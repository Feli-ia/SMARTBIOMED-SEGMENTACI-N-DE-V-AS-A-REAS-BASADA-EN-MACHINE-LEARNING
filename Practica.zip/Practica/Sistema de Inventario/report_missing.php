<?php
require_once('includes/load.php');

// Verificar si el usuario ha iniciado sesión
if (!$session->isUserLoggedIn()) {
    $session->msg('d', 'Error: Sesión de usuario no válida.');
    redirect('index.php', false);
}

// Obtener el ID del usuario
$user_id = $session->user_id;

if ($user_id === 0) {
    $session->msg('d', 'Error: Sesión de usuario no válida.');
    redirect('index.php', false);
}

// Manejar la solicitud de reporte
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $req_fields = ['description'];
    validate_fields($req_fields);

    if (empty($errors)) {
        $description = remove_junk($db->escape($_POST['description']));
        $date = make_date();

        $query = "INSERT INTO warnings (user_id, description, date) VALUES ('{$user_id}', '{$description}', '{$date}')";

        if ($db->query($query)) {
            $session->msg('s', "Reporte de advertencia registrado correctamente.");
            redirect('report_missing.php', false);
        } else {
            $session->msg('d', 'Falló al registrar el reporte de advertencia.');
            redirect('report_missing.php', false);
        }
    } else {
        $session->msg("d", $errors);
        redirect('report_missing.php', false);
    }
}

include_once('layouts/header.php');
?>

<div class="container">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-alert"></span>
          <span>Reportar Advertencia</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="report_missing.php" class="clearfix">
          <div class="form-group">
            <label for="description" class="control-label">Descripción</label>
            <textarea id="description" class="form-control" name="description" rows="5" placeholder="Escribe la descripción aquí..." required></textarea>
          </div>
          <div class="form-group">
            <button type="submit" name="report" class="btn btn-primary btn-block">Registrar Reporte</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>
