<?php $user = current_user(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>
        <?php
        if (!empty($page_title)) {
            echo remove_junk($page_title);
        } elseif (!empty($user)) {
            echo ucfirst($user['name']);
        } else {
            echo "Sistema de inventario";
        }
        ?>
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker3.min.css"/>
    <link rel="stylesheet" href="libs/css/main.css"/>
    <link rel="icon" href="favicon.ico" type="image/x-icon"/> <!-- Agregar favicon -->
</head>
<body>
<?php if ($session->isUserLoggedIn()): ?>
    <header id="header">
        <div class="logo pull-left">Gestión de Inventario</div>
        <div class="header-content">
            <div class="header-date pull-left">
                <strong id="current-time">
                    <?php
                    $dateTime = new DateTime('now', new DateTimeZone('America/Santiago'));
                    echo $dateTime->format('d/m/Y g:i:s a');
                    ?>
                </strong>
            </div>
            <div class="logos-container" style="text-align: center; width: 100%; position: absolute;">
                <div class="logos" style="display: inline-block; text-align: center; margin-left: 250px;">
                    <img src="uploads/logos/logo UV.png" alt="Logo UV" style="height: 40px; margin-right: 6 0px;">
                    <img src="uploads/logos/logo HCVB.png" alt="Logo HCVB" style="height: 50px; margin-left: 60px;">
                </div>
            </div>
            <div class="pull-right clearfix" style="position: relative;">
                <ul class="info-menu list-inline list-unstyled">
                    <li class="profile">
                        <?php
                        // Verifica la ruta de la imagen
                        $imagePath = isset($user['image']) ? $user['image'] : 'uploads/user.jpg';
                        ?>
                        <a href="#" data-toggle="dropdown" class="toggle" aria-expanded="false">
                            <img src="<?php echo $imagePath; ?>" class="img-circle img-inline" alt="User Image">
                            <span><?php echo remove_junk(ucfirst($user['name'])); ?> <i class="caret"></i></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="profile.php?id=<?php echo (int)$user['id']; ?>">
                                    <i class="glyphicon glyphicon-user"></i>
                                    Perfil
                                </a>
                            </li>
                            <li>
                                <a href="edit_account.php" title="Editar cuenta">
                                    <i class="glyphicon glyphicon-cog"></i>
                                    Configuración
                                </a>
                            </li>
                            <li class="last">
                                <a href="logout.php">
                                    <i class="glyphicon glyphicon-off"></i>
                                    Salir
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </header>
    <div class="sidebar">
        <?php if ($user['user_level'] === '1'): ?>
            <!-- Menú de administrador -->
            <?php include_once('admin_menu.php'); ?>
        <?php elseif ($user['user_level'] === '2'): ?>
            <!-- Menú de usuario especial -->
            <?php include_once('special_menu.php'); ?>
        <?php elseif ($user['user_level'] === '3'): ?>
            <!-- Menú de usuario -->
            <?php include_once('user_menu.php'); ?>
        <?php endif; ?>
    </div>
<?php endif; ?>
<div class="page">
    <div class="container-fluid"></div>
</div>
<script>
    function updateTime() {
        // Obtener la fecha y hora de Chile
        const options = {
            timeZone: "America/Santiago",
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        };
        const date = new Intl.DateTimeFormat('es-CL', options).format(new Date());
        document.getElementById('current-time').innerText = date.replace(",", "");
    }

    // Actualizar la hora cada segundo
    setInterval(updateTime, 1000);

    // Llamar a updateTime inmediatamente para establecer la hora inicial
    updateTime();
</script>
</body>
