<?php
$page_title = 'Eliminar Medicamento';
require_once('includes/load.php');
// Verifica qué nivel de usuario tiene permiso para ver esta página
page_require_level(2);

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
  $medicine_nombre = $db->escape($_GET['id']);
  
  // Verifica que el medicamento existe utilizando una consulta SQL
  $query = "SELECT * FROM medicamentos WHERE nombre = '{$medicine_nombre}' LIMIT 1";
  $result = $db->query($query);
  if ($result && $db->num_rows($result) > 0) {
    // Eliminar el medicamento
    $delete_query = "DELETE FROM medicamentos WHERE nombre = '{$medicine_nombre}'";
    
    if ($db->query($delete_query)) {
      $session->msg('s', "Medicamento eliminado correctamente.");
      redirect('medicine.php', false);
    } else {
      $session->msg('d', 'Lo siento, la eliminación falló.');
      redirect('medicine.php', false);
    }
  } else {
    $session->msg('d', 'Medicamento no encontrado.');
    redirect('medicine.php', false);
  }
} else {
  $session->msg('d', 'Solicitud no válida.');
  redirect('medicine.php', false);
}
?>

<?php include_once('layouts/header.php'); ?>
<div class="container">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-trash"></span>
          <span>Eliminar Medicamento</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="get" action="delete_medicine.php">
          <div class="form-group">
            <label for="medicine">Medicamento</label>
            <select class="form-control" nombre="id">
              <?php foreach ($all_medicines as $medicine): ?>
                <option value="<?php echo urlencode($medicine['nombre']); ?>">
                  <?php echo remove_junk($medicine['nombre']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <button type="submit" nombre="submit" class="btn btn-danger">Eliminar Medicamento</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>
