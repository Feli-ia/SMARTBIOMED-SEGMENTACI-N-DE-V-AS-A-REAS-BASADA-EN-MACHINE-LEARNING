<?php
$page_title = 'Préstamo de Producto';
require_once('includes/load.php');
page_require_level(require_level: 3);

$all_products = find_all('products'); // Obtener todos los productos para el autocompletado

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $req_fields = ['name', 'quantity', 'borrower_name', 'type'];
    validate_fields($req_fields);

    if (empty($errors)) {
        $date = make_date();
        $user_id = current_user_id(); // Obtener el ID del usuario autenticado

        // Verificar si el usuario existe en la tabla `users`
        $user = find_by_sql("SELECT name FROM users WHERE id='{$user_id}' LIMIT 1");
        if (!$user) {
            $session->msg('d', 'El ID del usuario no existe en la tabla de usuarios. Operación cancelada.');
            redirect('loan_product.php', false);
        }
        $user_name = $user[0]['name']; // Nombre del usuario actual

        $name = $_POST['name'];
        $quantity = $_POST['quantity'];
        $borrower_name = remove_junk($db->escape($_POST['borrower_name']));
        $type = $_POST['type'];

        $db->query("START TRANSACTION");

        try {
            foreach ($name as $index => $product_name) {
                $product_quantity = (int)$quantity[$index];

                // Buscar el producto en la base de datos
                $existing_product = find_by_sql("SELECT * FROM products WHERE name='{$product_name}' LIMIT 1");

                if ($existing_product) {
                    // Calcular la nueva cantidad en inventario
                    $new_quantity = ($type === 'Egreso') ? (int)$existing_product[0]['quantity'] - $product_quantity : (int)$existing_product[0]['quantity'] + $product_quantity;

                    if ($new_quantity < 0) {
                        throw new Exception('No hay suficiente cantidad para prestar.');
                    } else {
                        // Actualizar el inventario del producto
                        $update_query = "UPDATE products SET quantity={$new_quantity} WHERE name='{$product_name}'";
                        if (!$db->query($update_query)) {
                            throw new Exception('Falló al actualizar la cantidad del producto.');
                        }

                        // Registrar el movimiento del producto en la tabla `product_loans`
                        $loan_query = "INSERT INTO product_loans (product_id, quantity, borrower_name, user_id, user, date, type) 
                                       VALUES ('{$existing_product[0]['id']}', '{$product_quantity}', '{$borrower_name}', '{$user_id}', '{$user_name}', '{$date}', '{$type}')";
                        if (!$db->query($loan_query)) {
                            throw new Exception('Falló al registrar el préstamo del producto.');
                        }
                    }
                } else {
                    throw new Exception("El producto '{$product_name}' no existe.");
                }
            }

            $db->query("COMMIT");
            $session->msg('s', "Movimiento del producto registrado correctamente.");
        } catch (Exception $e) {
            $db->query("ROLLBACK");
            $session->msg('d', $e->getMessage());
        }

        redirect('loan_product.php', false);
    } else {
        $session->msg("d", $errors);
        redirect('loan_product.php', false);
    }
}
include_once('layouts/header.php')
?>

<div class="container">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-transfer"></span>
          <span>Movimiento de Producto</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="loan_product.php" class="clearfix">
          <div id="producto-fields">
            <div class="producto-field">
              <div class="form-group">
                <label for="name" class="control-label">Nombre</label>
                <input type="text" id="name" class="form-control product_id_input" name="name[]" placeholder="Nombre del producto" required>
                <ul class="dropdown-menu product_list"></ul>
              </div>
              <div class="form-group">
                <label for="quantity" class="control-label">Cantidad</label>
                <input type="number" id="quantity" class="form-control" name="quantity[]" min="1" placeholder="Cantidad utilizada" required>
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="borrower_name" class="control-label">Unidad Destino</label>
            <input type="text" id="borrower_name" class="form-control" name="borrower_name" placeholder="Nombre de Unidad" required>
          </div>
          <div class="form-group">
              <label for="type" class="control-label">Tipo de Movimiento</label>
              <select id="type" class="form-control" name="type" required>
                  <option value="Egreso">Egreso</option>
                  <option value="Ingreso">Ingreso</option>
              </select>
          </div>
          <div class="form-group">
            <button type="button" id="add-producto" class="btn btn-success">Agregar otro producto</button>
          </div>
          <div class="form-group">
            <button type="submit" name="loan" class="btn btn-primary">Registrar Movimiento</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const allProducts = <?php echo json_encode($all_products); ?>;

  function setupProductAutocomplete(container) {
    const productInput = container.querySelector('.product_id_input');
    const productList = container.querySelector('.product_list');

    productInput.addEventListener('input', function() {
      const userInput = productInput.value.toLowerCase();
      productList.innerHTML = '';
      if (userInput) {
        const filteredOptions = allProducts.filter(product => product.name.toLowerCase().includes(userInput));
        filteredOptions.forEach(product => {
          const option = document.createElement('li');
          option.className = 'dropdown-item';
          option.textContent = product.name;
          option.dataset.id = product.id;
          option.addEventListener('click', function() {
            productInput.value = product.name;
            productList.innerHTML = '';
          });
          productList.appendChild(option);
        });
        productList.style.display = 'block';
      } else {
        productList.style.display = 'none';
      }
    });

    document.addEventListener('click', function(event) {
      if (!productInput.contains(event.target) && !productList.contains(event.target)) {
        productList.style.display = 'none';
      }
    });
  }

  document.querySelectorAll('.producto-field').forEach(setupProductAutocomplete);

  document.getElementById('add-producto').addEventListener('click', function() {
    const productoFields = document.getElementById('producto-fields');
    const newFields = document.createElement('div');
    newFields.className = 'producto-field';
    newFields.innerHTML = `
      <div class="form-group">
        <label for="name" class="control-label">Nombre</label>
        <input type="text" class="form-control product_id_input" name="name[]" placeholder="Nombre del producto" required>
        <ul class="dropdown-menu product_list"></ul>
      </div>
      <div class="form-group">
        <label for="quantity" class="control-label">Cantidad</label>
        <input type="number" class="form-control" name="quantity[]" min="1" placeholder="Cantidad utilizada" required>
      </div>
      <div class="form-group">
        <button type="button" class="remove-producto btn btn-danger">Eliminar</button>
      </div>
    `;
    productoFields.appendChild(newFields);
    setupProductAutocomplete(newFields);
    attachRemoveEvent();
    updateRemoveButtons();
  });

  function attachRemoveEvent() {
    document.querySelectorAll('.remove-producto').forEach(button => {
      button.addEventListener('click', function() {
        button.closest('.producto-field').remove();
        updateRemoveButtons();
      });
    });
  }

  function updateRemoveButtons() {
    const removeButtons = document.querySelectorAll('.remove-producto');
    removeButtons.forEach((button, index) => {
      button.style.display = index < 1 ? 'none' : 'block'; // Ocultar el botón de eliminar si hay menos de 2 campos
    });
  }

  attachRemoveEvent();
  updateRemoveButtons();
});
</script>
