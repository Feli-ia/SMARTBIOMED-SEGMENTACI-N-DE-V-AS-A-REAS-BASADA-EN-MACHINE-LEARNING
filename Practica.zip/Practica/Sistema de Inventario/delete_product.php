<?php
$page_title = 'Eliminar Producto';
require_once('includes/load.php'); // Carga configuraciones y funciones necesarias
page_require_level(2); // Verifica los permisos del usuario

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
  $product_id = intval($db->escape($_GET['id'])); // Sanitiza el ID para mayor seguridad

  // Verificar si el producto existe en la base de datos
  $query = "SELECT * FROM products WHERE id = '{$product_id}' LIMIT 1";
  $result = $db->query($query);

  if ($result && $db->num_rows($result) > 0) {
    // Eliminar el producto de la base de datos
    $delete_query = "DELETE FROM products WHERE id = '{$product_id}'";
    if ($db->query($delete_query)) {
      $session->msg('s', "Producto eliminado exitosamente.");
      redirect('product.php', false); // Redirige a la página de gestión de productos
    } else {
      $session->msg('d', 'Error al intentar eliminar el producto.');
      redirect('product.php', false);
    }
  } else {
    $session->msg('d', 'Producto no encontrado en la base de datos.');
    redirect('product.php', false);
  }
} else {
  $session->msg('d', 'Solicitud no válida.');
  redirect('product.php', false);
}
?>
