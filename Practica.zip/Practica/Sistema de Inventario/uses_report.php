<?php
$page_title = 'Reporte de Consumo';
require_once('includes/load.php');
require_once('includes/sql.php'); // Make sure this line is added to include the file with the function

// Verifica qué nivel de usuario tiene permiso para ver esta página
page_require_level(3);

// Variables para los filtros adicionales
$selected_user = isset($_GET['selected_user']) ? (int)$_GET['selected_user'] : '';
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
$category = isset($_GET['category']) ? $_GET['category'] : '';
$min_quantity = isset($_GET['min_quantity']) ? (int)$_GET['min_quantity'] : 0;
$max_quantity = isset($_GET['max_quantity']) ? (int)$_GET['max_quantity'] : 0;

// Funciones para obtener los consumos
function get_consumption($selected_user, $filter_type, $start_date, $end_date, $category, $min_quantity, $max_quantity, $limit = 10, $offset = 0) {
  global $db;
  $table = $category == 'medicamentos' ? 'medicamentos' : 'products';
  $sql  = "SELECT user_id, product_id, SUM(quantity) as quantity, MAX(date) as date FROM product_usage WHERE 1=1 ";

  if (!empty($selected_user)) {
    $sql .= "AND user_id = '{$selected_user}' ";
  }

  if ($filter_type == 'diario') {
    $sql .= "AND DATE(date) = CURDATE() ";
  } elseif ($filter_type == 'mensual') {
    $sql .= "AND MONTH(date) = MONTH(CURDATE()) ";
  }

  if (!empty($start_date) && !empty($end_date)) {
    $sql .= "AND DATE(date) BETWEEN '{$start_date}' AND '{$end_date}' ";
  }

  if (!empty($category)) {
    if ($category == 'medicamentos') {
      $sql .= "AND product_id IN (SELECT id FROM medicamentos) ";
    } else {
      $sql .= "AND product_id IN (SELECT id FROM products WHERE categorie = '{$category}') ";
    }
  }

  if ($min_quantity > 0) {
    $sql .= "AND quantity >= {$min_quantity} ";
  }

  if ($max_quantity > 0) {
    $sql .= "AND quantity <= {$max_quantity} ";
  }

  $sql .= "GROUP BY user_id, product_id LIMIT {$limit} OFFSET {$offset}";
  return find_by_sql($sql);
}

// Obtener la página actual
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Obtener el tipo de filtro seleccionado
$filter_type = isset($_GET['filter_type']) ? $_GET['filter_type'] : 'total';

// Obtener los datos en función del filtro seleccionado
$consumption_data = get_consumption($selected_user, $filter_type, $start_date, $end_date, $category, $min_quantity, $max_quantity, $limit, $offset);

// Obtener categorías de productos para el filtro
$product_categories = find_all('categories');

// Obtener todos los usuarios para el filtro
$users = find_all('users');
?>

<?php include_once('layouts/header.php'); ?>
<div class="container">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-list-alt"></span>
          <span>Reporte de Consumo</span>
        </strong>
      </div>
      <div class="panel-body">
        <!-- Filtros -->
        <form method="get" action="uses_report.php" class="form-inline mb-3">
          <div class="form-group">
            <label for="filter_type">Filtro:</label>
            <select class="form-control ml-2" name="filter_type" onchange="this.form.submit()">
              <option value="total" <?php echo $filter_type == 'total' ? 'selected' : ''; ?>>Total</option>
              <option value="mensual" <?php echo $filter_type == 'mensual' ? 'selected' : ''; ?>>Mensual</option>
              <option value="diario" <?php echo $filter_type == 'diario' ? 'selected' : ''; ?>>Diario</option>
            </select>
          </div>
          <div class="form-group ml-3">
            <label for="selected_user">Usuario:</label>
            <select class="form-control ml-2" name="selected_user" onchange="this.form.submit()">
              <option value="">Todos</option>
              <?php foreach ($users as $user): ?>
                <option value="<?php echo $user['id']; ?>" <?php echo $selected_user == $user['id'] ? 'selected' : ''; ?>>
                  <?php echo $user['username']; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group ml-3">
            <label for="start_date">Fecha Inicio:</label>
            <input type="date" class="form-control ml-2" name="start_date" value="<?php echo $start_date; ?>" onchange="this.form.submit()">
          </div>
          <div class="form-group ml-3">
            <label for="end_date">Fecha Fin:</label>
            <input type="date" class="form-control ml-2" name="end_date" value="<?php echo $end_date; ?>" onchange="this.form.submit()">
          </div>
          <div class="form-group ml-3">
            <label for="category">Categoría:</label>
            <select class="form-control ml-2" name="category" onchange="this.form.submit()">
              <option value="">Todas</option>
              <?php foreach ($product_categories as $cat): ?>
                <option value="<?php echo $cat['name']; ?>" <?php echo $category == $cat['name'] ? 'selected' : ''; ?>>
                  <?php echo ucfirst($cat['name']); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group ml-3">
            <label for="min_quantity">Cantidad Mínima:</label>
            <input type="number" class="form-control ml-2" name="min_quantity" value="<?php echo $min_quantity; ?>" onchange="this.form.submit()">
          </div>
        </form>

        <!-- Paginación -->
        <?php
        // Contar el total de registros
        $total_records = count_by_sql("SELECT COUNT(*) as total FROM product_usage WHERE 1=1");

        // Calcular el total de páginas
        $total_pages = ceil($total_records['total'] / $limit);
        ?>
        <nav aria-label="Page navigation" style="margin-bottom: 20px;">
          <ul class="pagination">
            <?php if ($page > 1): ?>
              <li><a href="?page=1&selected_user=<?php echo urlencode($selected_user); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>&category=<?php echo urlencode($category); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&max_quantity=<?php echo urlencode($max_quantity); ?>&filter_type=<?php echo urlencode($filter_type); ?>" aria-label="First"><span aria-hidden="true">&laquo;&laquo;</span></a></li>
              <li><a href="?page=<?php echo $page - 1; ?>&selected_user=<?php echo urlencode($selected_user); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>&category=<?php echo urlencode($category); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&max_quantity=<?php echo urlencode($max_quantity); ?>&filter_type=<?php echo urlencode($filter_type); ?>" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
              <li class="<?php echo $page == $i ? 'active' : ''; ?>"><a href="?page=<?php echo $i; ?>&selected_user=<?php echo urlencode($selected_user); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>&category=<?php echo urlencode($category); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&max_quantity=<?php echo urlencode($max_quantity); ?>&filter_type=<?php echo urlencode($filter_type); ?>"><?php echo $i; ?></a></li>
            <?php endfor; ?>
            <?php if ($page < $total_pages): ?>
              <li><a href="?page=<?php echo $page + 1; ?>&selected_user=<?php echo urlencode($selected_user); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>&category=<?php echo urlencode($category); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&max_quantity=<?php echo urlencode($max_quantity); ?>&filter_type=<?php echo urlencode($filter_type); ?>" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>
              <li><a href="?page=<?php echo $total_pages; ?>&selected_user=<?php echo urlencode($selected_user); ?>&start_date=<?php echo urlencode($start_date); ?>&end_date=<?php echo urlencode($end_date); ?>&category=<?php echo urlencode($category); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&max_quantity=<?php echo urlencode($max_quantity); ?>&filter_type=<?php echo urlencode($filter_type); ?>" aria-label="Last"><span aria-hidden="true">&raquo;&raquo;</span></a></li>
            <?php endif; ?>
          </ul>
        </nav>

        <h4>Consumo <?php echo ucfirst($filter_type); ?></h4>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th class="text-center" style="width: 50px;">#</th>
              <th>Usuario</th>
              <th>Producto</th>
              <th class="text-center" style="width: 10%;">Cantidad</th>
              <th class="text-center" style="width: 15%;">Fecha</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($consumption_data as $consumption): ?>
              <?php
              $table = $category == 'medicamentos' ? 'medicamentos' : 'products';
              $user = find_by_id('users', $consumption['user_id']);
              ?>
              <tr>
                <td class="text-center"><?php echo count_id(); ?></td>
                <td><?php echo remove_junk($user['username']); ?></td>
                <td><?php echo remove_junk(find_by_id($table, $consumption['product_id'])['name']); ?></td>
                <td class="text-center"><?php echo (int)$consumption['quantity']; ?></td>
                <td class="text-center"><?php echo read_date($consumption['date']); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <!-- Gráficos -->
        <div class="panel-footer">
          <canvas id="consumoChart"></canvas>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>

<!-- Script para gráficos -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  document.addEventListener("DOMContentLoaded", function() {
    var ctx = document.getElementById('consumoChart').getContext('2d');
    var consumoChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: [<?php foreach ($consumption_data as $consumption) { echo '"' . remove_junk(find_by_id($table, $consumption['product_id'])['name']) . '",'; } ?>],
        datasets: [{
          label: 'Cantidad Consumida',
          data: [<?php foreach ($consumption_data as $consumption) { echo (int)$consumption['quantity'] . ','; } ?>],
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  });
</script>
