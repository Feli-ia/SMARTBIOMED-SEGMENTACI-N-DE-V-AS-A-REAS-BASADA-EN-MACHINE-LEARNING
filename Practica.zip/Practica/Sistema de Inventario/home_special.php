<?php
$page_title = 'Página de Inicio del Usuario Especial';
require_once('includes/load.php');
if (!$session->isUserLoggedIn()) { redirect('index.php', false);}
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
  <div class="col-md-12">
    <div class="panel">
      <div class="jumbotron text-center">
        <h1 style="font-size: 2.5em;">Bienvenido</h1>
        <p style="font-size: 1.2em;">En este sistema, usted puede realizar varias acciones importantes relacionadas con la gestión de inventario de productos. A continuación, se explican de forma clara y detallada las funcionalidades disponibles:</p>
        <hr>

<!-- Botón principal para Productos -->
<div class="feature">
  <button class="btn btn-custom-1 btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#productos">Productos</button>
  <div id="productos" class="collapse">

    <!-- Botón para Administrar Productos -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#administrar_productos">Administrar Productos</button>
      <div id="administrar_productos" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-3" style="flex-grow: 1;">
            <h2 style="font-size: 2em;"><strong>Administrar Productos</strong></h2>
            <p style="font-size: 1.2em; margin-left: 10px;">Aquí se puede ver el listado de productos, su código, categoría, cantidad, stock crítico. Se poseen filtros. Además, existe la opción de nuevo medicamento.</p>
          </div>
          <div class="col-md-9" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/special/special 1.1.png" class="img-responsive" alt="Listado de productos" style="width: 10%; margin-right: 10px;">
            <img src="uploads/special/special 1.1.1.png" class="img-responsive" alt="Opciones de administración" style="width: 75%; margin-left: 10px;">
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Botón para Nuevo Producto -->
    <div class="feature">
     <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#nuevo_producto">Nuevo Producto</button>
      <div id="nuevo_producto" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-9 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/special/special 1.2.png" class="img-responsive" alt="Registrar nuevo producto" style="width: 10%; margin-right: 10px;">
            <img src="uploads/special/special 1.2.1.png" class="img-responsive" alt="Formulario de registro" style="width: 75%;">
          </div>
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Nuevo Producto</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">En esta sección, puede registrar un nuevo producto en el sistema de inventario:</p>
            <ol style="font-size: 1.2em; margin-bottom: 1em;">
              <li style="margin-bottom: 1em;"><strong>Nombre del Producto:</strong> Ingrese el nombre del insumo, medicamento o material a agregar.</li>
              <li style="margin-bottom: 1em;"><strong>Categoría:</strong> Seleccione la categoría a la que pertenece el producto.</li>
              <li style="margin-bottom: 1em;"><strong>Cantidad:</strong> Especifique la cantidad inicial del producto.</li>
              <li style="margin-bottom: 1em;"><strong>Nivel Crítico:</strong> Defina el umbral mínimo de stock para generar alertas.</li>
            </ol>
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Botón para Ingreso de Producto -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#ingreso_producto">Ingreso de Producto</button>
      <div id="ingreso_producto" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Ingreso de Producto</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">Utilice este formulario para registrar la entrada de productos en el sistema:</p>
            <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left;">
              <li style="margin-bottom: 1em;"><strong>Producto:</strong> Ingrese el nombre del producto que se está agregando al inventar
              <li style="margin-bottom: 1em;"><strong>Agregar otro producto:</strong>Haga clic en este botón si desea registrar más productos en la misma operación.</li>
            </ol>
            <p style="font-size: 1.2em; max-width: 100%; text-align: left; margin-left: 20px;"><strong>Registrar Ingreso:</strong> Haga clic en este botón para guardar los cambios en el sistema.
            </p>
          </div>
          <div class="col-md-9 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/special/special 1.3.png" class="img-responsive" alt="Registrar ingreso de producto" style="width: 10%; margin-right: 10px;">
            <img src="uploads/special/special 1.3.1.png" class="img-responsive" alt="Formulario de ingreso" style="width: 75%;">
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Botón para Egreso de Producto -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#egreso_producto">Egreso de Producto</button>
      <div id="egreso_producto" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/special/special 1.4.png" class="img-responsive" alt="Registrar egreso de producto" style="width: 20%; margin-right: 10px;">
            <img src="uploads/special/special 1.4.1.png" class="img-responsive" alt="Formulario de egreso" style="width: 75%;">
          </div>
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Egreso de Producto</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">Utilice este formulario para registrar la salida de productos del sistema:</p>
            <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left;">
              <li style="margin-bottom: 1em;"><strong>Producto:</strong> Ingrese el nombre del producto que se está retirando del inventario.</li>
              <li style="margin-bottom: 1em;"><strong>Cantidad:</strong> Especifique la cantidad de unidades retiradas.</li>
            </ol>
            <p style="font-size: 1.2em; max-width: 100%; text-align: left; margin-left: 15px;">
              <strong>Agregar otro producto:</strong> Haga clic en este botón si desea registrar más productos en la misma operación.<br>
              <strong>Registrar Egreso:</strong> Haga clic en este botón para guardar los cambios en el sistema.
            </p>
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Botón para Préstamo de Producto -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#prestamo_producto">Préstamo de Producto</button>
      <div id="prestamo_producto" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Préstamo de Producto</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">Utilice este formulario para registrar el préstamo de productos del sistema:</p>
            <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left;">
              <li style="margin-bottom: 1em;"><strong>Producto:</strong> Ingrese el nombre del producto que se está prestando del inventario.</li>
              <li style="margin-bottom: 1em;"><strong>Cantidad:</strong> Especifique la cantidad de unidades prestadas.</li>
              <li style="margin-bottom: 1em;"><strong>Fecha de Devolución:</strong> Defina la fecha en que se debe devolver el producto.</li>
            </ol>
            <p style="font-size: 1.2em; max-width: 100%; text-align: left; margin-left: 15px;">
              <strong>Agregar otro producto:</strong> Haga clic en este botón si desea registrar más productos en la misma operación.<br>
              <strong>Registrar Préstamo:</strong> Haga clic en este botón para guardar los cambios en el sistema.
            </p>
          </div>
          <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/special/special 1.5.png" class="img-responsive" alt="Registrar préstamo de producto" style="width: 20%; margin-right: 10px;">
            <img src="uploads/special/special 1.5.1.png" class="img-responsive" alt="Formulario de préstamo" style="width: 75%;">
          </div>
        </div>
        <hr>
      </div>
    </div>
  </div>
</div>

<!-- Botón principal para Medicamentos -->
<div class="feature">
  <button class="btn btn-custom-2 btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#medications">Medicamentos</button>
  <div id="medications" class="collapse">

    <!-- Botón para Administrar Medicamentos -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#administrar_medications">Administrar Medicamentos</button>
      <div id="administrar_medications" class="collapse">
      <div class="col-md-9" style="display: flex; align-items: center; justify-content: center;">
            <img src="uploads/special/special 2.1.png" class="img-responsive" alt="Listado de medicamentos" style="width: 10%;">
            <img src="uploads/special/special 2.1.1.png" class="img-responsive" alt="Opciones de administración" style="width: 75%;">
          </div>
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-3" style="flex-grow: 1;">
            <h2 style="font-size: 2em;"><strong>Administrar Medicamentos</strong></h2>
            <p style="font-size: 1.2em;">Aquí se puede ver el listado de medicamentos, su código, categoría, cantidad, stock crítico. Se poseen filtros. Además, existe la opción de nuevo medicamento.</p>
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Botón para Nuevo Medicamento -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#nuevo_medications">Nuevo Medicamento</button>
      <div id="nuevo_medications" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Nuevo Medicamento</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">En esta sección, puede registrar un nuevo medicamento en el sistema de inventario:</p>
            <ol style="font-size: 1.2em; margin-bottom: 1em;">
              <li style="margin-bottom: 1em;"><strong>Nombre del Medicamento:</strong> Ingrese el nombre del medicamento a agregar.</li>
              <li style="margin-bottom: 1em;"><strong>Categoría:</strong> Seleccione la categoría a la que pertenece el medicamento.</li>
              <li style="margin-bottom: 1em;"><strong>Cantidad:</strong> Especifique la cantidad inicial del medicamento.</li>
              <li style="margin-bottom: 1em;"><strong>Nivel Crítico:</strong> Defina el umbral mínimo de stock para generar alertas.</li>
            </ol>
          </div>
          <div class="col-md-9 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/special/special 2.4.png" class="img-responsive" alt="Registrar nuevo medicamento" style="width: 10%; margin-right: 10px;">
            <img src="uploads/special/special 2.4.1.png" class="img-responsive" alt="Formulario de registro" style="width: 75%;">
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Botón para Ingreso de Medicamento -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#ingreso_medications">Ingreso de Medicamento</button>
      <div id="ingreso_medications" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
        <div class="col-md-9 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/special/special 2.2.png" class="img-responsive" alt="Registrar ingreso de medicamento" style="width: 10%; margin-right: 10px;">
            <img src="uploads/special/special 2.2.1.png" class="img-responsive" alt="Formulario de ingreso" style="width: 75%;">
          </div>
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Ingreso de Medicamento</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">Utilice este formulario para registrar la entrada de medicamentos en el sistema:</p>
            <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left;">
              <li style="margin-bottom: 1em;"><strong>Medicamento:</strong> Ingrese el nombre del medicamento que se está agregando al inventario.</li>
              <li style="margin-bottom: 1em;"><strong>Cantidad:</strong> Especifique la cantidad de unidades ingresadas.</li>
            </ol>
            <p style="font-size: 1.2em; max-width: 100%; text-align: left; margin-left: 15px;">
              <strong>Agregar otro medicamento:</strong> Haga clic en este botón si desea registrar más medicamentos en la misma operación.<br>
              <strong>Registrar Ingreso:</strong> Haga clic en este botón para guardar los cambios en el sistema.
            </p>
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Botón para Egreso de Medicamento -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#egreso_medications">Egreso de Medicamento</button>
      <div id="egreso_medications" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Egreso de Medicamento</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">Utilice este formulario para registrar la salida de medicamentos del sistema:</p>
            <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left;">
              <li style="margin-bottom: 1em;"><strong>Medicamento:</strong> Ingrese el nombre del medicamento que se está retirando del inventario.</li>
              <li style="margin-bottom: 1em;"><strong>Cantidad:</strong> Especifique la cantidad de unidades retiradas.</li>
            </ol>
            <p style="font-size: 1.2em; max-width: 100%; text-align: left; margin-left: 15px;">
              <strong>Agregar otro medicamento:</strong> Haga clic en este botón si desea registrar más medicamentos en la misma operación.<br>
              <strong>Registrar Egreso:</strong> Haga clic en este botón para guardar los cambios en el sistema.
            </p>
          </div>
          <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/special/special 2.3.png" class="img-responsive" alt="Registrar egreso de medicamento" style="width: 20%; margin-right: 10px;">
            <img src="uploads/special/special 2.3.1.png" class="img-responsive" alt="Formulario de egreso" style="width: 75%;">
          </div>
        </div>
        <hr>
      </div>
    </div>

  </div>
</div>


<!-- Historial de Movimientos -->
<div class="feature">
  <button class="btn btn-custom-4 btn-lg btn-block mb-2" data-toggle="collapse" data-target="#historial_movimientos">Historial de Movimientos</button>
  <div id="historial_movimientos" class="collapse">
    <div class="feature row" style="display: flex; align-items: center; text-align: center;">
      <div class="col-md-5" style="display: flex; align-items: center; justify-content: center; gap: 5%; margin-left: 10px;">
        <img src="uploads/special/special 3.png" class="img-responsive" alt="Historial de Movimientos" style="width: 20%;">
        <img src="uploads/special/special 3.1.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
      </div>
      <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
        <h2 style="font-size: 2em; text-align: center;"><strong>Historial de Movimientos</strong></h2>
        <p style="font-size: 1.2em; text-align: center;">En esta sección, puede realizar las siguientes acciones:</p>
        <ul style="font-size: 1.2em; text-align: left; margin-left: 20px;">
          <li style="margin-bottom: 1em;">Visualizar el historial completo de movimientos de productos y medicamentos en el inventario.</li>
          <li style="margin-bottom: 1em;">Utilizar filtros para buscar movimientos específicos por fecha, tipo de producto, cantidad, y más.</li>
          <li style="margin-bottom: 1em;">Generar reportes detallados de los movimientos realizados en el sistema.</li>
          <li style="margin-bottom: 1em;">Exportar el historial de movimientos a formatos como Excel o PDF para su análisis.</li>
        </ul>
      </div>
    </div>
    <hr>
  </div>
</div>


<!--Advertencia -->
<div class="feature">
  <button class="btn btn-custom-5 btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#advertencia">Advertencia</button>
  <div id="advertencia" class="collapse">
    <div class="feature row">
      <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
        <h2 style="font-size: 2em; text-align: center;"><strong>Advertencia</strong></h2>
        <p style="font-size: 1.2em; max-width: 100%; text-align: center;">Utilice esta opción para reportar problemas relacionados con la falta de insumos o medicamentos:</p>
        <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: center;">
          <li style="margin-bottom: 1em;"><strong>Descripción del Problema:</strong> Ingrese la descripción del problema.</li>
        </ol>
        <p style="font-size: 1.2em; max-width: 100%; text-align: center;"><strong>Registrar Advertencia:</strong> Haga clic en este botón para guardar el reporte en el sistema.</p>
      </div>
      <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
        <img src="uploads/special/special 4.png" class="img-responsive" alt="Instrucciones para registrar advertencias" style="width: 20%;">
        <img src="uploads/special/special 4.1.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
      </div>
    </div>
  </div>
</div>
<hr>


        <p style="font-size: 1.2em;">Utilice el menú de navegación lateral para acceder a las diferentes secciones de la plataforma. Si tiene alguna duda o problema, no dude en contactar con el soporte técnico.</p>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>

<?php include_once('layouts/footer.php'); ?>



<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cortina de Gatos y Perros</title>
  <style>
    .animated-pet {
      position: fixed;
      z-index: 9999;
    }
    .cat {
      width: 150px;
      height: auto;
    }
    .dog {
      width: 800px;
      height: auto;
    }
    .hidden {
      display: none;
    }
    #timer-circle {
      width: 40px;
      height: 40px;
      border: 1px solid #000;
      border-radius: 60%;
      display: inline-block;
      margin-left: 10px;
      position: relative;
      background: conic-gradient(black 0deg, black 0deg);
    }
    .btn-bonus {
      background-color:rgba(9, 71, 125, 0.96);
      border-color:rgb(12, 92, 177);
      color: white;
      font-size: 16px;
      padding: 10px 20px;
      border-radius: 5px;
      border: none;
      cursor: pointer;
      transition: background-color 0.3s ease, border-color 0.3s ease;
    }

    .btn-bonus:hover {
      background-color: #0056b3;
      border-color: #0056b3;
    }
  </style>
</head>
<body>
  <div id="animals-container"></div>
  <button id="toggle-button" class="btn-bonus">Bonus</button>
  <div id="timer-circle" class="hidden"></div>
</body>
</html>

  <script>
    let animalsActive = false;
    let loopInterval;
    const maxCats = 70; // Aumentado el número de gatos
    const maxDogs = 12; // Aumentado el número de perros
    const rowHeight = 120;
    const catRows = [0, 2, 4, 6];
    const dogRows = [1, 3, 5];
    const maxActiveAnimals = 20; // Aumentado el número máximo de animales activos
    let timerInterval;

    function toggleAnimals() {
      animalsActive = !animalsActive;
      const button = document.getElementById('toggle-button');
      const timerCircle = document.getElementById('timer-circle');
      button.textContent = animalsActive ? 'Desactivar' : 'Bonus';
      timerCircle.classList.toggle('hidden', !animalsActive);
      if (animalsActive) {
        startTimer();
        startAnimals();
      } else {
        stopAnimals();
      }
    }

    function startTimer() {
      let timeLeft = 20;
      const timerCircle = document.getElementById('timer-circle');
      timerInterval = setInterval(() => {
        timeLeft -= 1;
        const degrees = (timeLeft / 20) * 360;
        timerCircle.style.background = `conic-gradient(black ${degrees}deg, transparent ${degrees}deg)`;
        if (timeLeft <= 0) {
          clearInterval(timerInterval);
          stopAnimals(); // Parar los animales al finalizar el tiempo
        }
      }, 1000);
    }

    function startAnimals() {
  const catInterval = 300;  // Intervalo para los gatos
  const dogInterval = 2000; // Intervalo aumentado para los perros
  const startTime = Date.now();

  function animate() {
    if (!animalsActive) return;

    let activeAnimals = document.querySelectorAll('.animated-pet').length;
    if (activeAnimals >= maxActiveAnimals) {
      return;
    }

    for (let i = 0; i < maxCats; i++) {
      const row = catRows[i % catRows.length];
      createAnimal(i * catInterval, row * rowHeight, 'cat');
    }

    for (let i = 0; i < maxDogs; i++) {
      const row = dogRows[i % dogRows.length];
      createAnimal(i * dogInterval, row * rowHeight + 20, 'dog');
    }

    setTimeout(() => {
      const elapsedTime = Date.now() - startTime;
      if (elapsedTime < 20000 && animalsActive) {
        animate();
      }
    }, Math.max(maxCats * catInterval, maxDogs * dogInterval));
  }

  animate();
  loopInterval = setInterval(() => {
    if (animalsActive) {
      animate();
    }
  }, Math.max(maxCats * catInterval, maxDogs * dogInterval));
}

    function stopAnimals() {
      animalsActive = false;
      const button = document.getElementById('toggle-button');
      const timerCircle = document.getElementById('timer-circle');
      button.textContent = 'Bonus';
      button.disabled = false;
      clearInterval(loopInterval);
      clearInterval(timerInterval);
      document.getElementById('animals-container').innerHTML = '';
      timerCircle.classList.add('hidden');
    }

    function createAnimal(delay, topPosition, type) {
      const animalsContainer = document.getElementById('animals-container');
      const animal = document.createElement('div');
      animal.className = 'animated-pet ' + type;
      animal.style.top = `${topPosition}px`;

      if (type === 'cat') {
        animal.style.left = `${window.innerWidth}px`;
        animal.innerHTML = '<img src="https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExb3h2ZDhuYzRvYmp5MHQ0eTRnZGVrc2x4bDE5cGl3bmJ0bHNjZXFocCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/QcuzOd4rRLyLu/giphy.gif" alt="Gato" class="cat">';
      } else if (type === 'dog') {
        animal.style.left = `-${window.innerWidth}px`;
        animal.innerHTML = '<img src="https://media0.giphy.com/media/iEp5KdgmIMzz4u5jvI/giphy.gif" alt="Perro corriendo" class="dog">';
      }

      animalsContainer.appendChild(animal);

      setTimeout(() => {
        if (animalsActive) moveAnimal(animal, type);
      }, delay);
    }

    function moveAnimal(animal, type) {
      let startTime = null;
      const duration = 10000;
      const startLeft = type === 'cat' ? window.innerWidth : -animal.offsetWidth;
      const endLeft = type === 'cat' ? -animal.offsetWidth : window.innerWidth;

      function step(timestamp) {
        if (!startTime) startTime = timestamp;
        const progress = timestamp - startTime;
        const left = startLeft + ((endLeft - startLeft) * (progress / duration));
        animal.style.left = `${left}px`;
        if (progress < duration) {
          window.requestAnimationFrame(step);
        } else {
          if (animal.parentNode === animalsContainer) {
            animalsContainer.removeChild(animal);
          }
        }
      }

      window.requestAnimationFrame(step);
    }

    document.getElementById('toggle-button').addEventListener('click', toggleAnimals);
  </script>
</body>
</html>

