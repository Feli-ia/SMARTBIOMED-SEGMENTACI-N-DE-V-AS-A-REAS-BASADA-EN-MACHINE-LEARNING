<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(3);
?>
<?php
  $d_use = find_by_id('uses',(int)$_GET['id']);
  if(!$d_use){
    $session->msg("d","ID vacío.");
    redirect('uses.php');
  }
?>
<?php
  $delete_id = delete_by_id('uses',(int)$d_use['id']);
  if($delete_id){
      $session->msg("s","Uso eliminada.");
      redirect('uses.php');
  } else {
      $session->msg("d","Eliminación falló");
      redirect('uses.php');
  }
?>
