<?php
  require_once('includes/load.php');
  
  // Verificar si el usuario tiene permisos para ver esta página
  page_require_level(2);

  // Obtener todos los movimientos de inventario
  function get_inventory_report() {
    global $db;
    $sql  = "SELECT product_id, quantity, type, date FROM inventory ";
    $sql .= "ORDER BY date DESC";
    return find_by_sql($sql);
  }

  $inventory_report = get_inventory_report();
?>

<?php include_once('layouts/header.php'); ?>

<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Reporte de Inventario</span>
        </strong>
      </div>
      <div class="panel-body">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Producto</th>
              <th>Cantidad</th>
              <th>Tipo</th>
              <th>Fecha</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($inventory_report as $report): ?>
              <tr>
                <td><?php echo remove_junk($report['product_id']); ?></td>
                <td><?php echo remove_junk($report['quantity']); ?></td>
                <td><?php echo remove_junk($report['type']); ?></td>
                <td><?php echo remove_junk($report['date']); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>
