<?php
$page_title = 'Página de Inicio del Usuario Especial';
require_once('includes/load.php');
if (!$session->isUserLoggedIn()) { redirect('index.php', false);}
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
  <div class="col-md-12">
    <div class="panel">
      <div class="jumbotron text-center">
        <h1 style="font-size: 2.5em;">Bienvenido</h1>
        <p style="font-size: 1.2em;">En este sistema, usted puede realizar varias acciones importantes relacionadas con la gestión de inventario de productos y medicamentos.</p>
        <p style="font-size: 1.2em;">A continuación, se explican de forma clara y detallada las funcionalidades disponibles:</p>
        <hr>

<!-- Panel de Control -->
        <div class="feature">
          <button class="btn btn-custom-1 btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#control_panel">Panel de Control</button>
          <div id="control_panel" class="collapse">
            <div class="feature row">
            <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
              <img src="uploads/admin/admin 1.png" class="img-responsive" alt="Instrucciones para registrar advertencias" style="width: 20%;">
              <img src="uploads/admin/admin 1.1.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
            </div>
            <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
              <h2 style="font-size: 2em; text-align: center;"><strong>Panel de Control</strong></h2>
              <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
                Bienvenido al corazón del sistema: el Panel de Control. Aquí podrás obtener una visión clara y actualizada del estado de tu inventario. 
                Este espacio actúa como una central de información, destacando los productos o medicamentos con <strong>stock crítico</strong> que requieren atención inmediata.
              </p>
              <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
                Además, te ofrece un resumen detallado de los <strong>últimos ingresos</strong>, permitiéndote monitorear con precisión los movimientos recientes de tu inventario. 
                Desde las adquisiciones más recientes hasta las necesidades urgentes, este panel está diseñado para mantenerte informado en todo momento.
              </p>
              <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
                Mantén el control absoluto de tu inventario y toma decisiones informadas con facilidad. ¡Todo lo que necesitas está a un clic de distancia!
              </p>
            </div>
            </div>
            <hr>
          </div>
        </div>

        
<!-- Accesos -->
<div class="feature">
  <button class="btn btn-custom-2 btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#accesos">Accesos</button>
  <div id="accesos" class="collapse">

    <!-- Administrar Grupos -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#grupos">Administrar Grupos</button>
      <div id="grupos" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-9 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/admin/admin 2.1.png" class="img-responsive" alt="" style="width: 10%; margin-right: 10px;">
            <img src="uploads/admin/admin 2.1.1.png" class="img-responsive" alt="" style="width: 75%;">
          </div>
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Administrar Grupos</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Bienvenido a la sección de <strong>Administración de Grupos</strong>, diseñada para ofrecerte un control preciso y detallado sobre los diferentes tipos de usuarios en el sistema. Aquí podrás comprender y gestionar las funcionalidades específicas asignadas a cada grupo de usuarios.
            </p>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Cada tipo de usuario tiene roles y permisos claramente definidos para garantizar un flujo de trabajo eficiente y ordenado. Explora las características de los siguientes grupos:
            </p>
            <ol style="font-size: 1.2em; margin-bottom: 1em;">
              <li style="margin-bottom: 1em;">
                <strong>Admin:</strong> El grupo de usuarios más exclusivo, reservado para las <strong>supervisoras de la unidad</strong>. Los administradores tienen acceso total para configurar y supervisar el sistema. 
                <em>Nivel del Usuario:</em> 1.
              </li>
              <li style="margin-bottom: 1em;">
                <strong>Special:</strong> Este grupo abarca al <strong>personal de bodega</strong>, encargado de gestionar el ingreso y egreso de productos y medicamentos. Son esenciales para el manejo de inventario eficiente.
                <em>Nivel del Usuario:</em> 2.
              </li>
              <li style="margin-bottom: 1em;">
                <strong>User:</strong> Los usuarios generales representan al <strong>personal operativo</strong>, quienes registran el uso de insumos y medicamentos directamente en los boxes y salas correspondientes.
                <em>Nivel del Usuario:</em> 3.
              </li>
            </ol>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Esta sección no solo te permite visualizar los grupos existentes, sino también ajustar sus configuraciones según las necesidades operativas. Gestiona con confianza y asegúrate de que todos los usuarios tengan los permisos adecuados para desempeñar su rol.
            </p>
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Administrar Usuarios -->
        <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#usuarios">Adminitrar Usuarios</button>
      <div id="usuarios" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
        <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
          <h2 style="font-size: 2em; text-align: center;"><strong>Administrar Usuarios</strong></h2>
          <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
            Bienvenido al módulo de <strong>Gestión de Usuarios</strong>, una herramienta esencial para mantener el control y la organización de tu sistema. Aquí podrás acceder a las funcionalidades necesarias para asegurar que cada usuario tenga permisos y roles adecuados.
          </p>
          <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
            Este apartado te permite <strong>modificar usuarios existentes</strong> para reflejar cambios en responsabilidades, <strong>añadir nuevos usuarios</strong> con facilidad y <strong>eliminar usuarios</strong> que ya no estén en uso. ¡Gestiona tu equipo de manera eficiente y sin complicaciones!
          </p>
          <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
            Asegúrate de mantener tu sistema actualizado con una lista de usuarios precisa y ordenada. Con estas opciones, puedes ajustar configuraciones específicas para optimizar los flujos de trabajo y garantizar un acceso controlado.
          </p>
          <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
            ¡Empieza a personalizar la experiencia de tus usuarios y garantiza un entorno bien administrado desde aquí mismo!
          </p>
        </div>
          <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/admin/admin 2.2.png" class="img-responsive" alt="" style="width: 20%; margin-right: 10px;">
            <img src="uploads/admin/admin 2.2.1.png" class="img-responsive" alt="" style="width: 75%;">
          </div>
        </div>
        <hr>
      </div>
    </div>
  </div>
</div>

    <!-- Categorias -->
<div class="feature">
          <button class="btn btn-custom-3 btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#categorias">Categorias</button>
          <div id="categorias" class="collapse">
            <div class="feature row">
            <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
              <img src="uploads/admin/admin 3.png" class="img-responsive" alt="Instrucciones para registrar advertencias" style="width: 20%;">
              <img src="uploads/admin/admin 3.1.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
            </div>
            <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
              <h2 style="font-size: 2em; text-align: center;"><strong>Categorías</strong></h2>
              <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
                Explora las <strong>categorías principales</strong> que estructuran y optimizan el manejo de productos dentro del sistema. Cada categoría está diseñada para facilitar la organización y el acceso rápido a los elementos necesarios.
              </p>
              <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
                Las categorías disponibles incluyen:
              </p>
              <ul style="font-size: 1.2em; margin: 0 auto; text-align: left; list-style-position: inside;">
                <li style="margin-bottom: 1em;">
                  <strong>Insumos:</strong> Materiales generales que se utilizan en las operaciones diarias.
                </li>
                <li style="margin-bottom: 1em;">
                  <strong>Esterilización:</strong> Elementos esenciales para garantizar la limpieza y seguridad en procedimientos.
                </li>
                <li style="margin-bottom: 1em;">
                  <strong>Economato:</strong> Productos relacionados con el almacenamiento y el uso común dentro de la organización.
                </li>
                <li style="margin-bottom: 1em;">
                  <strong>Medicamentos:</strong> Recursos farmacéuticos críticos que requieren un manejo adecuado.
                </li>
              </ul>
              <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
                Mantén tu inventario bien organizado y clasificado para agilizar las operaciones y garantizar un control efectivo de cada recurso. ¡Haz de esta sección tu aliada para la gestión eficiente!
              </p>
            </div>
            </div>
            <hr>
          </div>
        </div>
    
    <!-- Productos -->
<div class="feature">
  <button class="btn btn-custom-4 btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#productos">Productos</button>
  <div id="productos" class="collapse">

    <!-- Administrar Productos -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#administrar_productos">Administrar Productos</button>
      <div id="administrar_productos" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
        <div class="col-md-3" style="flex-grow: 1;">
          <h2 style="font-size: 2em; text-align: center;"><strong>Administrar Productos</strong></h2>
          <p style="font-size: 1.2em; text-align: justify;">
            Bienvenido a la sección de <strong>Administración de Productos</strong>, diseñada para ofrecerte una visión completa y detallada de tu inventario. Aquí encontrarás un listado de todos los productos disponibles, con información clave como <strong>código</strong>, <strong>categoría</strong>, <strong>cantidad</strong> y su <strong>nivel de stock crítico</strong>. Esta funcionalidad te garantiza un control total de los recursos esenciales.
          </p>
          <p style="font-size: 1.2em; text-align: justify;">
            Además, esta herramienta cuenta con <strong>filtros avanzados</strong> que te permitirán buscar y organizar los productos según tus necesidades específicas, facilitando la localización rápida de lo que necesitas. 
          </p>
          <p style="font-size: 1.2em; text-align: justify;">
            ¿Necesitas agregar un nuevo medicamento al inventario? Esta sección te brinda la opción de registrar fácilmente nuevos productos, asegurando que tu inventario esté siempre actualizado y adaptado a las demandas de tu operación.
          </p>
          <p style="font-size: 1.2em; text-align: justify;">
            Mantén un flujo de trabajo organizado, reduce riesgos de desabastecimiento y optimiza la gestión de tu inventario con estas potentes herramientas de administración.
          </p>
        </div>
          <div class="col-md-9" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/admin/admin 4.1.png" class="img-responsive" alt="" style="width: 10%; margin-right: 10px;">
            <img src="uploads/admin/admin 4.1.1.png" class="img-responsive" alt="" style="width: 75%; margin-left: 10px;">
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Nuevo Producto -->
    <div class="feature">
     <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#nuevo_producto">Nuevo Producto</button>
      <div id="nuevo_producto" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-9 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/admin/admin 4.2.png" class="img-responsive" alt="Registrar nuevo producto" style="width: 10%; margin-right: 10px;">
            <img src="uploads/admin/admin 4.2.1.png" class="img-responsive" alt="Formulario de registro" style="width: 75%;">
          </div>
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Nuevo Producto</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              ¡Bienvenido a la sección de <strong>Registro de Nuevos Productos</strong>! Este espacio está diseñado para simplificar el proceso de agregar nuevos elementos a tu inventario, asegurando que cada detalle sea registrado con precisión.
            </p>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Sigue estos sencillos pasos para completar el registro:
            </p>
            <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
              <li style="margin-bottom: 1em;">
                <strong>Nombre del Producto:</strong> Introduce el nombre completo del insumo, medicamento o material que deseas añadir. Este nombre será clave para identificarlo en el sistema.
              </li>
              <li style="margin-bottom: 1em;">
                <strong>Categoría:</strong> Selecciona la categoría más adecuada para el producto. Por ejemplo: Insumos, Esterilización, Economato o Medicamentos, dependiendo de su uso o tipo.
              </li>
              <li style="margin-bottom: 1em;">
                <strong>Cantidad:</strong> Indica la cantidad inicial que se incorporará al inventario. Asegúrate de ser lo más preciso posible para evitar discrepancias en el stock.
              </li>
              <li style="margin-bottom: 1em;">
                <strong>Nivel Crítico:</strong> Define el nivel mínimo de stock para este producto. Si las existencias descienden por debajo de este nivel, el sistema generará alertas automáticas para evitar desabastecimientos.
              </li>
            </ol>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Mantener un registro detallado y actualizado de tus productos es fundamental para garantizar un flujo de trabajo eficiente y sin interrupciones. ¡Aprovecha esta sección para optimizar tu inventario desde el primer paso!
            </p>
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Ingreso de Producto -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#ingreso_producto">Ingreso de Producto</button>
      <div id="ingreso_producto" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
        <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
          <h2 style="font-size: 2em; text-align: center;"><strong>Ingreso de Producto</strong></h2>
          <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
            Bienvenido al módulo de <strong>Ingreso de Productos</strong>, tu herramienta clave para mantener el inventario actualizado y bien organizado. Aquí podrás registrar las entradas de manera precisa, asegurando que cada nuevo producto sea registrado correctamente en el sistema.
          </p>
          <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
            Sigue estos pasos sencillos para completar el proceso:
          </p>
          <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
            <li style="margin-bottom: 1em;">
              <strong>Producto:</strong> Introduce el nombre del producto que deseas añadir al inventario. Asegúrate de usar una descripción clara para identificarlo fácilmente.
            </li>
            <li style="margin-bottom: 1em;">
              <strong>Cantidad:</strong> Especifica el número de unidades que ingresarán al sistema. Este dato es esencial para reflejar el stock actualizado.
            </li>
          </ol>
          <p style="font-size: 1.2em; max-width: 100%; text-align: left;">
            <strong>Opciones adicionales:</strong> 
          </p>
          <ul style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
            <li style="margin-bottom: 1em;">Haz clic en <strong>Agregar otro producto</strong> si necesitas ingresar más artículos en la misma operación.</li>
            <li style="margin-bottom: 1em;">Cuando finalices, selecciona <strong>Registrar Ingreso</strong> para guardar los cambios en el sistema de manera permanente.</li>
          </ul>
          <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
            Asegúrate de revisar los datos ingresados antes de proceder para mantener la precisión del inventario. ¡Facilita tu trabajo diario con esta herramienta eficiente y confiable!
          </p>
        </div>
          <div class="col-md-9 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/admin/admin 4.3.png" class="img-responsive" alt="Registrar ingreso de producto" style="width: 10%; margin-right: 10px;">
            <img src="uploads/admin/admin 4.3.1.png" class="img-responsive" alt="Formulario de ingreso" style="width: 75%;">
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Egreso de Producto -->
    <div class="feature">
  <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#egreso_producto">Egreso de Producto</button>
  <div id="egreso_producto" class="collapse">
    <div class="feature row" style="display: flex; align-items: center; text-align: center;">
      <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
        <img src="uploads/admin/admin 4.4.png" class="img-responsive" alt="Registrar egreso de producto" style="width: 20%; margin-right: 10px;">
        <img src="uploads/admin/admin 4.4.1.png" class="img-responsive" alt="Formulario de egreso de producto" style="width: 75%;">
      </div>
      <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
        <h2 style="font-size: 2em; text-align: center;"><strong>Egreso de Producto</strong></h2>
        <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
          Bienvenido a la sección de <strong>Egreso de Productos</strong>, diseñada para registrar de forma ágil y precisa las salidas de artículos de tu inventario. Mantén un control total sobre tus recursos mientras optimizas la gestión operativa.
        </p>
        <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
          Sigue estos pasos para realizar un registro exitoso:
        </p>
        <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
          <li style="margin-bottom: 1em;">
            <strong>Producto:</strong> Escribe el nombre del producto que deseas retirar del inventario. Asegúrate de especificarlo correctamente para garantizar un registro exacto.
          </li>
          <li style="margin-bottom: 1em;">
            <strong>Cantidad:</strong> Indica con precisión el número de unidades a retirar. Esta información es crucial para reflejar los ajustes en el stock.
          </li>
        </ol>
        <p style="font-size: 1.2em; max-width: 100%; text-align: left;">
          <strong>Opciones adicionales:</strong>
        </p>
        <ul style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
          <li style="margin-bottom: 1em;">Haz clic en <strong>Agregar otro producto</strong> para incluir más egresos en la misma operación.</li>
          <li style="margin-bottom: 1em;">Selecciona <strong>Registrar Egreso</strong> para guardar los cambios y actualizar el inventario.</li>
        </ul>
        <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
          Con esta herramienta, puedes garantizar una gestión precisa y confiable de los recursos, ayudándote a mantener tu inventario siempre actualizado y eficiente. ¡Confía en esta funcionalidad para mantener tus operaciones en marcha sin interrupciones!
        </p>
      </div>
    </div>
    <hr>
  </div>
</div>


    <!-- Uso de Producto -->
    <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#uso_productos">Uso de Productos</button>
        <div id="uso_productos" class="collapse">
          <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Gestión de Productos</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              El módulo de <strong>Gestión de Productos</strong>, donde podrás llevar el control total de los recursos en tu inventario. Esta herramienta está diseñada para garantizar un manejo eficiente y actualizado de los productos utilizados en las operaciones diarias.
            </p>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              A continuación, sigue estos pasos sencillos para registrar y gestionar el uso de productos en tu sistema:
            </p>
            <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
              <li style="margin-bottom: 1em;">
                <strong>Nombre del Producto:</strong> Introduce el nombre del producto que deseas gestionar (por ejemplo, "Guantes"). Este campo es clave para identificar los artículos específicos en el inventario.
              </li>
              <li style="margin-bottom: 1em;">
                <strong>Cantidad:</strong> Especifica el número exacto de unidades utilizadas (por ejemplo, "10"). Esto asegura que el sistema registre correctamente las existencias restantes.
              </li>
              <li style="margin-bottom: 1em;">
                <strong>Agregar otro producto:</strong> Si tienes múltiples productos por registrar, haz clic en este botón para añadir más artículos a la misma operación sin interrupciones.
              </li>
            </ol>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Una vez completados todos los campos requeridos, selecciona <strong>Registrar Uso</strong> para guardar los cambios en el sistema. Este paso garantiza que el inventario se mantenga actualizado y refleje con precisión el estado actual de los recursos disponibles.
            </p>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Utiliza esta funcionalidad para optimizar la administración de tus recursos, prevenir desabastecimientos y asegurar un seguimiento detallado de cada producto utilizado. ¡Haz que tu inventario sea más eficiente hoy mismo!
            </p>
          </div>
            <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
              <img src="uploads/admin/admin 4.5.png" class="img-responsive" alt="Instrucciones para registrar el uso de Insumos" style="width: 20%;">
              <img src="uploads/admin/admin 4.5.1.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
            </div>
          </div>
          <hr>
        </div>

    <!-- Préstamo de Producto -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#prestamo_producto">Préstamo de Producto</button>
      <div id="prestamo_producto" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
        <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
          <h2 style="font-size: 2em; text-align: center;"><strong>Préstamo de Producto</strong></h2>
          <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
            Ell módulo de <strong>Préstamo de Productos</strong>. Esta herramienta está diseñada para registrar y organizar de manera eficiente los productos prestados, asegurando un seguimiento claro y estructurado de los recursos.
          </p>
          <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
            Sigue estos sencillos pasos para completar el registro de un préstamo:
          </p>
          <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
            <li style="margin-bottom: 1em;">
              <strong>Producto:</strong> Introduce el nombre del producto que deseas prestar. Este será el identificador principal en el sistema.
            </li>
            <li style="margin-bottom: 1em;">
              <strong>Cantidad:</strong> Especifica el número exacto de unidades que se están prestando. Este valor garantiza un control preciso del inventario.
            </li>
            <li style="margin-bottom: 1em;">
              <strong>Fecha de Devolución:</strong> Indica la fecha límite en que se debe devolver el producto. Esta información es esencial para mantener un seguimiento adecuado y evitar pérdidas.
            </li>
          </ol>
          <p style="font-size: 1.2em; max-width: 100%; text-align: left;">
            <strong>Opciones adicionales:</strong> 
          </p>
          <ul style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
            <li style="margin-bottom: 1em;">Haz clic en <strong>Agregar otro producto</strong> si deseas incluir más artículos en el mismo préstamo.</li>
            <li style="margin-bottom: 1em;">Selecciona <strong>Registrar Préstamo</strong> para guardar los datos en el sistema de manera definitiva.</li>
          </ul>
          <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
            Este módulo no solo permite un seguimiento detallado de los productos prestados, sino que también asegura una gestión eficiente de tus recursos. ¡Haz uso de esta herramienta para mantener el control total de tu inventario y evitar inconvenientes!
          </p>
        </div>
          <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/admin/admin 4.6.png" class="img-responsive" alt="Registrar préstamo de producto" style="width: 20%; margin-right: 10px;">
            <img src="uploads/admin/admin 4.6.1.png" class="img-responsive" alt="Formulario de préstamo" style="width: 75%;">
          </div>
        </div>
        <hr>
      </div>
    </div>
  </div>
</div>

<!-- Medicamentos -->
<div class="feature">
  <button class="btn btn-custom-5 btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#medications">Medicamentos</button>
  <div id="medications" class="collapse">

    <!-- Administrar Medicamentos -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#administrar_medications">Administrar Medicamentos</button>
      <div id="administrar_medications" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
        <div class="col-md-3" style="flex-grow: 1;">
          <h2 style="font-size: 2em; text-align: center;"><strong>Administrar Medicamentos</strong></h2>
          <p style="font-size: 1.2em; text-align: justify;">
            Bienvenido al módulo de <strong>Administración de Medicamentos</strong>, una herramienta indispensable para garantizar un manejo eficaz de los recursos farmacéuticos. Este espacio te permite consultar un listado completo con información clave sobre cada medicamento, incluyendo su <strong>cantidad actual</strong> y el <strong>nivel crítico de stock</strong> para evitar desabastecimientos.
          </p>
          <p style="font-size: 1.2em; text-align: justify;">
            Además, esta sección cuenta con <strong>filtros avanzados</strong> que te permiten buscar medicamentos específicos o categorizar información para agilizar la gestión. Ya sea por nombre, categoría o nivel de stock, esta funcionalidad está diseñada para adaptarse a tus necesidades.
          </p>
          <p style="font-size: 1.2em; text-align: justify;">
            ¿Necesitas agregar un nuevo medicamento? Con solo unos clics, podrás incluir nuevos elementos en tu inventario, asegurando que toda la información esté siempre actualizada y sea precisa.
          </p>
          <p style="font-size: 1.2em; text-align: justify;">
            Mantén el control absoluto de tus medicamentos con esta herramienta confiable y eficiente. Optimiza tu inventario y asegúrate de que nunca falte lo esencial para las operaciones diarias.
          </p>
        </div>
          <div class="col-md-9" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/admin/admin 5.1.png" class="img-responsive" alt="Listado de medicamentos" style="width: 10%; margin-right: 10px;">
            <img src="uploads/admin/admin 5.1.1.png" class="img-responsive" alt="Opciones de administración" style="width: 75%; margin-left: 10px;">
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Nuevo Medicamento -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#nuevo_medications">Nuevo Medicamento</button>
      <div id="nuevo_medications" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-9 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/admin/admin 5.2.png" class="img-responsive" alt="Registrar nuevo medicamento" style="width: 10%; margin-right: 10px;">
            <img src="uploads/admin/admin 5.2.1.png" class="img-responsive" alt="Formulario de registro" style="width: 75%;">
          </div>
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Registrar Nuevo Medicamento</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Bienvenido a la sección de <strong>Registro de Nuevos Medicamentos</strong>, diseñada para garantizar un manejo preciso y organizado de los recursos farmacéuticos. Aquí podrás ingresar información detallada de medicamentos clave, asegurando que tu inventario esté siempre actualizado.
            </p>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Sigue estos pasos para registrar un nuevo medicamento de forma rápida y sencilla:
            </p>
            <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
              <li style="margin-bottom: 1em;">
                <strong>Nombre del Medicamento:</strong> Proporciona el nombre completo y claro del medicamento que deseas registrar. Esto facilitará su búsqueda y referencia futura.
              </li>
              <li style="margin-bottom: 1em;">
                <strong>Categoría:</strong> Selecciona la categoría más adecuada para clasificar el medicamento. Esto ayuda a mantener tu inventario organizado por tipo o uso.
              </li>
              <li style="margin-bottom: 1em;">
                <strong>Cantidad:</strong> Indica el número inicial de unidades que se agregarán al inventario. Una cantidad precisa es crucial para garantizar el control del stock.
              </li>
              <li style="margin-bottom: 1em;">
                <strong>Nivel Crítico:</strong> Define un umbral mínimo para el stock. Cuando este nivel sea alcanzado, el sistema generará una alerta automática para reabastecimiento.
              </li>
            </ol>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Esta funcionalidad asegura que cada medicamento esté registrado de forma precisa y categorizada, facilitando la gestión de tus recursos farmacéuticos. ¡Haz de este módulo tu aliado en la administración eficiente del inventario!
            </p>
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Ingreso de Medicamento -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#ingreso_medications">Ingreso de Medicamento</button>
      <div id="ingreso_medications" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
        <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
              <h2 style="font-size: 2em; text-align: center;"><strong>Ingreso de Medicamento</strong></h2>
              <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
                El módulo de <strong>Ingreso de Medicamentos</strong>. Esta sección te permite registrar la entrada de medicamentos al inventario de manera eficiente y precisa, asegurando un control adecuado de tus recursos farmacéuticos.
              </p>
              <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
                Para completar el registro de nuevos medicamentos, sigue estos pasos:
              </p>
              <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
                <li style="margin-bottom: 1em;">
                  <strong>Medicamento:</strong> Introduce el nombre completo del medicamento que estás agregando al inventario. Asegúrate de que el nombre sea claro y preciso para facilitar su identificación.
                </li>
                <li style="margin-bottom: 1em;">
                  <strong>Cantidad:</strong> Especifica el número exacto de unidades que ingresan al inventario. Este dato es crucial para reflejar con precisión las existencias disponibles.
                </li>
              </ol>
              <p style="font-size: 1.2em; max-width: 100%; text-align: left;">
                <strong>Opciones adicionales:</strong>
              </p>
              <ul style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
                <li style="margin-bottom: 1em;">Selecciona <strong>Agregar otro medicamento</strong> si necesitas ingresar múltiples medicamentos en la misma operación.</li>
                <li style="margin-bottom: 1em;">Haz clic en <strong>Registrar Ingreso</strong> para guardar los cambios de manera definitiva en el sistema.</li>
              </ul>
              <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
                Este módulo está diseñado para agilizar y garantizar la precisión en la gestión de inventarios, permitiendo que siempre tengas un registro actualizado y confiable de los medicamentos disponibles. ¡Facilita tus operaciones y mantén un control óptimo de tus recursos con esta herramienta indispensable!
              </p>
            </div>
          <div class="col-md-9 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/admin/admin 5.3.png" class="img-responsive" alt="Registrar ingreso de medicamento" style="width: 10%; margin-right: 10px;">
            <img src="uploads/admin/admin 5.3.1.png" class="img-responsive" alt="Formulario de ingreso" style="width: 75%;">
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Egreso de Medicamento -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#egreso_medications">Egreso de Medicamento</button>
      <div id="egreso_medications" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/admin/admin 5.4.png" class="img-responsive" alt="Registrar egreso de medicamento" style="width: 20%; margin-right: 10px;">
            <img src="uploads/admin/admin 5.4.1.png" class="img-responsive" alt="Formulario de egreso" style="width: 75%;">
          </div>
          <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
            <h2 style="font-size: 2em; text-align: center;"><strong>Egreso de Medicamento</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
            En el módulo de <strong>Egreso de Medicamentos</strong>. Esta herramienta te permite registrar las salidas de medicamentos del inventario con rapidez y precisión, manteniendo un control estricto sobre tus recursos farmacéuticos.
            </p>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Para garantizar un registro correcto, sigue estos pasos detallados:
            </p>
            <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
              <li style="margin-bottom: 1em;">
                <strong>Medicamento:</strong> Introduce el nombre exacto del medicamento que deseas retirar del inventario. Este paso asegura un seguimiento correcto dentro del sistema.
              </li>
              <li style="margin-bottom: 1em;">
                <strong>Cantidad:</strong> Especifica el número de unidades que se están retirando. Este dato es crucial para reflejar con precisión las existencias restantes.
              </li>
            </ol>
            <p style="font-size: 1.2em; max-width: 100%; text-align: left;">
              <strong>Opciones adicionales:</strong>
            </p>
            <ul style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
              <li style="margin-bottom: 1em;">Selecciona <strong>Agregar otro medicamento</strong> si deseas registrar múltiples egresos en la misma operación.</li>
              <li style="margin-bottom: 1em;">Haz clic en <strong>Registrar Egreso</strong> para guardar los cambios en el sistema y mantener actualizado el inventario.</li>
            </ul>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Este módulo asegura que cada salida de medicamento sea documentada de manera eficiente, proporcionando un registro preciso para optimizar el manejo de tu inventario. ¡Mantén tus operaciones organizadas y asegúrate de que nada falte en tu inventario crítico!
            </p>
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Uso de Medicamento -->
    <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#uso_medicamento">Medicamento</button>
        <div id="uso_medicamento" class="collapse">
          <div class="feature row" style="display: flex; align-items: center; text-align: center;">
            <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
              <img src="uploads/admin/admin 5.5.png" class="img-responsive" alt="Instrucciones para registrar el uso de Medicamentos" style="width: 20%;">
              <img src="uploads/admin/admin 5.5.1.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
            </div>
            <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
  <h2 style="font-size: 2em; text-align: center;"><strong>Registro de Consumo de Medicamentos</strong></h2>
  <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
    En el módulo de <strong>Registro de Consumo de Medicamentos</strong>. Utiliza esta herramienta para llevar un control preciso sobre los medicamentos utilizados en tu inventario, garantizando una gestión eficiente y actualizada.
  </p>
  <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
    Para registrar el consumo de medicamentos, sigue estos pasos sencillos:
  </p>
  <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
    <li style="margin-bottom: 1em;">
      <strong>Nombre:</strong> Introduce el nombre completo del medicamento consumido (por ejemplo, "Paracetamol"). Esto permitirá una identificación rápida y precisa en el sistema.
    </li>
    <li style="margin-bottom: 1em;">
      <strong>Cantidad:</strong> Especifica la cantidad exacta de unidades consumidas (por ejemplo, "2"). Este dato es esencial para actualizar las existencias disponibles en el inventario.
    </li>
    <li style="margin-bottom: 1em;">
      <strong>Agregar otro medicamento:</strong> Haz clic en este botón si necesitas registrar el consumo de múltiples medicamentos antes de finalizar la operación.
    </li>
  </ol>
  <p style="font-size: 1.2em; max-width: 100%; text-align: left;">
    <strong>Registrar Uso:</strong> Una vez que todos los campos estén completados, selecciona esta opción para guardar los datos en el sistema de forma definitiva.
  </p>
  <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
    Este módulo ha sido diseñado para facilitar la administración de tu inventario, evitando errores y garantizando un control detallado de los medicamentos utilizados. ¡Optimiza tu gestión con esta herramienta intuitiva y confiable!
  </p>
</div>

          </div>
          <hr>
        </div>
  </div>
</div>


    <!-- Reportes -->
<div class="feature">
  <button class="btn btn-custom-6 btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#reportes">Reportes</button>
  <div id="reportes" class="collapse">

    <!-- Consumo -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#consumo"> Consumo</button>
      <div id="consumo" class="collapse">
        <div class="feature row" style="display: flex; align-items: center; text-align: center;">
          <div class="col-md-3" style="flex-grow: 1;">
          <h2 style="font-size: 2em; text-align: center;"><strong>Registro de Consumo</strong></h2>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              En esta sección de <strong>Consumo</strong>. Aquí podrás registrar y gestionar el uso de recursos esenciales de manera rápida y precisa. Mantener un control detallado del consumo te ayudará a optimizar la administración de tu inventario.
            </p>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Utiliza esta herramienta para obtener la información necesaria, como el nombre del recurso y la cantidad utilizada, garantizando que el sistema se mantenga actualizado.
            </p>
            <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
              Esta funcionalidad está diseñada para ofrecerte control total, mejorar la trazabilidad y garantizar la eficiencia en la gestión de tus recursos.
            </p>
          </div>
          <div class="col-md-9" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
            <img src="uploads/admin/admin 6.1.png" class="img-responsive" alt="" style="width: 10%; margin-right: 10px;">
            <img src="uploads/admin/admin 6.1.1.png" class="img-responsive" alt="" style="width: 75%; margin-left: 10px;">
          </div>
        </div>
        <hr>
      </div>
    </div>

    <!-- Historial del Inventario -->
    <div class="feature">
      <button class="btn btn-custom-gray btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#historial_movimientos">Historial de Movimientos</button>
      <div id="historial_movimientos" class="collapse">
        <div class="feature row">
        <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
          <img src="uploads/admin/admin 6.2.png" class="img-responsive" alt="Instrucciones para registrar advertencias" style="width: 20%;">
          <img src="uploads/admin/admin 6.2.1.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
        </div>
        <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
  <h2 style="font-size: 2em; text-align: center;"><strong>Historial de Movimientos</strong></h2>
  <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
    Este es el módulo de <strong>Historial de Movimientos</strong>, una herramienta esencial para supervisar y analizar la actividad de tu inventario. Aquí encontrarás un registro completo de todos los movimientos realizados, desde ingresos hasta egresos, garantizando una trazabilidad detallada de productos y medicamentos.
  </p>
  <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
    Utiliza los <strong>filtros avanzados</strong> disponibles para buscar y segmentar información relevante según tus necesidades. Puedes filtrar movimientos por:
  </p>
  <ul style="font-size: 1.2em; margin: 0 auto; text-align: left; list-style-position: inside;">
    <li style="margin-bottom: 1em;"><strong>Fecha:</strong> Visualiza transacciones específicas dentro de un rango temporal definido.</li>
    <li style="margin-bottom: 1em;"><strong>Tipo de Producto:</strong> Encuentra movimientos relacionados con medicamentos, insumos u otros recursos.</li>
    <li style="margin-bottom: 1em;"><strong>Cantidad:</strong> Identifica operaciones según la cantidad de unidades movidas.</li>
    <li style="margin-bottom: 1em;"><strong>Tipo de Movimiento:</strong> Clasifica transacciones como ingresos, egresos o préstamos.</li>
  </ul>
  <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
    Este módulo está diseñado para ofrecerte control total y garantizar una supervisión precisa de tu inventario. Analiza patrones, identifica tendencias y toma decisiones informadas con acceso a un historial transparente y organizado.
  </p>
</div>

        </div>
        <hr>
      </div>
    </div>
  </div>
</div>


<!--Advertencia -->
<div class="feature">
  <button class="btn btn-custom-7 btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#advertencia">Advertencia</button>
  <div id="advertencia" class="collapse">
    <div class="feature row">
      <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
        <img src="uploads/admin/admin 7.png" class="img-responsive" alt="Instrucciones para registrar advertencias" style="width: 20%;">
        <img src="uploads/admin/admin 7.1.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
      </div>
      <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
        <h2 style="font-size: 2em; text-align: center;"><strong>Reportar Advertencia</strong></h2>
        <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
          Este módulo está diseñado para que puedas <strong>resolver problemas críticos</strong> relacionados con la falta de insumos o medicamentos.
        </p>
        <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
          Sigue los pasos a continuación para resolver la advertencia de manera eficiente:
        </p>
        <p style="font-size: 1.2em; max-width: 100%; text-align: left;">
          <strong>Resolver Advertencia:</strong> Una vez presentado el reporte se podra tomar acciones segun la descripción del problema, selecciona esta opción para enviar el reporte al sistema.
        </p>
        <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
          Esta funcionalidad permite un monitoreo continuo de las necesidades del inventario, ayudando a evitar posibles interrupciones en las operaciones. ¡Reporta a tiempo y contribuye al flujo eficiente de recursos esenciales!
        </p>
      </div>
    </div>
  </div>
</div>


<!--Descarga -->
<div class="feature">
  <button class="btn btn-custom-8 btn-lg btn-block mb-2 btn-custom" data-toggle="collapse" data-target="#descarga">Descarga</button>
  <div id="descarga" class="collapse">
    <div class="feature row">
      <div class="col-md-5 text-center" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
        <img src="uploads/admin/admin 8.png" class="img-responsive" alt="Instrucciones para realizar descarga" style="width: 20%;">
        <img src="uploads/admin/admin 8.1.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
      </div>
      <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
        <h2 style="font-size: 2em; text-align: center;"><strong>Descarga de Bases de Datos</strong></h2>
        <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
          Accede fácilmente a la <strong>descarga de información clave</strong> desde el sistema. Esta opción está diseñada para permitirte almacenar y analizar los datos de tu inventario de manera conveniente, asegurando siempre que la información esté disponible cuando la necesites.
        </p>
        <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
          Selecciona el tipo de base de datos que deseas descargar según tus necesidades:
        </p>
        <ol style="font-size: 1.2em; margin-bottom: 1em; text-align: left; list-style-position: inside;">
          <li style="margin-bottom: 1em;">
            <strong>Productos:</strong> Descarga un listado completo de todos los productos en el inventario, con su uso con respecto del tiempo, los prestamos realizados a otras unidades y los movimientos que realiza en la bodega.
          </li>
          <li style="margin-bottom: 1em;">
            <strong>Medicamentos:</strong> Obtén un excel con el inventario de los medicamentos registrados, con su uso con respecto del tiempo y los movimientos que realiza en la bodega.
          <li style="margin-bottom: 1em;">
            <strong>Advertencias:</strong> Consulta el historial de reportes de problemas relacionados con insumos o medicamentos presentado por otros usuarios.
          </li>
        </ol>
        <p style="font-size: 1.2em; max-width: 100%; text-align: center;">
          Esta funcionalidad te proporciona un control total sobre la información del inventario.
        </p>
      </div>
    </div>
  </div>
</div>
<hr>

        <p style="font-size: 1.2em;">Utilice el menú de navegación lateral para acceder a las diferentes secciones de la plataforma. Si tiene alguna duda o problema, no dude en contactar con el soporte técnico.</p>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>

<?php include_once('layouts/footer.php'); ?>



<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cortina de Gatos y Perros</title>
  <style>
    .animated-pet {
      position: fixed;
      z-index: 9999;
    }
    .cat {
      width: 150px;
      height: auto;
    }
    .dog {
      width: 800px;
      height: auto;
    }
    .hidden {
      display: none;
    }
    #timer-circle {
      width: 40px;
      height: 40px;
      border: 1px solid #000;
      border-radius: 60%;
      display: inline-block;
      margin-left: 10px;
      position: relative;
      background: conic-gradient(black 0deg, black 0deg);
    }
    .btn-bonus {
      background-color:rgba(9, 71, 125, 0.96);
      border-color:rgb(12, 92, 177);
      color: white;
      font-size: 16px;
      padding: 10px 20px;
      border-radius: 5px;
      border: none;
      cursor: pointer;
      transition: background-color 0.3s ease, border-color 0.3s ease;
    }

    .btn-bonus:hover {
      background-color: #0056b3;
      border-color: #0056b3;
    }
  </style>
</head>
<body>
  <div id="animals-container"></div>
  <button id="toggle-button" class="btn-bonus">Bonus</button>
  <div id="timer-circle" class="hidden"></div>
</body>
</html>

  <script>
    let animalsActive = false;
    let loopInterval;
    const maxCats = 70; // Aumentado el número de gatos
    const maxDogs = 12; // Aumentado el número de perros
    const rowHeight = 120;
    const catRows = [0, 2, 4, 6];
    const dogRows = [1, 3, 5];
    const maxActiveAnimals = 20; // Aumentado el número máximo de animales activos
    let timerInterval;

    function toggleAnimals() {
      animalsActive = !animalsActive;
      const button = document.getElementById('toggle-button');
      const timerCircle = document.getElementById('timer-circle');
      button.textContent = animalsActive ? 'Desactivar' : 'Bonus';
      timerCircle.classList.toggle('hidden', !animalsActive);
      if (animalsActive) {
        startTimer();
        startAnimals();
      } else {
        stopAnimals();
      }
    }

    function startTimer() {
      let timeLeft = 20;
      const timerCircle = document.getElementById('timer-circle');
      timerInterval = setInterval(() => {
        timeLeft -= 1;
        const degrees = (timeLeft / 20) * 360;
        timerCircle.style.background = `conic-gradient(black ${degrees}deg, transparent ${degrees}deg)`;
        if (timeLeft <= 0) {
          clearInterval(timerInterval);
          stopAnimals(); // Parar los animales al finalizar el tiempo
        }
      }, 1000);
    }

    function startAnimals() {
  const catInterval = 300;  // Intervalo para los gatos
  const dogInterval = 2000; // Intervalo aumentado para los perros
  const startTime = Date.now();

  function animate() {
    if (!animalsActive) return;

    let activeAnimals = document.querySelectorAll('.animated-pet').length;
    if (activeAnimals >= maxActiveAnimals) {
      return;
    }

    for (let i = 0; i < maxCats; i++) {
      const row = catRows[i % catRows.length];
      createAnimal(i * catInterval, row * rowHeight, 'cat');
    }

    for (let i = 0; i < maxDogs; i++) {
      const row = dogRows[i % dogRows.length];
      createAnimal(i * dogInterval, row * rowHeight + 20, 'dog');
    }

    setTimeout(() => {
      const elapsedTime = Date.now() - startTime;
      if (elapsedTime < 20000 && animalsActive) {
        animate();
      }
    }, Math.max(maxCats * catInterval, maxDogs * dogInterval));
  }

  animate();
  loopInterval = setInterval(() => {
    if (animalsActive) {
      animate();
    }
  }, Math.max(maxCats * catInterval, maxDogs * dogInterval));
}

    function stopAnimals() {
      animalsActive = false;
      const button = document.getElementById('toggle-button');
      const timerCircle = document.getElementById('timer-circle');
      button.textContent = 'Bonus';
      button.disabled = false;
      clearInterval(loopInterval);
      clearInterval(timerInterval);
      document.getElementById('animals-container').innerHTML = '';
      timerCircle.classList.add('hidden');
    }

    function createAnimal(delay, topPosition, type) {
      const animalsContainer = document.getElementById('animals-container');
      const animal = document.createElement('div');
      animal.className = 'animated-pet ' + type;
      animal.style.top = `${topPosition}px`;

      if (type === 'cat') {
        animal.style.left = `${window.innerWidth}px`;
        animal.innerHTML = '<img src="https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExb3h2ZDhuYzRvYmp5MHQ0eTRnZGVrc2x4bDE5cGl3bmJ0bHNjZXFocCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/QcuzOd4rRLyLu/giphy.gif" alt="Gato" class="cat">';
      } else if (type === 'dog') {
        animal.style.left = `-${window.innerWidth}px`;
        animal.innerHTML = '<img src="https://media0.giphy.com/media/iEp5KdgmIMzz4u5jvI/giphy.gif" alt="Perro corriendo" class="dog">';
      }

      animalsContainer.appendChild(animal);

      setTimeout(() => {
        if (animalsActive) moveAnimal(animal, type);
      }, delay);
    }

    function moveAnimal(animal, type) {
      let startTime = null;
      const duration = 10000;
      const startLeft = type === 'cat' ? window.innerWidth : -animal.offsetWidth;
      const endLeft = type === 'cat' ? -animal.offsetWidth : window.innerWidth;

      function step(timestamp) {
        if (!startTime) startTime = timestamp;
        const progress = timestamp - startTime;
        const left = startLeft + ((endLeft - startLeft) * (progress / duration));
        animal.style.left = `${left}px`;
        if (progress < duration) {
          window.requestAnimationFrame(step);
        } else {
          if (animal.parentNode === animalsContainer) {
            animalsContainer.removeChild(animal);
          }
        }
      }

      window.requestAnimationFrame(step);
    }

    document.getElementById('toggle-button').addEventListener('click', toggleAnimals);
  </script>
</body>
</html>


