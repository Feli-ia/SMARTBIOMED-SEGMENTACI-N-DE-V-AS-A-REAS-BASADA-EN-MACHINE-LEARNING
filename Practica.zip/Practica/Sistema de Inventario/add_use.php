<?php
  $page_title = 'Agregar Préstamo de Insumo';
  require_once('includes/load.php');
  // Verificar el nivel de permiso del usuario para ver esta página
  page_require_level(3);
?>

<?php
  if(isset($_POST['add_loan'])){
    $req_fields = array('insumo', 'cantidad', 'encargado', 'unidad');
    validate_fields($req_fields);
    if(empty($errors)){
      $encargado  = $db->escape($_POST['encargado']);
      $paciente   = $db->escape($_POST['paciente']);
      $unidad     = $db->escape($_POST['unidad']);
      $loan_date  = make_date();
      
      // Loop through all insumo and cantidad fields
      for ($i = 0; $i < count($_POST['insumo']); $i++) {
        $insumo     = $db->escape((int)$_POST['insumo'][$i]);
        $cantidad   = $db->escape((int)$_POST['cantidad'][$i]);

        $sql  = "INSERT INTO loans (";
        $sql .= " insumo_id, cantidad, encargado, paciente, unidad, date";
        $sql .= ") VALUES (";
        $sql .= "'{$insumo}', '{$cantidad}', '{$encargado}', '{$paciente}', '{$unidad}', '{$loan_date}'";
        $sql .= ")";

        if(!$db->query($sql)){
          $session->msg('d', 'Lo siento, registro falló.');
          redirect('add_use.php', false);
        }

        // Update insumo quantity
        update_insumo_qty($cantidad, $insumo);
      }

      $session->msg('s', "Préstamo agregado correctamente.");
      redirect('add_use.php', false);
      
    } else {
      $session->msg("d", $errors);
      redirect('add_use.php', false);
    }
  }
?>

<?php include_once('layouts/header.php'); ?>
<div class="container">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-plus"></span>
          <span>Agregar Préstamo de Insumo</span>
        </strong>
      </div>
      <div class="panel-body">
        <form id="UsoForm" method="post" action="add_loan.php" onsubmit="event.preventDefault(); finalizarIngresoPrestamo();">
          <div id="UsoInsumosContainer">
            <div class="form-group">
              <label for="prestamoNombreInsumo">Nombre Insumo</label>
              <input type="text" class="UsoNombreInsumo form-control" list="insumosList" autocomplete="off" name="insumo[]" required>
              <label for="UsoCantidad">Cantidad</label>
              <input type="number" class="UsoCantidad form-control" min="0" step="1" name="cantidad[]" required>
            </div>
          </div>
          <button type="button" class="btn btn-primary" onclick="addPrestamoInsumo()">Añadir Otro Insumo</button>
          <div class="form-group">
            <label for="encargadoPrestamo">Encargado</label>
            <input type="text" id="encargadoPrestamo" class="form-control" name="encargado" required>
          </div>
          <div class="form-group">
            <label for="unidad">Box</label>
            <input type="text" id="unidad" class="form-control" name="unidad" required>
          </div>
          <button type="submit" name="add_loan" class="btn btn-primary">Registrar Uso</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<script src="path/to/your/js/functions.js"></script>
<script>
  function openModal() {
    document.getElementById('prestamoModal').style.display = 'flex';
  }

  function closeModal() {
    document.getElementById('prestamoModal').style.display = 'none';
  }

  function addPrestamoInsumo() {
    const container = document.getElementById('UsoInsumosContainer');
    const insumoDiv = document.createElement('div');
    insumoDiv.classList.add('form-group');
    insumoDiv.innerHTML = `
      <label>Nombre Insumo</label>
      <input type="text" class="UsoNombreInsumo form-control" list="insumosList" autocomplete="off" name="insumo[]" required>
      <label>Cantidad</label>
      <input type="number" class="UsoCantidad form-control" min="0" step="1" name="cantidad[]" required>
      <button type="button" class="btn btn-danger eliminar-boton" onclick="removeInsumo(this)">Eliminar</button>
    `;
    container.appendChild(insumoDiv);
  }

  function removeInsumo(button) {
    button.parentElement.remove();
  }

  function finalizarIngresoPrestamo() {
    document.getElementById('UsoForm').submit();
  }

  document.addEventListener('DOMContentLoaded', () => {
    const insumosList = document.getElementById('insumosList');
    inventario.forEach(item => {
        const option = document.createElement('option');
        option.value = item.product;
        insumosList.appendChild(option);
    });
    actualizarResumen();
  });

  // Adicionales funciones y eventos
  function setFechaHoraChile() {
    const ahora = new Date();
    const opciones = { timeZone: 'America/Santiago' };
    const formatoChile = new Intl.DateTimeFormat('es-CL', opciones);
    const fechaChile = new Date(ahora.toLocaleString('en-US', opciones));
    const año = fechaChile.getFullYear();
    const mes = String(fechaChile.getMonth() + 1).padStart(2, '0');
    const dia = String(fechaChile.getDate()).padStart(2, '0');
    const horas = String(fechaChile.getHours()).padStart(2, '0');
    const minutos = String(fechaChile.getMinutes()).padStart(2, '0');
    const segundos = String(fechaChile.getSeconds()).padStart(2, '0');
    const fechaHoraLocal = `${año}-${mes}-${dia}T${horas}:${minutos}:${segundos}`;
    const fechaHoraUso = document.getElementById('fechaHoraUso');
    fechaHoraUso.value = fechaHoraLocal;
  }

  document.addEventListener('DOMContentLoaded', () => {
    setFechaHoraChile();
    setInterval(setFechaHoraChile, 1000);
  });

  function cerrarSesion() {
    window.location.href = "index.html";
  }

  function cancelarFormulario() {
    const formulario = document.getElementById("prestamoForm");
    formulario.reset();
    closeModal();
  }

  document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("cancelar").addEventListener("click", cancelarFormulario);
  });

  function actualizarInventario(nombre, cantidad) {
    inventario.forEach(item => {
        if (item.product.trim().toLowerCase() === nombre.trim().toLowerCase()) {
            item.uso += cantidad;
        }
    });
  }

  function actualizarResumen() {
    const summaryTableBody = document.getElementById('summaryTableBody');
    summaryTableBody.innerHTML = '';
    inventario.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.product}</td>
            <td>${item.uso}</td>
        `;
        summaryTableBody.appendChild(row);
    });
  }

  function ordenarTabla() {
    const summaryTableBody = document.getElementById('summaryTableBody');
    const rows = Array.from(summaryTableBody.rows);
    rows.sort((a, b) => {
        const usoA = parseInt(a.cells[1].innerText);
        const usoB = parseInt(b.cells[1].innerText);
        return usoB - usoA;
    });
    rows.forEach(row => summaryTableBody.appendChild(row));
  }
</script>

<datalist id="insumosList"></datalist>

<?php include_once('layouts/footer.php'); ?>
