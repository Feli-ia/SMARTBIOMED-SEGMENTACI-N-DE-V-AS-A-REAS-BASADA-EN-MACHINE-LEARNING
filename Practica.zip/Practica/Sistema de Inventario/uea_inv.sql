  -- phpMyAdmin SQL Dump
  -- version 4.5.1
  -- http://www.phpmyadmin.net
  --
  -- Servidor: 127.0.0.1
  -- Tiempo de generación: 16-06-2017 a las 07:12:59
  -- Versión del servidor: 10.1.19-MariaDB
  -- Versión de PHP: 7.0.13

  SET @@SESSION.SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
  SET time_zone = '+00:00';

  /*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
  /*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
  /*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
  /*!40101 SET NAMES utf8mb4 */;

  --
  -- Base de datos: `uea_inv`
  --

  -- --------------------------------------------------------

  --
  -- Estructura de tabla para la tabla `products`
  --

  USE uea_inv;

  CREATE TABLE IF NOT EXISTS `products` (
    `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `categorie` varchar(60) NOT NULL,  -- Almacenamos el nombre de la categoría como texto
    `quantity` varchar(50) DEFAULT NULL,
    `nivel_critico` INT(11) DEFAULT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;



  -- Crear una tabla temporal para cargar los datos desde el archivo CSV
  CREATE TEMPORARY TABLE temp_products (
    id INT(11) UNSIGNED,
    name VARCHAR(255),
    categorie VARCHAR(60),  -- Almacenamos el nombre de la categoría como texto
    quantity VARCHAR(50),
    nivel_critico INT(11)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;




  -- Cargar los datos desde el archivo CSV a la tabla temporal
  LOAD DATA INFILE 'C:/xampp/htdocs/Sistema de Inventario/Sistema de Inventario/products.csv'
  INTO TABLE temp_products
  FIELDS TERMINATED BY ';'
  LINES TERMINATED BY '\n'
  (id, name, categorie, quantity, nivel_critico);


  -- Insertar los datos en la tabla `products` y actualizar los duplicados
  INSERT INTO products (id, name, categorie, quantity, nivel_critico)
  SELECT tp.id, tp.name, tp.categorie, tp.quantity, tp.nivel_critico
  FROM temp_products tp
  ON DUPLICATE KEY UPDATE 
    name = VALUES(name),
    categorie = VALUES(categorie),
    quantity = VALUES(quantity),
    nivel_critico = VALUES(nivel_critico);

  -- Eliminar la tabla temporal
  DROP TEMPORARY TABLE temp_products;





  -- --------------------------------------------------------

  --
  -- Estructura de tabla para la tabla `users`
  --

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_level` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

  --
  -- Volcado de datos para la tabla `users`
  --

-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `user_level`, `status`, `last_login`) VALUES
  (1, 'Admin Users', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 1, 1, '2025-03-05 07:11:03'),
  (2, 'Special User', 'special', 'ba36b97a41e7faf742ab09bf88405ac04f99599a', 2, 1, '2025-03-05 07:11:03'),
  (3, 'Default User', 'user', '12dea96fec20593566ab75692c9949596833adc9', 3, 1, '2025-03-05 07:11:03'),
  (9, 'Supervisora UEA', 'supervisorauea', '80ac92917c817f3cda2f17a9f1b8111275c2c1f0', 1, 1, '2025-03-05 07:11:03'),
  (10, 'Box 1', 'box1', '31db3a06052d24455d217255d55c0d27efc359a3', 3, 1, '2025-03-05 07:11:03'),
  (11, 'Box 2', 'box2', '15b1faae289101c39eeedc39406742e7510c2e4c', 3, 1, '2025-03-05 07:11:03'),
  (12, 'Sala Mixto 1', 'salamixto1', 'f03d0db884519dfe63d9170d42154ecd15443724', 3, 1, '2025-03-05 07:11:03'),
  (13, 'Sala Mixto 2', 'salamixto2', '675001b144898eed573d741ff4be963ca08f8e36', 3, 1, '2025-03-05 07:11:03'),
  (14, 'Sala Mixto 3', 'salamixto3', 'cb479c954816bdf5e7da3dbb14deffc3d51b0050', 3, 1, '2025-03-05 07:11:03'),
  (15, 'Box Dental', 'boxdental', '9ad733f6061ccd6d51e3c021d312b341d46326f0', 3, 1, '2025-03-05 07:11:03'),
  (16, 'Box REA', 'boxrea', '2bff55a5747069f3267f916723f2f5da98461320', 3, 1, '2025-03-05 07:11:03'),
  (17, 'Box Priorizador', 'boxpriorizador', '34a12c9bedfcd47c33b6838f9ab50e2f7c146dca', 3, 1, '2025-03-05 07:11:03'),
  (18, 'Box de material', 'boxdematerial', 'fba7af10966f2764ab503a2066707e9441ea8b9d', 3, 1, '2025-03-05 07:11:03'),
  (19, 'Box REA respiratorio', 'boxrearespiratorio', 'ee0e9d281bcd4cb12b49f7e2b45207d3a7dcbd08', 3, 1, '2025-03-05 07:11:03'),
  (20, 'Sala de Procedimiento Quirurgico', 'saladeprocedimientoquirurgico', 'f30ace7fd0c1bfe46d539a022172634910622b2c', 3, 1, '2025-03-05 07:11:03'),
  (21, 'Bodega UEA', 'bodegauea', 'adf17555024b8ff98c677eaf245dd79e38ecb7fa ', 2, 1, '2025-03-05 07:11:03');

  -- --------------------------------------------------------

  --
  -- Estructura de tabla para la tabla `user_groups`
  --

  CREATE TABLE `user_groups` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `group_name` varchar(150) NOT NULL,
    `group_level` int(11) NOT NULL,
    `group_status` int(1) NOT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

  --
  -- Volcado de datos para la tabla `user_groups`
  --

  INSERT INTO `user_groups` (`id`, `group_name`, `group_level`, `group_status`) VALUES
  (1, 'Admin', 1, 1),
  (2, 'Special', 2, 0),
  (3, 'User', 3, 1);

  -- --------------------------------------------------------

  --
  -- Estructura de tabla para la tabla `product_loans`
  --

CREATE TABLE `product_loans` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `product_id` INT(11) UNSIGNED NOT NULL,
    `quantity` INT NOT NULL,
    `borrower_name` VARCHAR(255) NOT NULL,
    `user_id` INT(11) UNSIGNED NOT NULL,
    `user` VARCHAR(255) NOT NULL,
    `date` DATETIME NOT NULL,
    `type` VARCHAR(10) NOT NULL DEFAULT 'Egreso',
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


  -- --------------------------------------------------------

  --
  -- Estructura de tabla para la tabla `product_usage`
  --

CREATE TABLE `product_usage` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `product_id` INT(11) UNSIGNED NOT NULL,
    `user_id` INT(11) UNSIGNED NOT NULL,
    `user` VARCHAR(255) NOT NULL,
    `quantity` INT NOT NULL,
    `date` DATETIME NOT NULL,
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

  -- --------------------------------------------------------

  --
  -- Estructura de tabla para la tabla `medicamentos`
  --

  CREATE TABLE IF NOT EXISTS `medicamentos` (
    `nombre` varchar(255) NOT NULL,
    `cantidad` bigint(20) NOT NULL,
    `nivel_critico_med` INT(11) DEFAULT NULL,
    PRIMARY KEY (`nombre`)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

  -- Crear una tabla temporal para cargar los datos desde el archivo CSV
  CREATE TEMPORARY TABLE temp_medicamentos (
    nombre VARCHAR(255),
    cantidad BIGINT(20),
    nivel_critico_med INT(11)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

  -- Cargar los datos desde el archivo CSV a la tabla temporal
  LOAD DATA INFILE 'C:/xampp/htdocs/Sistema de Inventario/Sistema de Inventario/medicamentos.csv'
  INTO TABLE temp_medicamentos
  FIELDS TERMINATED BY ','
  ENCLOSED BY '"' 
  LINES TERMINATED BY '\n'
  (nombre, cantidad, nivel_critico_med);

  -- Insertar los datos en la tabla `medicamentos` y actualizar los duplicados
  INSERT INTO medicamentos (nombre, cantidad, nivel_critico_med)
  SELECT tm.nombre, tm.cantidad, tm.nivel_critico_med
  FROM temp_medicamentos tm
  ON DUPLICATE KEY UPDATE 
    cantidad = VALUES(cantidad),
    nivel_critico_med = VALUES(nivel_critico_med);

  -- Eliminar la tabla temporal
  DROP TEMPORARY TABLE temp_medicamentos;

  -- --------------------------------------------------------

  --
  -- Estructura de tabla para la tabla `medicine_usage`
  --

CREATE TABLE IF NOT EXISTS `medicine_usage` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `medicine` varchar(255) NOT NULL,
    `user_id` int(11) UNSIGNED NOT NULL,
    `user` varchar(255) NOT NULL,
    `quantity` int(11) NOT NULL,
    `date` datetime NOT NULL,
    FOREIGN KEY (`medicine`) REFERENCES `medicamentos`(`nombre`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


  -- --------------------------------------------------------

  --
  -- Estructura de tabla para la tabla `warnings`
  --

    CREATE TABLE `warnings` (
      `id` INT AUTO_INCREMENT PRIMARY KEY,
      `user_id` INT(11) UNSIGNED NOT NULL,
    `user` VARCHAR(255) NOT NULL,
      `description` TEXT NOT NULL,
      `date` DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

  -- --------------------------------------------------------

  --
  -- Estructura de tabla para la tabla `product_movements`
  --

  CREATE TABLE IF NOT EXISTS `product_movements` (
      id INT AUTO_INCREMENT PRIMARY KEY,
      product_id INT(11) UNSIGNED NOT NULL,
      quantity INT NOT NULL,
      date DATE NOT NULL,
      type ENUM('Ingreso', 'Egreso') NOT NULL,
      category VARCHAR(50) NOT NULL,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE ON UPDATE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

  -- --------------------------------------------------------

  --
  -- Estructura de tabla para la tabla `medicine_movements`
  --

  CREATE TABLE IF NOT EXISTS `medicine_movements` (
      id INT AUTO_INCREMENT PRIMARY KEY,
      medicine_name VARCHAR(255) NOT NULL,
      quantity INT NOT NULL,
      date DATE NOT NULL,
      type ENUM('Ingreso', 'Egreso') NOT NULL,
      category VARCHAR(50) NOT NULL,
      FOREIGN KEY (medicine_name) REFERENCES medicamentos(nombre) ON DELETE CASCADE ON UPDATE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;



  CREATE TABLE IF NOT EXISTS `categories` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

  INSERT INTO `categories` (`name`) VALUES
  ('Insumos'),
  ('Economato'),
  ('Esterilización'),
  ('Medicamentos');


  CREATE TABLE IF NOT EXISTS `uses` (
      `id` INT AUTO_INCREMENT PRIMARY KEY,
      `product_id` INT(11) UNSIGNED NOT NULL,
      `quantity` INT NOT NULL,
      `user_id` INT(11) UNSIGNED NOT NULL,
      `date` DATETIME NOT NULL,
      FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
      FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `activity_log` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) UNSIGNED NOT NULL,
  `action` VARCHAR(255) NOT NULL,
  `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


  -- --------------------------------------------------------

  --
  -- Índices para tablas volcadas
  --

  --
  -- Índices de la tabla `products`
  --
  ALTER TABLE `products`
    ADD UNIQUE KEY `name` (`name`),
    ADD KEY `categorie` (`categorie`);

  --
  -- Índices de la tabla `product_movements `
  --
  
  ALTER TABLE product_movements 
    ADD COLUMN user_id INT(11) UNSIGNED NOT NULL;


  --
  -- Índices de la tabla `users`
  --
  ALTER TABLE `users`
    ADD UNIQUE KEY `username` (`username`),
    ADD KEY `user_level` (`user_level`);

  --
  -- Índices de la tabla `user_groups`
  --
  ALTER TABLE `user_groups`
    ADD UNIQUE KEY `group_level` (`group_level`);

  --
  -- Índices de la tabla `medicine_usage`
  --
  ALTER TABLE `medicine_usage`
    ADD KEY `medicine_usage_medicine` (`medicine`);


  ALTER TABLE `uses`
  ADD COLUMN `qty` INT NOT NULL;


  --
  -- AUTO_INCREMENT de las tablas volcadas
  --

  ALTER TABLE `products`
    MODIFY `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

  ALTER TABLE `users`
    MODIFY `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

  ALTER TABLE `user_groups`
    MODIFY `id` INT(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

  ALTER TABLE `medicine_usage`
    MODIFY `id` INT NOT NULL AUTO_INCREMENT;

  ALTER TABLE `product_loans`
    MODIFY `id` INT NOT NULL AUTO_INCREMENT;

  ALTER TABLE `product_usage`
    MODIFY `id` INT NOT NULL AUTO_INCREMENT;

  --
  -- Restricciones para tablas volcadas
  --

  ALTER TABLE `users`
    ADD CONSTRAINT `FK_user` FOREIGN KEY (`user_level`) REFERENCES `user_groups` (`group_level`) ON DELETE CASCADE ON UPDATE CASCADE;

  ALTER TABLE `product_loans`
    ADD KEY `product_id` (`product_id`);

  ALTER TABLE `product_usage`
    ADD KEY `product_id` (`product_id`),
    ADD KEY `user_id` (`user_id`);

  ALTER TABLE `medicamentos`
    ADD UNIQUE KEY `nombre` (`nombre`);

