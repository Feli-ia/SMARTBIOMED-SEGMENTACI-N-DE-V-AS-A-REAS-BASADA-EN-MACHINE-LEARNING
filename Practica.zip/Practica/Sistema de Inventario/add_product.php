<?php
$page_title = 'Ingresar Producto';
require_once('includes/load.php');
// Verifica qué nivel de usuario tiene permiso para ver esta página
page_require_level(2);

// Obtener todos los productos para el autocompletado
$all_products = find_all('products');

// Manejar la solicitud de ingreso de productos
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $req_fields = ['name', 'quantity'];
    validate_fields($req_fields);

    if (empty($errors)) {
        $names = $_POST['name'];
        $quantities = $_POST['quantity'];
        $date = make_date();
        $user_id = current_user_id();
        
        // Comenzar transacción
        $db->query("START TRANSACTION");
        
        try {
            foreach ($names as $index => $name) {
                $name = remove_junk($db->escape($name));
                $quantity = (int)$quantities[$index];
                
                // Verifica si el producto existe
                $existing_product = find_by_sql("SELECT * FROM products WHERE name='{$name}' LIMIT 1");
                if ($existing_product) {
                    // Suma la cantidad ingresada a la cantidad existente
                    $new_quantity = (int)$existing_product[0]['quantity'] + $quantity;
                    $query  = "UPDATE products SET quantity={$new_quantity} WHERE name='{$name}'";
                    $db->query($query);
                    $product_id = $existing_product[0]['id'];
                    
                    // Registrar el movimiento en la tabla 'product_movements'
                    $movement_query = "INSERT INTO product_movements (product_id, quantity, date, type, category) VALUES ({$product_id}, {$quantity}, '{$date}', 'Ingreso', 'Producto')";
                    if (!$db->query($movement_query)) {
                        throw new Exception('Falló al registrar el movimiento del producto.');
                    }
                } else {
                    throw new Exception('El producto no existe.');
                }
            }
            // Confirmar transacción
            $db->query("COMMIT");
            $session->msg('s', "Productos ingresados y movimientos registrados exitosamente.");
        } catch (Exception $e) {
            // Revertir transacción
            $db->query("ROLLBACK");
            $session->msg('d', $e->getMessage());
        }
        
        redirect('enter_product.php', false);
    } else {
        $session->msg("d", $errors);
        redirect('enter_product.php', false);
    }
}

include_once('layouts/header.php');
?>

<div class="container">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-log-in"></span>
          <span>Ingresar Productos</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="enter_product.php" class="clearfix">
          <div id="product-fields">
            <div class="product-field">
              <div class="form-group">
                <label for="name" class="control-label">Nombre</label>
                <input type="text" class="form-control product_id_input" name="name[]" placeholder="Nombre del producto" required>
                <ul class="dropdown-menu product_list"></ul>
              </div>
              <div class="form-group">
                <label for="quantity" class="control-label">Cantidad</label>
                <input type="number" class="form-control" name="quantity[]" min="1" placeholder="Cantidad utilizada" required>
              </div>
              <button type="button" class="remove-product btn btn-danger">Eliminar</button>
            </div>
          </div>
          <div class="form-group">
            <button type="button" id="add-product" class="btn btn-success">Agregar otro producto</button>
          </div>
          <div class="form-group">
            <button type="submit" name="enter" class="btn btn-primary">Ingresar Productos</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const allProducts = <?php echo json_encode($all_products); ?>;

  function setupProductAutocomplete(container) {
    const productInput = container.querySelector('.product_id_input');
    const productList = container.querySelector('.product_list');

    productInput.addEventListener('input', function() {
      const userInput = productInput.value.toLowerCase();
      productList.innerHTML = '';
      if (userInput) {
        const filteredOptions = allProducts.filter(product => product.name.toLowerCase().includes(userInput));
        filteredOptions.forEach(product => {
          const option = document.createElement('li');
          option.className = 'dropdown-item';
          option.textContent = product.name;
          option.dataset.id = product.id;
          option.addEventListener('click', function() {
            productInput.value = product.name;
            productList.innerHTML = '';
          });
          productList.appendChild(option);
        });
        productList.style.display = 'block';
      } else {
        productList.style.display = 'none';
      }
    });

    document.addEventListener('click', function(event) {
      if (!productInput.contains(event.target) && !productList.contains(event.target)) {
        productList.style.display = 'none';
      }
    });
  }

  document.querySelectorAll('.product-field').forEach(setupProductAutocomplete);

  document.getElementById('add-product').addEventListener('click', function() {
    const productFields = document.getElementById('product-fields');
    const newFields = document.createElement('div');
    newFields.className = 'product-field';
    newFields.innerHTML = `
      <div class="form-group">
        <label for="name" class="control-label">Nombre</label>
        <input type="text" class="form-control product_id_input" name="name[]" placeholder="Nombre del producto" required>
        <ul class="dropdown-menu product_list"></ul>
      </div>
      <div class="form-group">
        <label for="quantity" class="control-label">Cantidad</label>
        <input type="number" class="form-control" name="quantity[]" min="1" placeholder="Cantidad utilizada" required>
      </div>
      <button type="button" class="remove-product btn btn-danger">Eliminar</button>
    `;
    productFields.appendChild(newFields);
    setupProductAutocomplete(newFields);
    attachRemoveEvent();
    updateRemoveButtons();
  });

  function attachRemoveEvent() {
    document.querySelectorAll('.remove-product').forEach(button => {
      button.addEventListener('click', function() {
        button.closest('.product-field').remove();
        updateRemoveButtons();
      });
    });
  }

  function updateRemoveButtons() {
    const removeButtons = document.querySelectorAll('.remove-product');
    removeButtons.forEach((button, index) => {
      button.style.display = index < 1 ? 'none' : 'block'; // Ocultar el botón de eliminar si hay menos de 2 campos
    });
  }

  attachRemoveEvent();
  updateRemoveButtons();
});
</script>
