<ul class="nav flex-column">
  <li class="nav-item">
    <a href="home_special.php">
      <i class="glyphicon glyphicon-info-sign"></i>
      <span>Información</span>
    </a>
  </li>
  <li class="nav-item">
    <a href="#" class="nav-link submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Productos</span>
    </a>
    <ul class="nav flex-column ms-3 submenu">
      <li class="nav-item"><a href="product.php" class="nav-link">Administrar productos</a></li>
      <li class="nav-item"><a href="add_new_product.php" class="nav-link">Nuevo producto</a></li>
      <li class="nav-item"><a href="add_product.php" class="nav-link">Ingreso productos</a></li>
      <li class="nav-item"><a href="exit_product.php" class="nav-link">Egreso productos</a></li>
      <li class="nav-item"><a href="add_loan.php" class="nav-link">Préstamo de productos</a></li>
    </ul>
  </li>
  <li class="nav-item">
    <a href="#" class="nav-link submenu-toggle">
      <i class="glyphicon glyphicon-heart"></i>
      <span>Medicamentos</span>
    </a>
    <ul class="nav flex-column ms-3 submenu">
      <li class="nav-item"><a href="medicine.php" class="nav-link">Administrar medicamentos</a></li>
      <li class="nav-item"><a href="add_new_medicine.php" class="nav-link">Nuevo medicamento</a></li>
      <li class="nav-item"><a href="add_medicine.php" class="nav-link">Ingreso medicamentos</a></li>
      <li class="nav-item"><a href="exit_medicine.php" class="nav-link">Egreso medicamentos</a></li>
    </ul>
  </li>
  <li class="nav-item">
    <a href="movement_history.php" class="nav-link">
      <i class="glyphicon glyphicon-signal"></i>
      <span>Historial</span>
    </a>
  </li>
  <li class="nav-item">
    <a href="report_missing.php" class="nav-link">
      <i class="glyphicon glyphicon-warning-sign"></i>
      <span>Advertencias</span>
    </a>
  </li>
</ul>
