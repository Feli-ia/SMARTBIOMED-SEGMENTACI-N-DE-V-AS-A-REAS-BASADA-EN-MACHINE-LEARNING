<?php include_once('includes/load.php'); ?>
<?php
$req_fields = array('username', 'password');
validate_fields($req_fields);
$username = remove_junk($_POST['username']);
$password = remove_junk($_POST['password']);

if (empty($errors)) {
  $user_id = authenticate($username, $password);
  if ($user_id) {
    // Crear sesión con id
    $session->login($user_id);
    // Actualizar hora de inicio de sesión
    updateLastLogIn($user_id);
    $session->msg("s", "Bienvenido de nuevo.");

    // Obtener el nivel del usuario y redirigir a la página correspondiente
    $user_level = getUserLevel($user_id);
    switch ($user_level) {
      case '1':
        redirect('home_admin.php', false);
        break;
      case '2':
        redirect('home_special.php', false);
        break;
      case '3':
        redirect('home_user.php', false);
        break;
      default:
        // Redirigir a una página de error o de inicio de sesión
        redirect('login_v2.php', false);
    }
  } else {
    error_log("Fallo en la autenticación para el usuario: $username");
    $session->msg("d", "Nombre de usuario y/o contraseña incorrecto.");
    redirect('index.php', false);
  }
} else {
  $session->msg("d", $errors);
  redirect('index.php', false);
}
?>
