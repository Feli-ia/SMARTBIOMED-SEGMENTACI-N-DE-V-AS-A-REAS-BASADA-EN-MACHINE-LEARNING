<?php
require_once('includes/load.php');

if (isset($_GET['term']) && !empty($_GET['term'])) {
    $term = $db->escape($_GET['term']);
    $sql = "SELECT name FROM products WHERE name LIKE '%{$term}%' LIMIT 10";
    $result = $db->query($sql);
    
    $product_list = array();
    while ($row = $db->fetch_assoc($result)) {
        $product_list[] = $row['name'];
    }
    
    echo json_encode($product_list);
} else {
    echo json_encode([]);
}
?>
