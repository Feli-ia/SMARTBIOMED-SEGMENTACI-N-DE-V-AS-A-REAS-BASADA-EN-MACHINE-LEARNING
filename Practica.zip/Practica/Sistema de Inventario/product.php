<?php
$page_title = 'Administrar Inventario de Productos';
require_once('includes/load.php');
require_once('includes/functions.php'); // Usa require_once para evitar múltiples declaraciones

// Verifica qué nivel de usuario tiene permiso para ver esta página
page_require_level(2);

// Número de productos por página
$products_per_page = 15;

// Inicializar los filtros con valores predeterminados
$search_name = '';
$min_quantity = 0;
$critical_only = false;
$sort_by = 'default';
$order = 'asc';
$selected_category = '';

// Definir las categorías directamente en el código
$categories = [
  ['nombre' => 'Insumos'],
  ['nombre' => 'Economato'],
  ['nombre' => 'Esterilización']
];

// Recuperar filtros de búsqueda de la URL
if ($_SERVER["REQUEST_METHOD"] == "GET") {
  if (isset($_GET['search_name'])) {
    $search_name = $_GET['search_name'];
  }
  if (isset($_GET['min_quantity'])) {
    $min_quantity = (int)$_GET['min_quantity'];
  }
  if (isset($_GET['critical_only'])) {
    $critical_only = (bool)$_GET['critical_only'];
  }
  if (isset($_GET['category'])) {
    $selected_category = $_GET['category'];
  }
  if (isset($_GET['sort_order'])) {
    $sort_order = $_GET['sort_order'];
    if ($sort_order == 'cantidad_asc') {
      $sort_by = 'quantity';
      $order = 'asc';
    } elseif ($sort_order == 'cantidad_desc') {
      $sort_by = 'quantity';
      $order = 'desc';
    } else {
      $sort_by = 'default';
      $order = 'asc';
    }
  }
}

// Obtener el número total de productos con filtros aplicados
$total_products = count_products_with_filters('products', $search_name, $min_quantity, $critical_only, $selected_category);
if ($total_products === false) {
  die("Error al contar los productos.");
}
$total_pages = ceil($total_products / $products_per_page);

// Obtener la página actual desde la URL, por defecto es la página 1
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $products_per_page;

// Construir la consulta con los filtros aplicados
$all_products = find_products_with_filters('products', $search_name, $min_quantity, $products_per_page, $offset, $critical_only, $selected_category, $sort_by, $order);
if ($all_products === false) {
  die("Error al obtener los productos.");
}

// Actualizar el nivel crítico si se envía el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $codigo = $_POST['codigo'];
  $nivel_critico = $_POST['nivel_critico'];

  // Preparar la declaración SQL para evitar inyección de SQL
    $query = "UPDATE products SET nivel_critico = ? WHERE id = ?";
    if ($stmt = $db->prepare($query)) {
      $stmt->bind_param('ii', $nivel_critico, $codigo);
      if ($stmt->execute()) {
        $session->msg("s", "Nivel crítico actualizado correctamente.");
      } else {
        $session->msg("d", "Error al actualizar el nivel crítico.");
      }
      $stmt->close();
    } else {
      $session->msg("d", "Error al preparar la consulta SQL.");
    }
    redirect('product.php', false);
  }
  
  include_once('layouts/header.php'); 
  ?>
  
      <!-- Filtros -->
      <div class="col-md-3">
        <div class="panel panel-default" style= "width: 300px">
          <div class="panel-heading">
            <strong>Filtros</strong>
          </div>
          <div class="panel-body">
            <form id="filter-form" method="get" action="product.php">
              <div class="form-group">
                <label for="search_name">Nombre del Producto:</label>
                <input type="text" class="form-control" name="search_name" value="<?php echo $search_name; ?>" placeholder="Buscar por nombre" onkeydown="if (event.key === 'Enter') { event.preventDefault(); this.form.submit(); }">
              </div>
              <div class="form-group">
                <label for="min_quantity">Cantidad Mínima:</label>
                <input type="number" class="form-control" name="min_quantity" value="<?php echo $min_quantity; ?>" placeholder="Buscar por cantidad mínima" onkeydown="if (event.key === 'Enter') { event.preventDefault(); this.form.submit(); }">
              </div>
              <div class="form-group">
                <label for="critical_only">Mostrar solo críticos:</label>
                <div class="checkbox">
                  <label>
                    <input type="checkbox" name="critical_only" style="transform: scale(1.5); margin: 5px;"<?php echo $critical_only ? 'checked' : ''; ?> onchange="this.form.submit()"> Sí
                  </label>
                </div>
              </div>
              <div class="form-group">
                <label for="category">Categoría:</label>
                <select class="form-control" name="category" onchange="this.form.submit()">
                  <option value="">Todas las categorías</option>
                  <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category['nombre']; ?>" <?php echo $selected_category == $category['nombre'] ? 'selected' : ''; ?>>
                      <?php echo $category['nombre']; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="form-group">
                <label for="sort_order">Ordenar por:</label>
                <select class="form-control" name="sort_order" onchange="this.form.submit()">
                  <option value="default" <?php echo $sort_by == 'default' ? 'selected' : ''; ?>>Por defecto</option>
                  <option value="cantidad_asc" <?php echo $sort_by == 'quantity' && $order == 'asc' ? 'selected' : ''; ?>>Cantidad (Ascendente)</option>
                  <option value="cantidad_desc" <?php echo $sort_by == 'quantity' && $order == 'desc' ? 'selected' : ''; ?>>Cantidad (Descendente)</option>
                </select>
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block">Buscar</button>
              </div>
            </form>
          </div>
        </div>
      </div>


<div class="col-md-9">
<div class="container-fluid" style="margin-left: -210px;">
  <div class="panel panel-default">
    <div class="panel-heading">
    <strong>
        <span class="glyphicon glyphicon-th"></span>
        <span>Inventario de Productos</span>
        <a href="add_new_product.php" class="btn btn-primary pull-right">Nuevo Producto</a>
      </strong>
    </div>

      <!-- Paginación -->
      <nav aria-label="Page navigation" style="margin-left: 16px">
            <ul class="pagination">
            <?php if($current_page > 1): ?>
              <li><a href="?page=1&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="First"><span aria-hidden="true">&laquo;&laquo;</span></a></li>
              <li><a href="?page=<?php echo $current_page - 1; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
              <?php endif; ?>

              <?php for($i = 1; $i <= $total_pages; $i++): ?>
                <li class="<?php echo $current_page == $i ? 'active' : ''; ?>"><a href="?page=<?php echo $i; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>"><?php echo $i; ?></a></li>
                <?php endfor; ?>

                <?php if($current_page < $total_pages): ?>
              <li><a href="?page=<?php echo $current_page + 1; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>
              <li><a href="?page=<?php echo $total_pages; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Last"><span aria-hidden="true">&raquo;&raquo;</span></a></li>
           <?php endif; ?>
            </ul>
          </nav>  
          
  <!-- Tabla de Productos -->
    <div class="panel-body">
      <?php if($all_products): ?>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th class="text-center">Código</th>
            <th class="text-center">Nombre</th>
            <th class="text-center">Categoría</th>
            <th class="text-center">Cantidad</th>
            <th class="text-center">Stock Crítico</th>
            <th class="text-center">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($all_products as $product): ?>
            <tr class="<?php echo (isset($product['quantity']) && $product['quantity'] <= $product['nivel_critico']) ? 'danger' : ''; ?>">
              <td class="text-center"><?php echo isset($product['id']) ? remove_junk($product['id']) : 'Código no definido'; ?></td>
              <td class="text-center" style="width: 500px;"><?php echo isset($product['name']) ? remove_junk($product['name']) : 'Nombre no definido'; ?></td>
              <td class="text-center"><?php echo isset($product['categorie']) ? remove_junk($product['categorie']) : 'Categoría no definida'; ?></td>
              <td class="text-center"><?php echo isset($product['quantity']) ? (int)$product['quantity'] : 'Cantidad no definida'; ?></td>
              <td class="text-center">
                <form action="product.php" method="post" class="form-inline">
                  <input type="hidden" name="codigo" value="<?php echo $product['id']; ?>">
                  <div class="form-group">
                    <label for="nivel_critico">Nivel Crítico:</label>
                    <input type="number" class="form-control input-sm" name="nivel_critico" value="<?php echo isset($product['nivel_critico']) ? (int)$product['nivel_critico'] : ''; ?>" required style="width: 80px;">
                    <button type="submit" class="btn btn-custom-1 btn-sm" style="margin-left: 5px;">Actualizar</button>
                  </div>
                </form>
              </td>
              <td class="text-center">
                <div class="btn-group" role="group">
                  <a href="add_product.php?id=<?php echo urlencode($product['id']); ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&category=<?php echo urlencode($selected_category); ?>&sort_order=<?php echo urlencode($sort_order); ?>&page=<?php echo urlencode($current_page); ?>" class="btn btn-success btn-sm" title="Agregar producto" data-toggle="tooltip">
                    <span class="glyphicon glyphicon-plus"></span>
                  </a>
                  <a href="exit_product.php?id=<?php echo urlencode($product['id']); ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&category=<?php echo urlencode($selected_category); ?>&sort_order=<?php echo urlencode($sort_order); ?>&page=<?php echo urlencode($current_page); ?>" class="btn btn-warning btn-sm" title="Sacar producto" data-toggle="tooltip">
                    <span class="glyphicon glyphicon-minus"></span>
                  </a>
                  <a href="delete_product.php?id=<?php echo urlencode($product['id']); ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&category=<?php echo urlencode($selected_category); ?>&sort_order=<?php echo urlencode($sort_order); ?>&page=<?php echo urlencode($current_page); ?>" class="btn btn-danger btn-sm" title="Eliminar producto" data-toggle="tooltip">
                    <span class="glyphicon glyphicon-trash"></span>
                  </a>
                  <a href="edit_product.php?id=<?php echo urlencode($product['id']); ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&category=<?php echo urlencode($selected_category); ?>&sort_order=<?php echo urlencode($sort_order); ?>&page=<?php echo urlencode($current_page); ?>" class="btn btn-custom-6 btn-sm" title="Editar producto" data-toggle="tooltip">
                    <span class="glyphicon glyphicon-edit"></span>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>

      <!-- Paginación -->
      <nav aria-label="Page navigation">
            <ul class="pagination">
            <?php if($current_page > 1): ?>
              <li><a href="?page=1&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="First"><span aria-hidden="true">&laquo;&laquo;</span></a></li>
              <li><a href="?page=<?php echo $current_page - 1; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
              <?php endif; ?>

              <?php for($i = 1; $i <= $total_pages; $i++): ?>
                <li class="<?php echo $current_page == $i ? 'active' : ''; ?>"><a href="?page=<?php echo $i; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>"><?php echo $i; ?></a></li>
                <?php endfor; ?>

                <?php if($current_page < $total_pages): ?>
              <li><a href="?page=<?php echo $current_page + 1; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>
              <li><a href="?page=<?php echo $total_pages; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Last"><span aria-hidden="true">&raquo;&raquo;</span></a></li>
           <?php endif; ?>
            </ul>
          </nav>

      <?php else: ?>
        <div class="alert alert-warning">
          No se encontraron productos en el inventario.
        </div>
      <?php endif; ?>
      </div>
      </div>
    </div>
  </div>


<?php include_once('layouts/footer.php'); ?>
