<?php
require_once('includes/load.php');
// Verifica qué nivel de usuario tiene permiso para ver esta página
page_require_level(2);

if (isset($_GET['id'])) {
    $report_id = (int)$_GET['id'];
    
    // Consulta para eliminar el reporte de la tabla 'warnings'
    $sql = "DELETE FROM warnings WHERE id = {$report_id}";

    if ($db->query($sql)) {
        $session->msg('s', "Reporte Resuelto.");
    } else {
        $session->msg('d', "No se pudo resolver el reporte.");
    }
    redirect('report_missing_admin.php', false);
} else {
    $session->msg('d', "ID de reporte faltante.");
    redirect('report_missing_admin.php', false);
}
?>
