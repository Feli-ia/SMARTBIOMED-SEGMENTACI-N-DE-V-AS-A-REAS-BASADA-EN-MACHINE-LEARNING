<?php
$page_title = 'Historial de Movimientos';
require_once('includes/load.php');

// Verificar qué nivel de usuario tiene permiso para ver esta página
page_require_level(3);

// Comprobar si se ha seleccionado un tipo
$tipo = $_POST['tipo'] ?? 'productos';

// Función para encontrar todos los registros con una condición específica
function find_all_with_condition($table, $condition = "1=1") {
    global $db;
    return find_by_sql("SELECT * FROM {$db->escape($table)} WHERE {$condition}");
}

// Establecer la condición para la consulta según el tipo seleccionado
$movements_history = match ($tipo) {
    'productos' => find_all_with_condition('product_movements'),
    'medicamentos' => find_all_with_condition('medicine_movements'),
    'prestamos' => find_all_with_condition('product_loans'),
    default => [],
};

// Generar datos para los gráficos
function generar_datos_graficos($movements) {
    $ingresos_total = 0;
    $egresos_total = 0;

    foreach ($movements as $movement) {
        $quantity = (int)($movement['quantity'] ?? 0);
        $type = $movement['type'] ?? 'unknown';

        if ($type === 'Ingreso') {
            $ingresos_total += $quantity;
        } elseif ($type === 'Egreso') {
            $egresos_total += $quantity;
        }
    }

    return [$ingresos_total, $egresos_total];
}

list($ingresos_total, $egresos_total) = generar_datos_graficos($movements_history);
?>

<?php include_once('layouts/header.php'); ?>
>
    <div class="col-md-12">
        <?php echo display_msg($msg); ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-time"></span>
                    <span>Historial de Movimientos</span>
                </strong>
            </div>
            <div class="panel-body">
                <form id="filterForm" method="post" action="movement_history.php" class="form-inline">
                    <div class="form-group">
                        <label for="tipo">Seleccionar Tipo:</label>
                        <select name="tipo" id="tipo" class="form-control" onchange="document.getElementById('filterForm').submit();">
                            <option value="productos" <?php if ($tipo === 'productos') echo 'selected'; ?>>Productos</option>
                            <option value="medicamentos" <?php if ($tipo === 'medicamentos') echo 'selected'; ?>>Medicamentos</option>
                            <option value="prestamos" <?php if ($tipo === 'prestamos') echo 'selected'; ?>>Préstamos</option>
                        </select>
                    </div>
                </form>
                <br>
                <h3><?php echo ucfirst($tipo); ?></h3>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 50px;">#</th>
                            <th>Producto/Medicamento</th>
                            <th class="text-center" style="width: 10%;">Cantidad</th>
                            <th class="text-center" style="width: 15%;">Fecha</th>
                            <th class="text-center" style="width: 15%;">Tipo de Movimiento</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($movements_history)) : ?>
                            <?php foreach ($movements_history as $movement) : ?>
                                <tr>
                                    <td class="text-center"><?php echo count_id(); ?></td>
                                    <td>
                                        <?php
                                        if (in_array($tipo, ['productos', 'prestamos'])) {
                                            $product = find_by_id('products', $movement['product_id']);
                                            echo $product ? remove_junk($product['name']) : "Producto no encontrado";
                                        } elseif ($tipo === 'medicamentos') {
                                            echo remove_junk($movement['medicine_name']);
                                        }
                                        ?>
                                    </td>
                                    <td class="text-center"><?php echo (int)$movement['quantity']; ?></td>
                                    <td class="text-center"><?php echo read_date($movement['date']); ?></td>
                                    <td class="text-center"><?php echo ucfirst($movement['type']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="5" class="text-center">No se encontraron registros de movimientos</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <br>
                <h4>Gráfico de Ingresos vs Egresos</h4>
                <form class="form-inline">
                    <div class="form-group">
                        <label for="tipoGrafico">Seleccionar Tipo de Gráfico:</label>
                        <select id="tipoGrafico" class="form-control">
                            <option value="bar">Barras</option>
                            <option value="line">Líneas</option>
                            <option value="pie">Torta</option>
                        </select>
                    </div>
                </form>
                <br>
                <div>
                    <canvas id="movimientosChart" width="400" height="200"></canvas>
                </div>
                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                <script>
                    let movimientosChart;

                    function renderChart(type) {
                        const ctx = document.getElementById('movimientosChart').getContext('2d');

                        const data = {
                            labels: ['Ingresos', 'Egresos'],
                            datasets: [{
                                label: 'Cantidad',
                                backgroundColor: ['rgba(75, 192, 192, 0.2)', 'rgba(255, 99, 132, 0.2)'],
                                borderColor: ['rgba(75, 192, 192, 1)', 'rgba(255, 99, 132, 1)'],
                                borderWidth: 1,
                                data: [<?php echo $ingresos_total; ?>, <?php echo $egresos_total; ?>]
                            }]
                        };

                        if (movimientosChart) movimientosChart.destroy();

                        movimientosChart = new Chart(ctx, {
                            type: type,
                            data: data,
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                scales: {
                                    y: {
                                        beginAtZero: true,
                                        display: type !== 'pie'
                                    }
                                }
                            }
                        });
                    }

                    document.getElementById('tipoGrafico').addEventListener('change', function() {
                        renderChart(this.value);
                    });

                    // Render initial chart as bar chart
                    renderChart('bar');
                </script>
            </div>
        </div>
    </div>

<?php include_once('layouts/footer.php'); ?>
