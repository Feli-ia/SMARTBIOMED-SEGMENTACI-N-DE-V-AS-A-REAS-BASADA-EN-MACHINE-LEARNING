<?php
$page_title = 'Ingresar Medicamento';
require_once('includes/load.php');
// Verifica qué nivel de usuario tiene permiso para ver esta página
page_require_level(2);

// Obtener todos los medicamentos para el autocompletado
$all_medicamentos = find_all('medicamentos');

// Manejar la solicitud de agregar medicamentos
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $req_fields = ['nombre', 'cantidad'];
    validate_fields($req_fields);

    if (empty($errors)) {
        $nombres = $_POST['nombre'];
        $cantidades = $_POST['cantidad'];
        $date = make_date();

        // Comenzar transacción
        $db->query("START TRANSACTION");

        try {
            foreach ($nombres as $index => $nombre) {
                $nombre = remove_junk($db->escape($nombre));
                $cantidad = (int)$cantidades[$index];

                // Verifica si el medicamento ya existe
                $existing_medicine = find_by_sql("SELECT * FROM medicamentos WHERE nombre='{$nombre}' LIMIT 1");
                if ($existing_medicine) {
                    // Suma la cantidad ingresada a la cantidad existente
                    $new_quantity = (int)$existing_medicine[0]['cantidad'] + $cantidad;
                    $query  = "UPDATE medicamentos SET cantidad={$new_quantity} WHERE nombre='{$nombre}'";
                } else {
                    // Inserta un nuevo medicamento
                    $query  = "INSERT INTO medicamentos (nombre, cantidad) VALUES ('{$nombre}', {$cantidad})";
                }

                if (!$db->query($query)) {
                    throw new Exception('Falló al agregar o actualizar el medicamento.');
                }

                // Registrar el movimiento en la tabla 'medicine_movements'
                $movement_query = "INSERT INTO medicine_movements (medicine_name, quantity, date, type, category) VALUES ('{$nombre}', {$cantidad}, '{$date}', 'Ingreso', 'Medicamento')";
                if (!$db->query($movement_query)) {
                    throw new Exception('Falló al registrar el movimiento del medicamento.');
                }
            }
            // Confirmar transacción
            $db->query("COMMIT");
            $session->msg('s', "Medicamentos ingresados y movimientos registrados exitosamente.");
            redirect('add_medicine.php', false);
        } catch (Exception $e) {
            // Revertir transacción
            $db->query("ROLLBACK");
            $session->msg('d', $e->getMessage());
            redirect('add_medicine.php', false);
        }
    } else {
        $session->msg("d", $errors);
        redirect('add_medicine.php', false);
    }
}

include_once('layouts/header.php');
?>

<div class="container">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Agregar Medicamentos</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="add_medicine.php" class="clearfix">
          <div id="product-fields">
            <div class="product-field">
              <div class="form-group">
                <label for="nombre" class="control-label">Nombre</label>
                <input type="text" class="form-control product_id_input" name="nombre[]" list="medicamentos" placeholder="Nombre del medicamento" required>
                <ul class="dropdown-menu product_list"></ul>
              </div>
              <div class="form-group">
                <label for="cantidad" class="control-label">Cantidad</label>
                <input type="number" class="form-control" name="cantidad[]" min="1" placeholder="Cantidad utilizada" required>
              </div>
              <button type="button" class="remove-product btn btn-danger">Eliminar</button>
            </div>
          </div>
          <div class="form-group">
            <button type="button" id="add-product" class="btn btn-success">Agregar otro medicamento</button>
          </div>
          <div class="form-group">
            <button type="submit" name="add" class="btn btn-primary">Agregar Medicamentos</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const allProducts = <?php echo json_encode($all_medicamentos); ?>;

  function setupProductAutocomplete(container) {
    const productInput = container.querySelector('.product_id_input');
    const productList = container.querySelector('.product_list');

    productInput.addEventListener('input', function() {
      const userInput = productInput.value.toLowerCase();
      productList.innerHTML = '';
      if (userInput) {
        const filteredOptions = allProducts.filter(product => product.nombre.toLowerCase().includes(userInput));
        filteredOptions.forEach(product => {
          const option = document.createElement('li');
          option.className = 'dropdown-item';
          option.textContent = product.nombre;
          option.dataset.id = product.id;
          option.addEventListener('click', function() {
            productInput.value = product.nombre;
            productList.innerHTML = '';
          });
          productList.appendChild(option);
        });
        productList.style.display = 'block';
      } else {
        productList.style.display = 'none';
      }
    });

    document.addEventListener('click', function(event) {
      if (!productInput.contains(event.target) && !productList.contains(event.target)) {
        productList.style.display = 'none';
      }
    });
  }

  document.querySelectorAll('.product-field').forEach(setupProductAutocomplete);

  document.getElementById('add-product').addEventListener('click', function() {
    const productFields = document.getElementById('product-fields');
    const newFields = document.createElement('div');
    newFields.className = 'product-field';
    newFields.innerHTML = `
      <div class="form-group">
        <label for="nombre" class="control-label">Nombre</label>
        <input type="text" class="form-control product_id_input" name="nombre[]" list="medicamentos" placeholder="Nombre del medicamento" required>
        <ul class="dropdown-menu product_list"></ul>
      </div>
      <div class="form-group">
        <label for="cantidad" class="control-label">Cantidad</label>
        <input type="number" class="form-control" name="cantidad[]" min="1" placeholder="Cantidad utilizada" required>
      </div>
      <button type="button" class="remove-product btn btn-danger">Eliminar</button>
    `;
    productFields.appendChild(newFields);
    setupProductAutocomplete(newFields);
    attachRemoveEvent();
    updateRemoveButtons();
  });

  function attachRemoveEvent() {
    document.querySelectorAll('.remove-product').forEach(button => {
      button.addEventListener('click', function() {
        button.closest('.product-field').remove();
        updateRemoveButtons();
      });
    });
  }

  function updateRemoveButtons() {
    const removeButtons = document.querySelectorAll('.remove-product');
    removeButtons.forEach((button, index) => {
      button.style.display = index < 1 ? 'none' : 'block'; // Ocultar el botón de eliminar si hay menos de 2 campos
    });
  }

  attachRemoveEvent();
  updateRemoveButtons();
});
</script>
