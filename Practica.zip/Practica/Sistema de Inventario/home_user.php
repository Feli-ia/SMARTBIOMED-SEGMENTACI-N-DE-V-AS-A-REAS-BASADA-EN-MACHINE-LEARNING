<?php
$page_title = 'Página de Inicio del Usuario';
require_once('includes/load.php');
if (!$session->isUserLoggedIn()) { redirect('index.php', false); }
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
  <div class="col-md-12">
    <div class="panel">
      <div class="jumbotron text-center">
        <h1 style="font-size: 2.5em;">Bienvenido</h1>
        <p style="font-size: 1.2em;">Con este sistema, se registrara fácilmente los consumos, préstamos de productos y advertencias. Aquí están las funciones disponibles:</p>
        <hr>

        <!-- Botón para Productos -->
        <button class="btn btn-custom-1 btn-lg btn-block mb-2" data-toggle="collapse" data-target="#productos">Productos</button>
        <div id="productos" class="collapse">
          <div class="feature row" style="display: flex; align-items: center; text-align: center;">
            <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
              <h2 style="font-size: 2em;"><strong>Productos</strong></h2>
              <p style="font-size: 1.2em;">Gestione los productos en su inventario:</p>
              <ol style="font-size: 1.2em; margin-bottom: 1em;">
                <li><strong>Nombre del Producto:</strong> Ingrese el nombre del producto (ej. "Guantes").</li>
                <li><strong>Cantidad:</strong> Especifique la cantidad (ej. "10").</li>
                <li><strong>Agregar otro producto:</strong> Presione este botón para registrar más productos utilizados.</li>
              </ol>
              <p style="font-size: 1.2em;"><strong>Registrar Uso:</strong> Haga clic para registrar la información.</p>
            </div>
            <div class="col-md-5" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
              <img src="uploads/user/user 1.png" class="img-responsive" alt="Instrucciones para registrar el uso de Insumos" style="width: 20%;">
              <img src="uploads/user/user 1.2.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
            </div>
          </div>
          <hr>
        </div>

        <!-- Botón para Medicamento -->
        <button class="btn btn-custom-2 btn-lg btn-block mb-2" data-toggle="collapse" data-target="#medicamento">Medicamento</button>
        <div id="medicamento" class="collapse">
          <div class="feature row" style="display: flex; align-items: center; text-align: center;">
            <div class="col-md-5" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
              <img src="uploads/user/user 2.png" class="img-responsive" alt="Instrucciones para registrar el uso de Medicamentos" style="width: 20%;">
              <img src="uploads/user/user 2.2.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
            </div>
            <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
              <h2 style="font-size: 2em;"><strong>Medicamento</strong></h2>
              <p style="font-size: 1.2em;">Registre el uso de medicamentos:</p>
              <ol style="font-size: 1.2em; margin-bottom: 1em;">
                <li><strong>Nombre:</strong> Ingrese el nombre del medicamento (ej. "Paracetamol").</li>
                <li><strong>Cantidad:</strong> Especifique la cantidad (ej. "2").</li>
                <li><strong>Agregar otro medicamento:</strong> Presione este botón para registrar más medicamentos utilizados.</li>
              </ol>
              <p style="font-size: 1.2em;"><strong>Registrar Uso:</strong> Haga clic para registrar la información.</p>
            </div>
          </div>
          <hr>
        </div>

<!-- Botón para Préstamo de Producto -->
<button class="btn btn-custom-4 btn-lg btn-block mb-2" data-toggle="collapse" data-target="#prestamo">Préstamo de Producto</button>
<div id="prestamo" class="collapse">
  <div class="feature row" style="display: flex; align-items: center; text-align: center;">
    <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
      <h2 style="font-size: 2em;"><strong>Préstamo de Producto</strong></h2>
      <p style="font-size: 1.2em;">Registrar el préstamo de productos:</p>
      <ol style="font-size: 1.2em; margin-bottom: 1em;">
        <li><strong>Nombre:</strong> Ingrese el nombre del producto a prestar.</li>
        <li><strong>Cantidad:</strong> Especifique la cantidad a entregar.</li>
        <li><strong>Unidad Destino:</strong> Indique la unidad que recibirá el producto.</li>
        <li><strong>Agregar otro producto:</strong> Haga clic en este botón para registrar más productos en el mismo préstamo.</li>
      </ol>
      <p style="font-size: 1.2em;"><strong>Registrar Préstamo:</strong> Haga clic para guardar la información.</p>
    </div>
    <div class="col-md-5" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
      <img src="uploads/user/user 3.png" class="img-responsive" alt="Instrucciones para registrar el préstamo de productos" style="width: 20%;">
      <img src="uploads/user/user 3.2.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
    </div>
  </div>
  <hr>
</div>

<!-- Botón para Advertencia -->
<button class="btn btn-custom-5 btn-lg btn-block mb-2" data-toggle="collapse" data-target="#advertencia">Advertencia</button>
<div id="advertencia" class="collapse">
  <div class="feature row" style="display: flex; align-items: center; text-align: center;">
    <div class="col-md-5" style="display: flex; align-items: center; justify-content: center; gap: 5%;">
      <img src="uploads/user/user 4.png" class="img-responsive" alt="Instrucciones para registrar advertencias" style="width: 20%;">
      <img src="uploads/user/user 4.1.png" class="img-responsive" alt="Instrucciones adicionales" style="width: 75%;">
    </div>
    <div class="col-md-7" style="display: flex; flex-direction: column; justify-content: center;">
      <h2 style="font-size: 2em;"><strong>Advertencia</strong></h2>
      <p style="font-size: 1.2em;">Reportar problemas:</p>
      <ol style="font-size: 1.2em; margin-bottom: 1em;">
        <li><strong>Descripción del Problema:</strong> Ingrese la descripción del problema. Como la falta de productos o Medicamentos</li>
      </ol>
              <p style="font-size: 1.2em; max-width: 100%; text-align: center;"><strong>Registrar Advertencia:</strong> Haga clic en este botón para guardar el reporte en el sistema.</p>
            </div>
          </div>
        </div>
        <hr>
        <p style="font-size: 1.2em; margin-bottom: 2em;">Utilice el menú de navegación lateral para acceder a las diferentes secciones de la plataforma. Si tiene alguna duda o problema, no dude en contactar con el soporte técnico.</p>
        <p style="font-size: 0.9em; text-align: left;  margin-left: 1em;">Productos son los Insumos, Economato y Esterilización.</p>
      </div>
    </div>
  </div>
  <hr>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>

<?php include_once('layouts/footer.php'); ?>


<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cortina de Gatos y Perros</title>
  <style>
    .animated-pet {
      position: fixed;
      z-index: 9999;
    }
    .cat {
      width: 150px;
      height: auto;
    }
    .dog {
      width: 800px;
      height: auto;
    }
    .hidden {
      display: none;
    }
    #timer-circle {
      width: 40px;
      height: 40px;
      border: 1px solid #000;
      border-radius: 60%;
      display: inline-block;
      margin-left: 10px;
      position: relative;
      background: conic-gradient(black 0deg, black 0deg);
    }
    .btn-bonus {
      background-color:rgba(9, 71, 125, 0.96);
      border-color:rgb(12, 92, 177);
      color: white;
      font-size: 16px;
      padding: 10px 20px;
      border-radius: 5px;
      border: none;
      cursor: pointer;
      transition: background-color 0.3s ease, border-color 0.3s ease;
    }

    .btn-bonus:hover {
      background-color: #0056b3;
      border-color: #0056b3;
    }
  </style>
</head>
<body>
  <div id="animals-container"></div>
  <button id="toggle-button" class="btn-bonus">Bonus</button>
  <div id="timer-circle" class="hidden"></div>
</body>
</html>

  <script>
    let animalsActive = false;
    let loopInterval;
    const maxCats = 70; // Aumentado el número de gatos
    const maxDogs = 12; // Aumentado el número de perros
    const rowHeight = 120;
    const catRows = [0, 2, 4, 6];
    const dogRows = [1, 3, 5];
    const maxActiveAnimals = 20; // Aumentado el número máximo de animales activos
    let timerInterval;

    function toggleAnimals() {
      animalsActive = !animalsActive;
      const button = document.getElementById('toggle-button');
      const timerCircle = document.getElementById('timer-circle');
      button.textContent = animalsActive ? 'Desactivar' : 'Bonus';
      timerCircle.classList.toggle('hidden', !animalsActive);
      if (animalsActive) {
        startTimer();
        startAnimals();
      } else {
        stopAnimals();
      }
    }

    function startTimer() {
      let timeLeft = 20;
      const timerCircle = document.getElementById('timer-circle');
      timerInterval = setInterval(() => {
        timeLeft -= 1;
        const degrees = (timeLeft / 20) * 360;
        timerCircle.style.background = `conic-gradient(black ${degrees}deg, transparent ${degrees}deg)`;
        if (timeLeft <= 0) {
          clearInterval(timerInterval);
          stopAnimals(); // Parar los animales al finalizar el tiempo
        }
      }, 1000);
    }

    function startAnimals() {
  const catInterval = 300;  // Intervalo para los gatos
  const dogInterval = 2000; // Intervalo aumentado para los perros
  const startTime = Date.now();

  function animate() {
    if (!animalsActive) return;

    let activeAnimals = document.querySelectorAll('.animated-pet').length;
    if (activeAnimals >= maxActiveAnimals) {
      return;
    }

    for (let i = 0; i < maxCats; i++) {
      const row = catRows[i % catRows.length];
      createAnimal(i * catInterval, row * rowHeight, 'cat');
    }

    for (let i = 0; i < maxDogs; i++) {
      const row = dogRows[i % dogRows.length];
      createAnimal(i * dogInterval, row * rowHeight + 20, 'dog');
    }

    setTimeout(() => {
      const elapsedTime = Date.now() - startTime;
      if (elapsedTime < 20000 && animalsActive) {
        animate();
      }
    }, Math.max(maxCats * catInterval, maxDogs * dogInterval));
  }

  animate();
  loopInterval = setInterval(() => {
    if (animalsActive) {
      animate();
    }
  }, Math.max(maxCats * catInterval, maxDogs * dogInterval));
}

    function stopAnimals() {
      animalsActive = false;
      const button = document.getElementById('toggle-button');
      const timerCircle = document.getElementById('timer-circle');
      button.textContent = 'Bonus';
      button.disabled = false;
      clearInterval(loopInterval);
      clearInterval(timerInterval);
      document.getElementById('animals-container').innerHTML = '';
      timerCircle.classList.add('hidden');
    }

    function createAnimal(delay, topPosition, type) {
      const animalsContainer = document.getElementById('animals-container');
      const animal = document.createElement('div');
      animal.className = 'animated-pet ' + type;
      animal.style.top = `${topPosition}px`;

      if (type === 'cat') {
        animal.style.left = `${window.innerWidth}px`;
        animal.innerHTML = '<img src="https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExb3h2ZDhuYzRvYmp5MHQ0eTRnZGVrc2x4bDE5cGl3bmJ0bHNjZXFocCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/QcuzOd4rRLyLu/giphy.gif" alt="Gato" class="cat">';
      } else if (type === 'dog') {
        animal.style.left = `-${window.innerWidth}px`;
        animal.innerHTML = '<img src="https://media0.giphy.com/media/iEp5KdgmIMzz4u5jvI/giphy.gif" alt="Perro corriendo" class="dog">';
      }

      animalsContainer.appendChild(animal);

      setTimeout(() => {
        if (animalsActive) moveAnimal(animal, type);
      }, delay);
    }

    function moveAnimal(animal, type) {
      let startTime = null;
      const duration = 10000;
      const startLeft = type === 'cat' ? window.innerWidth : -animal.offsetWidth;
      const endLeft = type === 'cat' ? -animal.offsetWidth : window.innerWidth;

      function step(timestamp) {
        if (!startTime) startTime = timestamp;
        const progress = timestamp - startTime;
        const left = startLeft + ((endLeft - startLeft) * (progress / duration));
        animal.style.left = `${left}px`;
        if (progress < duration) {
          window.requestAnimationFrame(step);
        } else {
          if (animal.parentNode === animalsContainer) {
            animalsContainer.removeChild(animal);
          }
        }
      }

      window.requestAnimationFrame(step);
    }

    document.getElementById('toggle-button').addEventListener('click', toggleAnimals);
  </script>
</body>
</html>

