<?php
$page_title = 'Reporte de Falta de Producto';
require_once('includes/load.php');
// Verifica qué nivel de usuario tiene permiso para ver esta página
page_require_level(2);

// Consulta para obtener los reportes de falta de Producto y los nombres de los usuarios
$sql  = "SELECT w.*, u.name AS user_name FROM warnings w";
$sql .= " LEFT JOIN users u ON w.user_id = u.id";
$warnings = find_by_sql($sql);

include_once('layouts/header.php');
?>

<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-warning-sign"></span>
          <span>Reporte de Falta de Producto</span>
        </strong>
      </div>
      <div class="panel-body">
        <?php if (empty($warnings)): ?>
          <div class="alert alert-info">
            <strong>No se encontraron reportes de falta de Producto.</strong>
          </div>
        <?php else: ?>
          <table class="table table-bordered">
            <thead>
              <tr>
                <th class="text-center" style="width: 50px;">#</th>
                <th class="text-center" style="width: 100px;">Usuario</th>
                <th class="text-center" style="width: 300px;">Descripción</th>
                <th class="text-center" style="width: 100px;">Fecha de Reporte</th>
                <th class="text-center" style="width: 100px;">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($warnings as $report): ?>
              <tr>
                <td class="text-center"><?php echo count_id(); ?></td>
                <td><?php echo remove_junk(ucfirst($report['user_name'])); ?></td>
                <td><?php echo remove_junk($report['description']); ?></td>
                <td class="text-center"><?php echo read_date($report['date']); ?></td>
                <td class="text-center">
                  <div class="btn-group">
                    <a href="resolve_report.php?id=<?php echo (int)$report['id']; ?>" class="btn btn-success btn-xs" title="Resolver" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-ok"></span>
                    </a>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>
