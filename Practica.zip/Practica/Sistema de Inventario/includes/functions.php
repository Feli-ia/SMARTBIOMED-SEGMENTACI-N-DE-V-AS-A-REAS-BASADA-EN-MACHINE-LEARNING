<?php
 $errors = array();

 /*--------------------------------------------------------------*/
 /* Function for Remove escapes special
 /* characters in a string for use in an SQL statement
 /*--------------------------------------------------------------*/
function real_escape($str){
  global $con;
  $escape = mysqli_real_escape_string($con,$str);
  return $escape;
}
/*--------------------------------------------------------------*/
/* Function for Remove html characters
/*--------------------------------------------------------------*/
function remove_junk($str) {
  if (is_array($str)) {
    return array_map('remove_junk', $str);
  } else {
    $str = nl2br($str);
    $str = htmlspecialchars(strip_tags($str, ENT_QUOTES));
    return $str;
  }
}

/*--------------------------------------------------------------*/
/* Function for Uppercase first character
/*--------------------------------------------------------------*/
function first_character($str){
  $val = str_replace('-'," ",$str);
  $val = ucfirst($val);
  return $val;
}
/*--------------------------------------------------------------*/
/* Function for Checking input fields not empty
/*--------------------------------------------------------------*/
function validate_fields($var) {
  global $errors;
  foreach ($var as $field) {
    if (is_array($_POST[$field])) {
      foreach ($_POST[$field] as $value) {
        $val = remove_junk($value);
        if (isset($val) && $val == '') {
          $errors = $field . " No puede estar en blanco.";
          return $errors;
        }
      }
    } else {
      $val = remove_junk($_POST[$field]);
      if (isset($val) && $val == '') {
        $errors = $field . " No puede estar en blanco.";
        return $errors;
      }
    }
  }
}  

/*--------------------------------------------------------------*/
/* Function for Display Session Message
   Ex echo displayt_msg($message);
/*--------------------------------------------------------------*/
function display_msg($msg =''){
  $output = array();
  if(!empty($msg) && is_array($msg)) {
     foreach ($msg as $key => $value) {
        $output  = "<div class=\"alert alert-{$key}\">";
        $output .= "<a href=\"#\" class=\"close\" data-dismiss=\"alert\">&times;</a>";
        $output .= remove_junk(first_character($value));
        $output .= "</div>";
     }
     return $output;
  } else {
    return "" ;
  }
}

/*--------------------------------------------------------------*/
/* Function for redirect
/*--------------------------------------------------------------*/
function redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
      header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
/*--------------------------------------------------------------*/
/* Function for Readable date time
/*--------------------------------------------------------------*/
function read_date($str) {
  if ($str) {
      // Crear un objeto DateTime con la fecha y la zona horaria de Chile
      $dateTime = new DateTime($str, new DateTimeZone('America/Santiago'));
      // Formatear la fecha en el formato deseado
      return $dateTime->format('d/m/Y g:i:s a');
  } else {
      return null;
  }
}


/*--------------------------------------------------------------*/
/* Function for  Readable Make date time
/*--------------------------------------------------------------*/
function make_date() {
  // Crear un objeto DateTime con la fecha y hora actuales y la zona horaria de Chile
  $dateTime = new DateTime('now', new DateTimeZone('America/Santiago'));
  // Formatear la fecha en el formato deseado
  return $dateTime->format('Y-m-d H:i:s');
}


/*--------------------------------------------------------------*/
/* Function for  Readable date time
/*--------------------------------------------------------------*/
function count_id(){
  static $count = 1;
  return $count++;
}

/*--------------------------------------------------------------*/
/* Function for Creting random string
/*--------------------------------------------------------------*/
function randString($length = 5)
{
  $str='';
  $cha = "0123456789abcdefghijklmnopqrstuvwxyz";

  for($x=0; $x<$length; $x++)
   $str .= $cha[mt_rand(0,strlen($cha))];
  return $str;
}


function find_medicines_with_filters($table, $search_name, $min_quantity, $limit, $offset, $critical_only, $sort_by, $order) {
  global $db;
  
  $sql = "SELECT * FROM {$table} WHERE 1";

  if (!empty($search_name)) {
      $sql .= " AND nombre LIKE ?";
  }

  if ($min_quantity > 0) {
      $sql .= " AND cantidad >= ?";
  }

  if ($critical_only) {
      $sql .= " AND cantidad <= nivel_critico_med";
  }

  if ($sort_by !== 'default') {
      $sql .= " ORDER BY {$sort_by} {$order}";
  }

  $sql .= " LIMIT ? OFFSET ?";

  if ($stmt = $db->prepare($sql)) {
      $param_types = '';
      $params = [];

      if (!empty($search_name)) {
          $param_types .= 's';
          $params[] = "%$search_name%";
      }

      if ($min_quantity > 0) {
          $param_types .= 'i';
          $params[] = $min_quantity;
      }

      $param_types .= 'ii';
      $params[] = $limit;
      $params[] = $offset;

      $stmt->bind_param($param_types, ...$params);
      $stmt->execute();
      $result = $stmt->get_result();

      return $result->fetch_all(MYSQLI_ASSOC);
  } else {
      return [];
  }
}


function count_medicines_with_filters($table, $search_name = '', $min_quantity = 0, $critical_only = false) {
  global $db;
  $sql  = "SELECT COUNT(*) AS total FROM {$db->escape($table)} WHERE 1=1";
  if ($search_name) {
      $sql .= " AND nombre LIKE '%{$db->escape($search_name)}%'";
  }
  if ($min_quantity) {
      $sql .= " AND cantidad >= {$db->escape((int)$min_quantity)}";
  }
  if ($critical_only) {
      $sql .= " AND cantidad <= nivel_critico_med";
  }
  $result = $db->query($sql);
  if ($result === false) {
      return false;
  }
  if ($result === false) {
      return false;
  }
  return ($db->fetch_assoc($result)['total']);
}

function count_products_with_filters($table, $search_name, $min_quantity, $critical_only, $selected_category) {
  global $db;
  $sql = "SELECT COUNT(*) AS total FROM {$db->escape($table)} WHERE 1=1";
  if ($search_name !== '') {
      $sql .= " AND name LIKE '%{$db->escape($search_name)}%'";
  }
  if ($min_quantity > 0) {
      $sql .= " AND quantity >= " . (int)$min_quantity;
  }
  if ($critical_only) {
      $sql .= " AND quantity <= nivel_critico";
  }
  if ($selected_category !== '') {
      $sql .= " AND categorie = '{$db->escape($selected_category)}'";
  }
  $result = $db->query($sql);
  if ($result === false) {
      return false;
  }
  if ($db->num_rows($result) > 0) {
      $row = $db->fetch_assoc($result);
      return (int)$row['total'];
  } else {
      return false;
  }
}

function find_products_with_filters($table, $search_name, $min_quantity, $products_per_page, $offset, $critical_only, $selected_category, $sort_by, $order) {
  global $db;
  $sql = "SELECT * FROM {$db->escape($table)} WHERE 1=1";
  if ($search_name !== '') {
      $sql .= " AND name LIKE '%{$db->escape($search_name)}%'";
  }
  if ($min_quantity > 0) {
      $sql .= " AND quantity >= " . (int)$min_quantity;
  }
  if ($critical_only) {
      $sql .= " AND quantity <= nivel_critico";
  }
  if ($selected_category !== '') {
      $sql .= " AND categorie = '{$db->escape($selected_category)}'";
  }
  if ($sort_by !== 'default') {
      $sql .= " ORDER BY {$db->escape($sort_by)} {$db->escape($order)}";
  } else {
      $sql .= " ORDER BY id ASC";
  }
  $sql .= " LIMIT {$db->escape((int)$products_per_page)} OFFSET {$db->escape((int)$offset)}";
  return find_by_sql($sql);
}

function authenticate_v2($username, $password) {
  global $db;
  global $con;
  $username = mysqli_real_escape_string($con, $username);
  $password = sha1($db->escape($password));
  $sql  = "SELECT id, username, user_level FROM users ";
  $sql .= "WHERE username = '{$username}' AND password = '{$password}' LIMIT 1";
  $result = $db->query($sql);
  if ($result === false) {
      return false;
  }
  if ($db->num_rows($result) > 0) {
      return $db->fetch_assoc($result);
  }
  return false;
}

if (!function_exists('current_user_id')) {
  function current_user_id() {
    // Aquí debes agregar la lógica para obtener el ID del usuario actual
    return $_SESSION['user_id'];
  }
}


function find_by_username($username) {
  global $db;
  $sql = "SELECT * FROM users WHERE username = '{$username}' LIMIT 1";
  return $db->fetch_assoc($db->query($sql));
}

function getUserLevel($userId) {
  global $db;
  $sql = "SELECT user_level FROM users WHERE id='{$userId}' LIMIT 1";
  $result = $db->query($sql);
  if ($result && $db->num_rows($result) === 1) {
    $row = $db->fetch_assoc($result);
    return $row['user_level'];
  } else {
    return false;
  }
}


function log_action($user_id, $action) {
  global $db;
  $sql = "INSERT INTO activity_log (user_id, action) VALUES ('{$db->escape($user_id)}', '{$db->escape($action)}')";
  return $db->query($sql);
}

function find_user_by_id($user_id) {
  global $db;
  $id = $db->escape($user_id);
  $sql = "SELECT * FROM users WHERE id = '{$id}' LIMIT 1";
  $result = find_by_sql($sql);
  return $result ? $result[0] : null; // Retorna el primer resultado o null si no se encuentra
}

?>