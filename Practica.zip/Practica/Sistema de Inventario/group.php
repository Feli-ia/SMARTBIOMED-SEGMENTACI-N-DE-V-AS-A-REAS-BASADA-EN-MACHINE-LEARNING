<?php
  $page_title = 'Lista de Grupos';
  require_once('includes/load.php');
  // Verifica qué nivel de usuario tiene permiso para ver esta página
  page_require_level(1);
  $all_groups = find_all('user_groups');

  // Función para contar usuarios por grupo
  function count_users_by_group($group_level) {
    global $db;
    $sql = "SELECT COUNT(*) AS total FROM users WHERE user_level = '{$group_level}'";
    $result = $db->query($sql);
    if($result){
        $row = $result->fetch_assoc();
        return $row['total'];
    }
    return 0;
  }
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
   <div class="col-md-12">
     <?php echo display_msg($msg); ?>
   </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Grupos</span>
        </strong>
      </div>
      <div class="panel-body">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th class="text-center" style="width: 50px;">#</th>
              <th>Nombre del Grupo</th>
              <th class="text-center" style="width: 20%;">Nivel del Grupo</th>
              <th class="text-center" style="width: 15%;">Usuarios</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach($all_groups as $a_group): ?>
            <tr>
              <td class="text-center"><?php echo count_id(); ?></td>
              <td><?php echo remove_junk(ucwords($a_group['group_name'])); ?></td>
              <td class="text-center"><?php echo remove_junk(ucwords($a_group['group_level'])); ?></td>
              <td class="text-center"><?php echo count_users_by_group($a_group['group_level']); ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
