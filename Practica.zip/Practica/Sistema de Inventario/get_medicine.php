<?php
require_once('includes/load.php');

// Verifica qué nivel de usuario tiene permiso para ver esta página
page_require_level(2);

if (isset($_GET['nombre'])) {
    $medicine_name = remove_junk($db->escape($_GET['nombre']));
    $medicine = find_by_sql("SELECT nombre, cantidad FROM medicamentos WHERE nombre='{$medicine_name}' LIMIT 1");

    if ($medicine) {
        echo json_encode($medicine[0]);
    } else {
        echo json_encode(['error' => 'Medicamento no encontrado']);
    }
}
?>
