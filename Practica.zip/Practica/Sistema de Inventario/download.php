<?php
require_once('includes/load.php');

// Procesar la solicitud de descarga
if (isset($_GET['file'])) {
    $filename = urldecode($_GET['file']);
    if (file_exists($filename)) {
        // Descargar el archivo XLS
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
        readfile($filename);

        // Eliminar el archivo temporal
        unlink($filename);
        exit;
    } else {
        $session->msg('d', "Archivo no encontrado.");
        redirect('download.php', false);
    }
}

include_once('layouts/header.php');
?>

<div class="container-fluid">
    <div class="col-md-12">
        <?php echo display_msg($msg); ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                <strong>
                    <span class="glyphicon glyphicon-export"></span>
                    <span>Exportar Tablas</span>
                </strong>
            </div>
            <div class="panel-body">
                <form method="post" action="export.php" class="clearfix">
                    <div class="form-group">
                        <label for="action">Selecciona una tabla para exportar:</label>
                        <select name="action" id="action" class="form-control">
                            <option value="export_medicamentos">Inventario de Medicamentos</option>
                            <option value="export_medicine_usage">Uso de Medicinas</option>
                            <option value="export_medicine_movements">Movimientos de Medicinas</option>
                            <option value="export_products">Productos</option>
                            <option value="export_product_usage">Uso de Productos</option>
                            <option value="export_product_loans">Préstamos de Productos</option>
                            <option value="export_product_movements">Movimientos de Productos</option>
                            <option value="export_warnings">Advertencias</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">Exportar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once('layouts/footer.php'); ?>
