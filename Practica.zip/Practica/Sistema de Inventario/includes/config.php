<?php

define('DB_SERVER', 'localhost');
define('DB_USER', 'root'); 
define('DB_PASS', ''); 
define('DB_DATABASE', 'uea_inv'); 

// Establecer conexión con la base de datos
$connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE);

// Verificar la conexión
if (!$connection) {
    die("Error en la conexión: " . mysqli_connect_error());
}
?>
