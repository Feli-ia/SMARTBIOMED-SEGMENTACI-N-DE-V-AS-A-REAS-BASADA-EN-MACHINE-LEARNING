<?php
  $page_title = 'Lista de Categorías';
  require_once('includes/load.php');
  // Verifica qué nivel de usuario tiene permiso para ver esta página
  page_require_level(1);

  // Función para contar productos de una categoría específica en la base de datos
  function count_products_by_categorie($categorie) {
      global $db;
      $sql = "SELECT COUNT(*) AS total FROM products WHERE categorie = '{$categorie}'";
      $result = $db->query($sql);
      return $result->fetch_assoc()['total'];
  }

  // Función para contar medicamentos en la base de datos
  function count_medicines() {
      global $db;
      $sql = "SELECT COUNT(*) AS total FROM medicamentos";
      $result = $db->query($sql);
      return $result->fetch_assoc()['total'];
  }

  // Lista de categorías específicas
  $categories = [
      ['name' => 'insumos', 'count' => count_products_by_categorie('insumos')],
      ['name' => 'esterilizacion', 'count' => count_products_by_categorie('esterilizacion')],
      ['name' => 'economato', 'count' => count_products_by_categorie('economato')],
      ['name' => 'medicamentos', 'count' => count_medicines()]
  ];

  // Agregar nueva categoría
  if(isset($_POST['add_cat'])){
    $req_field = array('category-name');
    validate_fields($req_field);
    $cat_name = remove_junk($db->escape($_POST['category-name']));
    if(empty($errors)){
      $sql  = "INSERT INTO categories (name) VALUES ('{$cat_name}')";
      if($db->query($sql)){
        $session->msg("s", "Categoría agregada exitosamente.");
        redirect('category.php', false);
      } else {
        $session->msg("d", "Lo siento, el registro falló.");
        redirect('category.php', false);
      }
    } else {
      $session->msg("d", $errors);
      redirect('category.php', false);
    }
  }
?>
<?php include_once('layouts/header.php'); ?>

<div class="row">
   <div class="col-md-12">
     <?php echo display_msg($msg); ?>
   </div>
</div>
<div class="row">
  <div class="col-md-5">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Agregar Categoría</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="category.php">
          <div class="form-group">
              <input type="text" class="form-control" name="category-name" placeholder="Nombre de la categoría" required>
          </div>
          <button type="submit" name="add_cat" class="btn btn-primary">Agregar Categoría</button>
        </form>
      </div>
    </div>
  </div>
  <div class="col-md-7">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Lista de Categorías</span>
        </strong>
      </div>
      <div class="panel-body">
        <table class="table table-bordered table-striped table-hover">
          <thead>
              <tr>
                  <th class="text-center" style="width: 50px;">#</th>
                  <th>Categorías</th>
                  <th class="text-center" style="width: 150px;">Cantidad</th>
                  <th class="text-center" style="width: 100px;">Acciones</th>
              </tr>
          </thead>
          <tbody>
            <?php foreach ($categories as $index => $cat): ?>
              <tr>
                  <td class="text-center"><?php echo $index + 1; ?></td>
                  <td><?php echo remove_junk(ucfirst($cat['name'])); ?></td>
                  <td class="text-center"><?php echo $cat['count']; ?></td>
                  <td class="text-center">
                    <div class="btn-group">
                      <a href="edit_category.php?id=<?php echo urlencode($cat['name']); ?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Editar">
                        <span class="glyphicon glyphicon-edit"></span>
                      </a>
                      <a href="delete_category.php?id=<?php echo urlencode($cat['name']); ?>" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Eliminar">
                        <span class="glyphicon glyphicon-trash"></span>
                      </a>
                    </div>
                  </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>
