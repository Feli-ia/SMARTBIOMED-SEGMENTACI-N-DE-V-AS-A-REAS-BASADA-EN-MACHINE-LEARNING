<?php
require_once('includes/load.php');

$host = 'localhost';
$dbname = 'uea_inv';
$username = 'root';
$password = '';

// Función para exportar una tabla en formato Excel moderno
function writeTableToXLSX($table, $filename) {
    global $host, $dbname, $username, $password;

    // Conexión a la base de datos
    $conn = new mysqli($host, $username, $password, $dbname);

    // Verificar conexión
    if ($conn->connect_error) {
        die("La conexión falló: " . $conn->connect_error);
    }

    // Consultar datos de la tabla
    $result = $conn->query("SELECT * FROM `$table`");
    if (!$result) {
        die("Consulta fallida: " . $conn->error);
    }

    // Crear una tabla HTML que Excel pueda interpretar como archivo XML
    $output = '<?xml version="1.0"?>
    <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
        xmlns:x="urn:schemas-microsoft-com:office:excel"
        xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
        <Worksheet ss:Name="Sheet1">
            <Table>';

    // Escribir encabezados de columna
    $fields = $result->fetch_fields();
    $output .= '<Row>';
    foreach ($fields as $field) {
        $output .= '<Cell><Data ss:Type="String">' . htmlspecialchars($field->name) . '</Data></Cell>';
    }
    $output .= '</Row>';

    // Escribir filas de datos
    while ($row = $result->fetch_assoc()) {
        $output .= '<Row>';
        foreach ($row as $value) {
            $type = is_numeric($value) ? "Number" : "String";
            $output .= '<Cell><Data ss:Type="' . $type . '">' . htmlspecialchars($value) . '</Data></Cell>';
            }
        $output .= '</Row>';
    }

    $output .= '</Table>
        </Worksheet>
    </Workbook>';

    // Cerrar conexión a la base de datos
    $conn->close();

    // Escribir archivo y establecer encabezados para la descarga
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');

    echo $output;
}

// Procesar la solicitud de exportación
if (isset($_POST['action'])) {
    $validActions = [
        'export_medicamentos', 'export_medicine_usage', 'export_medicine_movements',
        'export_products', 'export_product_usage', 'export_product_loans', 'export_product_movements',
        'export_warnings'
    ];

    $action = $_POST['action'];
    if (in_array($action, $validActions)) {
        $filename = $action . '.xls'; // Usamos .xls porque Excel reconoce XML como archivo Excel
        switch ($action) {
            case 'export_medicamentos':
                writeTableToXLSX('medicamentos', $filename);
                break;
            case 'export_medicine_usage':
                writeTableToXLSX('medicine_usage', $filename);
                break;
            case 'export_medicine_movements':
                writeTableToXLSX('medicine_movements', $filename);
                break;
            case 'export_products':
                writeTableToXLSX('products', $filename);
                break;
            case 'export_product_usage':
                writeTableToXLSX('product_usage', $filename);
                break;
            case 'export_product_loans':
                writeTableToXLSX('product_loans', $filename);
                break;
            case 'export_product_movements':
                writeTableToXLSX('product_movements', $filename);
                break;
            case 'export_warnings':
                writeTableToXLSX('warnings', $filename);
                break;
        }
        exit;
    } else {
        echo "Acción no válida.";
        exit;
    }
} else {
    echo "No se especificó ninguna acción.";
    exit;
}
?>
