<?php
ob_start();
require_once('includes/load.php');
require_once('includes/functions.php'); // Asegúrate de incluir el archivo correcto

if ($session->isUserLoggedIn()) {
    if (isset($session->user_id)) {
        $user_id = $session->user_id;
        $user_level = getUserLevel($user_id);

        // Agregar mensajes de depuración
        echo "User ID: " . $user_id . "<br>";
        echo "User Level: " . $user_level . "<br>";

        switch ($user_level) {
            case '1':
                redirect('home_admin.php', false);
                break;
            case '2':
                redirect('home_special.php', false);
                break;
            case '3':
                redirect('home_user.php', false);
                break;
            default:
                redirect('login.php', false);
        }
    } else {
        // Mostrar mensaje de error si la autenticación falla
        $session->msg("d", "Nombre de usuario o contraseña incorrectos.");
        redirect('index.php', false);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Sistema de Gestion de Inventario</title>
    <style>
      /* Estilos globales para restablecer márgenes y eliminar barras no deseadas */
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }
      body {
        font-family: 'Arial', sans-serif;
        background-color: #f8f9fa;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
      }
      .container {
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
      }
      .logos-container {
        position: absolute;
        top: 10px;
        display: flex;
        justify-content: center;
        width: 100%;
        gap: 30px;
      }
      .logos img {
        height: 60px;  /* Ajusta esta línea para cambiar la altura de las imágenes */
        object-fit: contain;
      }
      .login-page {
        max-width: 400px;
        width: 100%;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        background-color: #fff;
        text-align: center;
      }
      .form-group {
        margin-bottom: 15px;
        text-align: left; /* Alinea las etiquetas al borde izquierdo */
      }
      .form-control {
        border: 1px solid #ccc;
        border-radius: 4px;
        padding: 10px;
        width: 100%;
      }
      .btn-info {
        background-color: #17a2b8;
        border: none;
        padding: 10px 20px;
        border-radius: 4px;
        color: #fff;
        font-size: 16px;
      }
    </style>
</head>
<body>
<div class="container">
  <div class="logos-container">
    <img src="uploads/logos/logo UV.png" alt="Logo UV" style="height: 100px; object-fit: contain;">
    <img src="uploads/logos/logo HCVB.png" alt="Logo HCVB" style="height: 100px; object-fit: contain;">
  </div>

  <div class="login-page">
      <div>
         <h1 style="color: #333;">Bienvenido</h1>
         <p style="color: #555;">Iniciar sesión</p>
       </div>
       <?php echo display_msg($msg); ?>
      <form method="post" action="auth.php" class="clearfix" autocomplete="off">
          <div class="form-group">
                <label for="username" class="control-label" style="color: #333;">Usuario</label>
                <input type="text" class="form-control" name="username" placeholder="Usuario" required autocomplete="new-username">
          </div>
          <div class="form-group">
              <label for="Password" class="control-label" style="color: #333;">Contraseña</label>
              <input type="password" name="password" class="form-control" placeholder="Contraseña" required autocomplete="new-password">
          </div>
          <div class="form-group">
              <button type="submit" class="btn btn-info">Entrar</button>
          </div>
      </form>
  </div>
<?php include_once('layouts/footer.php'); ?>
</body>
</html>
