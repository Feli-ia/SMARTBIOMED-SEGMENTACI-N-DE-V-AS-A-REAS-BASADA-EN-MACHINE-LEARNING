<?php
$page_title = 'Agregar Nuevo Producto';
require_once('includes/load.php');
require_once('includes/functions.php'); // Usa require_once para evitar múltiples declaraciones

// Verifica qué nivel de usuario tiene permiso para ver esta página
page_require_level(2);

// Definir las categorías directamente en el código
$categories = [
  ['nombre' => 'Insumos'],
  ['nombre' => 'Economato'],
  ['nombre' => 'Esterilización']
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = trim($_POST['name']);
  $category = $_POST['category'];
  $quantity = (int)$_POST['quantity'];
  $nivel_critico = (int)$_POST['nivel_critico'];

  // Verificar si los campos requeridos no están vacíos
  if (empty($name) || empty($category) || $quantity < 0 || $nivel_critico < 0) {
    $session->msg("d", "Error: Todos los campos son obligatorios y deben ser válidos.");
    redirect('add_new_product.php', false);
  }

  // Check for duplicate entries
  $query_check = "SELECT COUNT(*) FROM products WHERE name = ?";
  if ($stmt_check = $db->prepare($query_check)) {
    $stmt_check->bind_param('s', $name);
    $stmt_check->execute();
    $stmt_check->bind_result($count);
    $stmt_check->fetch();
    $stmt_check->close();

    if ($count > 0) {
      $session->msg("d", "Error: El producto ya existe.");
      redirect('add_new_product.php', false);
    } else {
      $query = "INSERT INTO products (name, categorie, quantity, nivel_critico) VALUES (?, ?, ?, ?)";
      if ($stmt = $db->prepare($query)) {
        $stmt->bind_param('ssii', $name, $category, $quantity, $nivel_critico);
        if ($stmt->execute()) {
          $session->msg("s", "Producto agregado correctamente.");
          redirect('product.php', false);
        } else {
          $session->msg("d", "Error al agregar el producto.");
        }
        $stmt->close();
      } else {
        $session->msg("d", "Error al preparar la consulta SQL.");
      }
    }
  } else {
    $session->msg("d", "Error al preparar la consulta SQL.");
  }
}

include_once('layouts/header.php');
?>

<div class="container">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Agregar Nuevo Producto</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="add_new_product.php" class="form-horizontal">
          <div class="form-group">
            <label for="name" class="col-sm-2 control-label">Nombre del Producto:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="name" placeholder="Nombre del Producto" required>
            </div>
          </div>
          <div class="form-group">
            <label for="category" class="col-sm-2 control-label">Categoría:</label>
            <div class="col-sm-10">
              <select class="form-control" name="category" required>
                <?php foreach ($categories as $category): ?>
                  <option value="<?php echo $category['nombre']; ?>"><?php echo $category['nombre']; ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label for="quantity" class="col-sm-2 control-label">Cantidad:</label>
            <div class="col-sm-10">
              <input type="number" class="form-control" name="quantity" placeholder="Cantidad" required>
            </div>
          </div>
          <div class="form-group">
            <label for="nivel_critico" class="col-sm-2 control-label">Nivel Crítico:</label>
            <div class="col-sm-10">
              <input type="number" class="form-control" name="nivel_critico" placeholder="Nivel Crítico" required>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" class="btn btn-primary">Agregar Producto</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>
