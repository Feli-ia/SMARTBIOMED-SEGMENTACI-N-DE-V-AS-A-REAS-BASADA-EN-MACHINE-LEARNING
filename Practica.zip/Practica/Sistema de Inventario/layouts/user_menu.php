<ul class="nav flex-column">
  <li class="nav-item">
    <a href="home_user.php" class="nav-link">
      <i class="glyphicon glyphicon-info-sign"></i>
      <span>Información</span>
    </a>
  </li>
  <li class="nav-item">
    <a href="use_product.php" class="nav-link">
      <i class="glyphicon glyphicon-list"></i>
      <span>Productos</span>
    </a>
  </li>
  <li class="nav-item">
    <a href="use_medicine.php" class="nav-link">
      <i class="glyphicon glyphicon-heart"></i>
      <span>Medicamentos</span>
    </a>
  </li>
  <li class="nav-item">
    <a href="loan_product.php" class="nav-link">
      <i class="glyphicon glyphicon-transfer"></i>
      <span>Préstamo</span>
    </a>
  </li>
  <li class="nav-item">
    <a href="report_missing.php" class="nav-link">
      <i class="glyphicon glyphicon-alert"></i>
      <span>Advertencia</span>
    </a>
  </li>
</ul>
