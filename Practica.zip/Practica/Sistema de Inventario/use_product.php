<?php
$page_title = 'Usar Producto';
require_once('includes/load.php');
page_require_level(3);

$all_products = find_all('products'); // Obtener todos los productos

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $req_fields = array('product_id', 'quantity');
    validate_fields($req_fields);

    if (empty($errors)) {
        $product_names = $_POST['product_id'];
        $quantities = $_POST['quantity'];
        $date = make_date();
        $user_id = current_user_id(); // Obtener el ID del usuario actual

        // Obtener el nombre del usuario basado en su user_id
        $user = find_by_sql("SELECT name FROM users WHERE id = '{$user_id}' LIMIT 1");
        if (!$user) {
            $session->msg("d", "Usuario no encontrado.");
            redirect('use_product.php', false);
        }
        $user_name = $user[0]['name']; // Nombre del usuario actual

        $db->query("START TRANSACTION"); // Comenzar transacción manual

        try {
            foreach ($product_names as $index => $product_name) {
                $product_name = $db->escape($product_name);
                $quantity = (int)$db->escape($quantities[$index]);

                // Busca el producto en la base de datos
                $product = find_by_sql("SELECT * FROM products WHERE name = '{$product_name}' LIMIT 1");
                if ($product) {
                    $product_id = $product[0]['id'];
                    $new_quantity = $product[0]['quantity'] - $quantity;

                    if ($new_quantity >= 0) {
                        // Actualizar el inventario del producto
                        $update_query = "UPDATE products SET quantity = '{$new_quantity}' WHERE id = '{$product_id}'";
                        $db->query($update_query);

                        // Registrar el uso del producto con el user_id y el nombre del usuario
                        $use_query = "INSERT INTO product_usage (product_id, quantity, date, user_id, user) 
                                      VALUES ('{$product_id}', '{$quantity}', '{$date}', '{$user_id}', '{$user_name}')";
                        $db->query($use_query);
                    } else {
                        throw new Exception("Cantidad insuficiente en el inventario para '{$product_name}'.");
                    }
                } else {
                    throw new Exception("Producto no encontrado: '{$product_name}'.");
                }
            }
            $db->query("COMMIT"); // Confirmar transacción si todo salió bien
            $session->msg('s', "Uso de productos registrado correctamente.");
        } catch (Exception $e) {
            $db->query("ROLLBACK"); // Revertir transacción en caso de error
            $session->msg('d', $e->getMessage());
        }

        redirect('use_product.php', false);
    } else {
        $session->msg("d", $errors);
        redirect('use_product.php', false);
    }
}
?>

  <?php include_once('layouts/header.php'); ?>
  <div class="container">
    <div class="col-md-12">
      <?php echo display_msg($msg); ?>
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-list"></span>
            <span>Usar Producto</span>
          </strong>
        </div>
        <div class="panel-body">
          <form method="post" action="use_product.php" class="clearfix">
            <div id="product-fields">
              <div class="product-field">
                <div class="form-group">
                  <label for="product_id">Producto</label>
                  <input type="text" class="form-control product_id_input" name="product_id[]" placeholder="Nombre del producto" required>
                  <ul class="dropdown-menu product_list"></ul>
                </div>
                <div class="form-group">
                  <label for="quantity">Cantidad</label>
                  <input type="number" class="form-control" name="quantity[]" min="1" placeholder="Cantidad utilizada" required>
                </div>
              </div>
            </div>
            <div class="form-group">
              <button type="button" id="add-product" class="btn btn-success">Agregar otro producto</button>
            </div>
            <div class="form-group">
              <button type="submit" name="submit" class="btn btn-primary">Registrar Uso</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>

  <script>
  document.addEventListener('DOMContentLoaded', function() {
    const allProducts = <?php echo json_encode($all_products); ?>;

    function setupProductAutocomplete(container) {
      const productInput = container.querySelector('.product_id_input');
      const productList = container.querySelector('.product_list');

      productInput.addEventListener('input', function() {
        const userInput = productInput.value.toLowerCase();
        productList.innerHTML = '';
        if (userInput) {
          const filteredOptions = allProducts.filter(product => product.name.toLowerCase().includes(userInput));
          filteredOptions.forEach(product => {
            const option = document.createElement('li');
            option.className = 'dropdown-item';
            option.textContent = product.name;
            option.dataset.id = product.id;
            option.addEventListener('click', function() {
              productInput.value = product.name;
              productList.innerHTML = '';
            });
            productList.appendChild(option);
          });
          productList.style.display = 'block';
        } else {
          productList.style.display = 'none';
        }
      });

      document.addEventListener('click', function(event) {
        if (!productInput.contains(event.target) && !productList.contains(event.target)) {
          productList.style.display = 'none';
        }
      });
    }

    document.querySelectorAll('.product-field').forEach(setupProductAutocomplete);

    document.getElementById('add-product').addEventListener('click', function() {
      const productFields = document.getElementById('product-fields');
      const newFields = document.createElement('div');
      newFields.className = 'product-field';
      newFields.innerHTML = `
        <div class="form-group">
          <label for="product_id">Producto</label>
          <input type="text" class="form-control product_id_input" name="product_id[]" placeholder="Nombre del producto" required>
          <ul class="dropdown-menu product_list"></ul>
        </div>
        <div class="form-group">
          <label for="quantity">Cantidad</label>
          <input type="number" class="form-control" name="quantity[]" min="1" placeholder="Cantidad utilizada" required>
        </div>
        <div class="form-group">
          <button type="button" class="remove-product btn btn-danger">Eliminar</button>
        </div>
      `;
      productFields.appendChild(newFields);
      setupProductAutocomplete(newFields);
      attachRemoveEvent();
      updateRemoveButtons();
    });

    function attachRemoveEvent() {
      document.querySelectorAll('.remove-product').forEach(button => {
        button.addEventListener('click', function() {
          button.closest('.product-field').remove();
          updateRemoveButtons();
        });
      });
    }

    function updateRemoveButtons() {
      const removeButtons = document.querySelectorAll('.remove-product');
      removeButtons.forEach((button, index) => {
        button.style.display = index < 0 ? 'none' : 'block';
      });
    }

    attachRemoveEvent();
    updateRemoveButtons();
  });
  </script>
