<?php
$connection = mysqli_connect('localhost', 'root', 'root', 'uea_inv');
if (!$connection) {
    die('Error de conexión: ' . mysqli_connect_error());
}

// Opcional: Configurar el conjunto de caracteres a UTF-8
mysqli_set_charset($connection, 'utf8');

echo 'Conexión exitosa a la base de datos';
?>
