<?php
require_once('includes/load.php');
page_require_level(2);

$term = $_GET['term'];
$all_products = find_by_sql("SELECT name FROM products WHERE name LIKE '%$term%'");

$product_names = [];
foreach ($all_products as $product) {
    $product_names[] = $product['name'];
}

echo json_encode($product_names);
?>
