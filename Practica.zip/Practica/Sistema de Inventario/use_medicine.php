<?php
$page_title = 'Usar Medicamento';
require_once('includes/load.php');
page_require_level(3);

$all_medicamentos = find_all('medicamentos'); // Obtener todos los medicamentos para el autocompletado

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $req_fields = ['nombre', 'cantidad'];
    validate_fields($req_fields);

    if (empty($errors)) {
        $date = make_date();
        $user_id = current_user_id(); // Obtener el ID del usuario actual

        // Verificar si el usuario existe y obtener su nombre
        $user = find_by_sql("SELECT name FROM users WHERE id='{$user_id}' LIMIT 1");
        if (!$user) {
            $session->msg('d', 'Usuario no encontrado en la base de datos.');
            redirect('use_medicine.php', false);
        }
        $user_name = $user[0]['name']; // Guardar el nombre del usuario

        $nombre = $_POST['nombre'];
        $cantidad = $_POST['cantidad'];

        $db->query("START TRANSACTION");

        try {
            foreach ($nombre as $index => $nombre_medicamento) {
                $cantidad_medicamento = (int)$cantidad[$index];

                $existing_medicine = find_by_sql("SELECT * FROM medicamentos WHERE nombre='{$nombre_medicamento}' LIMIT 1");

                if ($existing_medicine) {
                    $new_quantity = (int)$existing_medicine[0]['cantidad'] - $cantidad_medicamento;
                    if ($new_quantity < 0) {
                        throw new Exception('No hay suficiente cantidad para usar.');
                    } else {
                        // Actualizar la cantidad del medicamento
                        $update_query = "UPDATE medicamentos SET cantidad={$new_quantity} WHERE nombre='{$nombre_medicamento}'";
                        if (!$db->query($update_query)) {
                            throw new Exception('Falló al actualizar la cantidad del medicamento.');
                        }

                        // Registrar el uso del medicamento con `user_id` y `user`
                        $use_query = "INSERT INTO medicine_usage (medicine, user_id, user, quantity, date) 
                                      VALUES ('{$nombre_medicamento}', '{$user_id}', '{$user_name}', '{$cantidad_medicamento}', '{$date}')";
                        if (!$db->query($use_query)) {
                            throw new Exception('Falló al registrar el uso del medicamento.');
                        }
                    }
                } else {
                    throw new Exception('El medicamento no existe.');
                }
            }

            $db->query("COMMIT");
            $session->msg('s', "Uso del medicamento registrado correctamente.");
        } catch (Exception $e) {
            $db->query("ROLLBACK");
            $session->msg('d', $e->getMessage());
        }

        redirect('use_medicine.php', false);
    } else {
        $session->msg("d", $errors);
        redirect('use_medicine.php', false);
    }
}
include_once('layouts/header.php');
?>

<div class="container">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-heart-empty"></span>
          <span>Usar Medicamento</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="use_medicine.php" class="clearfix">
          <div id="medicamento-fields">
            <div class="medicamento-field">
              <div class="form-group">
                <label for="nombre" class="control-label">Nombre</label>
                <input type="text" id="nombre" class="form-control nombre_input" name="nombre[]" placeholder="Nombre del medicamento" required>
                <ul class="dropdown-menu medicamento_list"></ul>
              </div>
              <div class="form-group">
                <label for="cantidad" class="control-label">Cantidad</label>
                <input type="number" id="cantidad" class="form-control" name="cantidad[]" min="1" placeholder="Cantidad utilizada" required>
              </div>
            </div>
          </div>
          <div class="form-group">
            <button type="button" id="add-medicamento" class="btn btn-success">Agregar otro medicamento</button>
          </div>
          <div class="form-group">
            <button type="submit" name="use" class="btn btn-primary">Registrar Uso</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>


<script>
document.addEventListener('DOMContentLoaded', function() {
  const allMedicamentos = <?php echo json_encode($all_medicamentos); ?>;

  function setupMedicamentoAutocomplete(container) {
    const medicamentoInput = container.querySelector('.nombre_input');
    const medicamentoList = container.querySelector('.medicamento_list');

    medicamentoInput.addEventListener('input', function() {
      const userInput = medicamentoInput.value.toLowerCase();
      medicamentoList.innerHTML = '';
      if (userInput) {
        const filteredOptions = allMedicamentos.filter(medicamento => medicamento.nombre.toLowerCase().includes(userInput));
        filteredOptions.forEach(medicamento => {
          const option = document.createElement('li');
          option.className = 'dropdown-item';
          option.textContent = medicamento.nombre;
          option.dataset.id = medicamento.id;
          option.addEventListener('click', function() {
            medicamentoInput.value = medicamento.nombre;
            medicamentoList.innerHTML = '';
          });
          medicamentoList.appendChild(option);
        });
        medicamentoList.style.display = 'block';
      } else {
        medicamentoList.style.display = 'none';
      }
    });

    document.addEventListener('click', function(event) {
      if (!medicamentoInput.contains(event.target) && !medicamentoList.contains(event.target)) {
        medicamentoList.style.display = 'none';
      }
    });
  }

  document.querySelectorAll('.medicamento-field').forEach(setupMedicamentoAutocomplete);

  document.getElementById('add-medicamento').addEventListener('click', function() {
    const medicamentoFields = document.getElementById('medicamento-fields');
    const newFields = document.createElement('div');
    newFields.className = 'medicamento-field';
    newFields.innerHTML = `
      <div class="form-group">
        <label for="nombre" class="control-label">Nombre</label>
        <input type="text" class="form-control nombre_input" name="nombre[]" placeholder="Nombre del medicamento" required>
        <ul class="dropdown-menu medicamento_list"></ul>
      </div>
      <div class="form-group">
        <label for="cantidad" class="control-label">Cantidad</label>
        <input type="number" class="form-control" name="cantidad[]" min="1" placeholder="Cantidad utilizada" required>
      </div>
      <div class="form-group">
        <button type="button" class="remove-medicamento btn btn-danger">Eliminar</button>
      </div>
    `;
    medicamentoFields.appendChild(newFields);
    setupMedicamentoAutocomplete(newFields);
    attachRemoveEvent();
    updateRemoveButtons();
  });

  function attachRemoveEvent() {
    document.querySelectorAll('.remove-medicamento').forEach(button => {
      button.addEventListener('click', function() {
        button.closest('.medicamento-field').remove();
        updateRemoveButtons();
      });
    });
  }

  function updateRemoveButtons() {
    const removeButtons = document.querySelectorAll('.remove-medicamento');
    removeButtons.forEach((button, index) => {
      button.style.display = index < 0 ? 'none' : 'block';
    });
  }

  attachRemoveEvent();
  updateRemoveButtons();
});
</script>
