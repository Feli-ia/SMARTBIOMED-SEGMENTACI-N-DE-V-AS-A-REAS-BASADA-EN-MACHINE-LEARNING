<?php
$page_title = 'Administrar Inventario de Medicamentos';
require_once('includes/load.php');
// Verifica qué nivel de usuario tiene permiso para ver esta página
page_require_level(2);

// Número de medicamentos por página
$medicines_per_page = 15;

// Inicializar los filtros con valores predeterminados
$search_name = '';
$min_quantity = 0;
$critical_only = false;
$sort_by = 'default';
$order = 'asc';

// Recuperar filtros de búsqueda de la URL
if ($_SERVER["REQUEST_METHOD"] == "GET") {
  if (isset($_GET['search_name'])) {
    $search_name = $_GET['search_name'];
  }
  if (isset($_GET['min_quantity'])) {
    $min_quantity = (int)$_GET['min_quantity'];
  }
  if (isset($_GET['critical_only'])) {
    $critical_only = (bool)$_GET['critical_only'];
  }
  if (isset($_GET['sort_order'])) {
    $sort_order = $_GET['sort_order'];
    if ($sort_order == 'cantidad_asc') {
      $sort_by = 'cantidad';
      $order = 'asc';
    } elseif ($sort_order == 'cantidad_desc') {
      $sort_by = 'cantidad';
      $order = 'desc';
    } else {
      $sort_by = 'default';
      $order = 'asc';
    }
  }
}

// Obtener el número total de medicamentos con filtros aplicados
$total_medicines = count_medicines_with_filters('medicamentos', $search_name, $min_quantity, $critical_only);
$total_pages = ceil($total_medicines / $medicines_per_page);

// Obtener la página actual desde la URL, por defecto es la página 1
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($current_page - 1) * $medicines_per_page;

// Construir la consulta con los filtros aplicados
$all_medicamentos = find_medicines_with_filters('medicamentos', $search_name, $min_quantity, $medicines_per_page, $offset, $critical_only, $sort_by, $order);

// Actualizar el nivel crítico si se envía el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nombre = $_POST['nombre'];
  $nivel_critico_med = $_POST['nivel_critico_med'];

  // Preparar la declaración SQL para evitar inyección SQL
  $query = "UPDATE medicamentos SET nivel_critico_med = ? WHERE nombre = ?";
  if ($stmt = $db->prepare($query)) {
    $stmt->bind_param('is', $nivel_critico_med, $nombre);
    if ($stmt->execute()) {
      $session->msg("s", "Nivel crítico actualizado correctamente.");
    } else {
      $session->msg("d", "Error al actualizar el nivel crítico.");
    }
    $stmt->close();
  } else {
    $session->msg("d", "Error al preparar la consulta SQL.");
  }
  redirect('medicine.php', false);
}

include_once('layouts/header.php'); 
?>

  <div class="row">
    <!-- Filtros -->
    <div class="col-md-3">
      <div class="panel panel-default" style= "width: 300px">
        <div class="panel-heading">
          <strong>Filtros</strong>
        </div>
        <div class="panel-body">
          <form id="filter-form" method="get" action="medicine.php">
            <div class="form-group">
              <label for="search_name">Nombre del Medicamento:</label>
              <input type="text" class="form-control" name="search_name" value="<?php echo $search_name; ?>" placeholder="Buscar por nombre" onkeydown="if (event.key === 'Enter') { event.preventDefault(); this.form.submit(); }">
            </div>
            <div class="form-group">
              <label for="min_quantity">Cantidad Mínima:</label>
              <input type="number" class="form-control" name="min_quantity" value="<?php echo $min_quantity; ?>" placeholder="Buscar por cantidad mínima" onchange="this.form.submit()">
            </div>
            <div class="form-group">
              <label for="critical_only">Mostrar solo críticos:</label>
              <div class="checkbox">
                <label>
                  <input type="checkbox" name="critical_only" <?php echo $critical_only ? 'checked' : ''; ?> onchange="this.form.submit()"> Sí
                </label>
              </div>
            </div>
            <div class="form-group">
              <label for="sort_order">Ordenar por:</label>
              <select class="form-control" name="sort_order" onchange="this.form.submit()">
                <option value="default" <?php echo $sort_by == 'default' ? 'selected' : ''; ?>>Por defecto</option>
                <option value="cantidad_asc" <?php echo $sort_by == 'cantidad' && $order == 'asc' ? 'selected' : ''; ?>>Cantidad (Ascendente)</option>
                <option value="cantidad_desc" <?php echo $sort_by == 'cantidad' && $order == 'desc' ? 'selected' : ''; ?>>Cantidad (Descendente)</option>
              </select>
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block">Buscar</button>
            </div>
          </form>
        </div>
      </div>
    </div>

<div class="col-md-9">
<div class="container-fluid" style="margin-left: -200px;">
  <div class="panel panel-default">
    <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>Inventario de Medicamentos</span>
            <a href="add_new_medicine.php" class="btn btn-primary pull-right">Nuevo Medicamento</a>
          </strong>
        </div>

          <!-- Paginación -->
          <nav aria-label="Page navigation" style="margin-left: 16px">
            <ul class="pagination">
            <?php if($current_page > 1): ?>
              <li><a href="?page=1&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="First"><span aria-hidden="true">&laquo;&laquo;</span></a></li>
              <li><a href="?page=<?php echo $current_page - 1; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
              <?php endif; ?>

              <?php for($i = 1; $i <= $total_pages; $i++): ?>
                <li class="<?php echo $current_page == $i ? 'active' : ''; ?>"><a href="?page=<?php echo $i; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>"><?php echo $i; ?></a></li>
                <?php endfor; ?>

                <?php if($current_page < $total_pages): ?>
              <li><a href="?page=<?php echo $current_page + 1; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>
              <li><a href="?page=<?php echo $total_pages; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Last"><span aria-hidden="true">&raquo;&raquo;</span></a></li>
           <?php endif; ?>
            </ul>
          </nav>

     <!-- Tabla de Medicamentos -->
        <div class="panel-body">
          <?php if($all_medicamentos): ?>
          <table class="table table-bordered">
            <thead>
              <tr>
                <th class="text-center">Nombre</th>
                <th class="text-center">Cantidad</th>
                <th class="text-center">Nivel Crítico</th>
                <th class="text-center">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($all_medicamentos as $medicamento): ?>
                <tr class="<?php echo (isset($medicamento['cantidad']) && $medicamento['cantidad'] <= $medicamento['nivel_critico_med']) ? 'danger' : ''; ?>">
                  <td class="text-center"><?php echo isset($medicamento['nombre']) ? remove_junk($medicamento['nombre']) : 'Nombre no definido'; ?></td>
                  <td class="text-center"><?php echo isset($medicamento['cantidad']) ? (int)$medicamento['cantidad'] : 'Cantidad no definida'; ?></td>
                  <td class="text-center"><?php echo isset($medicamento['nivel_critico_med']) ? (int)$medicamento['nivel_critico_med'] : 'No definido'; ?></td>
                  <td class="text-center">
                    <form action="medicine.php" method="post" class="form-inline">
                      <input type="hidden" name="nombre" value="<?php echo $medicamento['nombre']; ?>">
                      <div class="form-group">
                        <label for="nivel_critico_med">Nivel Crítico:</label>
                        <input type="number" class="form-control" name="nivel_critico_med" value="<?php echo isset($medicamento['nivel_critico_med']) ? (int)$medicamento['nivel_critico_med'] : ''; ?>" required>
                      </div>
                      <button type="submit" class="btn btn-custom-1 btn-default">Actualizar</button>
                    </form>
                  </td>
                  <td class="text-center">
                    <a href="add_medicine.php?id=<?php echo urlencode($medicamento['nombre']); ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_order=<?php echo urlencode($sort_order); ?>&page=<?php echo urlencode($current_page); ?>" class="btn btn-success btn-sm" title="Agregar Medicamento" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-plus"></span>
                    </a>
                    <a href="exit_medicine.php?id=<?php echo urlencode($medicamento['nombre']); ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_order=<?php echo urlencode($sort_order); ?>&page=<?php echo urlencode($current_page); ?>" class="btn btn-warning btn-sm" title="Sacar Medicamento" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-minus"></span>
                    </a>
                    <a href="delete_medicine.php?id=<?php echo urlencode($medicamento['nombre']); ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_order=<?php echo urlencode($sort_order); ?>&page=<?php echo urlencode($current_page); ?>" class="btn btn-danger btn-sm" title="Eliminar Medicamento" data-toggle="tooltip">
                    <span class="glyphicon glyphicon-trash"></span>
                    </a>
                    <a href="edit_medicine.php?id=<?php echo urlencode($medicamento['nombre']); ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_order=<?php echo urlencode($sort_order); ?>&page=<?php echo urlencode($current_page); ?>" class="btn btn-custom-6 btn-sm" title="Editar Medicamento" data-toggle="tooltip">
                    <span class="glyphicon glyphicon-pencil"></span>
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>

          <!-- Paginación -->
          <nav aria-label="Page navigation">
            <ul class="pagination">
            <?php if($current_page > 1): ?>
              <li><a href="?page=1&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="First"><span aria-hidden="true">&laquo;&laquo;</span></a></li>
              <li><a href="?page=<?php echo $current_page - 1; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
              <?php endif; ?>

              <?php for($i = 1; $i <= $total_pages; $i++): ?>
                <li class="<?php echo $current_page == $i ? 'active' : ''; ?>"><a href="?page=<?php echo $i; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>"><?php echo $i; ?></a></li>
                <?php endfor; ?>

                <?php if($current_page < $total_pages): ?>
              <li><a href="?page=<?php echo $current_page + 1; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>
              <li><a href="?page=<?php echo $total_pages; ?>&search_name=<?php echo urlencode($search_name); ?>&min_quantity=<?php echo urlencode($min_quantity); ?>&critical_only=<?php echo urlencode($critical_only); ?>&sort_by=<?php echo urlencode($sort_by); ?>&order=<?php echo urlencode($order); ?>" aria-label="Last"><span aria-hidden="true">&raquo;&raquo;</span></a></li>
           <?php endif; ?>
            </ul>
          </nav>

          <?php else: ?>
            <div class="alert alert-warning">
              No se encontraron medicamentos en el inventario.
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

<?php include_once('layouts/footer.php'); ?>
