<?php
$page_title = 'Agregar Nuevo Medicamento';
require_once('includes/load.php');
// Verifica qué nivel de usuario tiene permiso para ver esta página
page_require_level(2);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nombre = trim($_POST['nombre']);
  $cantidad = (int)$_POST['cantidad'];
  $nivel_critico_med = (int)$_POST['nivel_critico_med'];

  // Verificar si los campos requeridos no están vacíos
  if (empty($nombre) || $cantidad < 0 || $nivel_critico_med < 0) {
    $session->msg("d", "Error: Todos los campos son obligatorios y deben ser válidos.");
    redirect('add_new_medicine.php', false);
  }

  // Check for duplicate entries
  $query_check = "SELECT COUNT(*) FROM medicamentos WHERE nombre = ?";
  if ($stmt_check = $db->prepare($query_check)) {
    $stmt_check->bind_param('s', $nombre);
    $stmt_check->execute();
    $stmt_check->bind_result($count);
    $stmt_check->fetch();
    $stmt_check->close();

    if ($count > 0) {
      $session->msg("d", "Error: El medicamento ya existe.");
      redirect('add_new_medicine.php', false);
    } else {
      $query = "INSERT INTO medicamentos (nombre, cantidad, nivel_critico_med) VALUES (?, ?, ?)";
      if ($stmt = $db->prepare($query)) {
        $stmt->bind_param('sii', $nombre, $cantidad, $nivel_critico_med);
        if ($stmt->execute()) {
          $session->msg("s", "Medicamento agregado correctamente.");
          redirect('add_new_medicine.php', false);
        } else {
          $session->msg("d", "Error al agregar el medicamento.");
          redirect('add_new_medicine.php', false);
        }
        $stmt->close();
      } else {
        $session->msg("d", "Error al preparar la consulta SQL.");
        redirect('add_new_medicine.php', false);
      }
    }
  } else {
    $session->msg("d", "Error al preparar la consulta SQL.");
    redirect('add_new_medicine.php', false);
  }
}

include_once('layouts/header.php');
?>

<div class="container">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Agregar Nuevo Medicamento</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="add_new_medicine.php" class="form-horizontal">
          <div class="form-group">
            <label for="nombre" class="col-sm-2 control-label">Nombre del Medicamento:</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="nombre" placeholder="Nombre del Medicamento" required>
            </div>
          </div>
          <div class="form-group">
            <label for="cantidad" class="col-sm-2 control-label">Cantidad:</label>
            <div class="col-sm-10">
              <input type="number" class="form-control" name="cantidad" placeholder="Ingrese la cantidad disponible del medicamento." required>
            </div>
          </div>
          <div class="form-group">
            <label for="nivel_critico_med" class="col-sm-2 control-label">Stock Crítico:</label>
            <div class="col-sm-10">
              <input type="number" class="form-control" name="nivel_critico_med" placeholder="Stock Crítico" required>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" class="btn btn-primary">Agregar Medicamento</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>
