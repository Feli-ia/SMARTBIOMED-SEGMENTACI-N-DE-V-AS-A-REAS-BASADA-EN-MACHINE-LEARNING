<?php
$page_title = 'Admin Página de Inicio';
require_once('includes/load.php');
require_once('includes/sql.php'); // Incluir el archivo que contiene las funciones necesarias

// Verificar el nivel de usuario que tiene permiso para ver esta página
page_require_level(1);

// Obtener datos del resumen
$c_critical_products = count_by_critical_level('products', 'quantity', 'nivel_critico');
$c_product = count_by_id('products');
$c_use = count_by_id('product_usage');
$c_critical_meds = count_by_critical_level('medicamentos', 'cantidad', 'nivel_critico_med');
$c_medicamentos = count_by_id('medicamentos');

// Definir el número de filas por página
$limit = 5;

// Obtener la página actual para la paginación
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Consultar los datos con límites y desplazamiento (offset)
$products = find_higest_using_product($limit, $offset);
$recent_products = find_recent_product_added($limit, $offset);
$recent_medicamentos = find_recent_medicamento_added($limit, $offset);
$top_users = find_top_users($limit, $offset);

// Contar el total de registros para la paginación
$total_products = count_by_id('products')['total'];
$total_recent_products = count_by_id('products')['total']; // O número total de productos recientes, si es diferente
$total_recent_medicamentos = count_by_id('medicamentos')['total']; // O número total de medicamentos recientes, si es diferente
$total_top_users = count_by_id('users')['total']; // O número total de usuarios, si es diferente

// Calcular el número total de páginas para cada tabla
$total_pages_products = ceil($total_products / $limit);
$total_pages_recent_products = ceil($total_recent_products / $limit);
$total_pages_recent_medicamentos = ceil($total_recent_medicamentos / $limit);
$total_pages_top_users = ceil($total_top_users / $limit);
?>

<?php include_once('layouts/header.php'); ?>

<!-- Paneles de resumen -->
<div class="row">
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-red">
        <i class="glyphicon glyphicon-list"></i>
      </div>
      <div class="panel-value">
        <h2 class="margin-top"> <?php echo $c_critical_products['total']; ?> </h2>
        <p class="text-muted">Productos Críticos</p>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-blue">
        <i class="glyphicon glyphicon-cloud"></i>
      </div>
      <div class="panel-value">
        <h2 class="margin-top"> <?php echo $c_product['total']; ?> </h2>
        <p class="text-muted">Productos</p>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-purple">
        <i class="glyphicon glyphicon-heart"></i>
      </div>
      <div class="panel-value">
        <h2 class="margin-top"> <?php echo $c_critical_meds['total']; ?> </h2>
        <p class="text-muted">Medicamentos Críticos</p>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-green">
        <i class="glyphicon glyphicon-plus"></i>
      </div>
      <div class="panel-value">
        <h2 class="margin-top"> <?php echo $c_medicamentos['total']; ?> </h2>
        <p class="text-muted">Medicamentos</p>
      </div>
    </div>
  </div>
</div>

<script>
  function toggleTable(tableId) {
    var table = document.getElementById(tableId);
    table.style.display = (table.style.display === "none") ? "block" : "none";
  }
</script>

<button onclick="toggleTable('productosTable')" class="btn btn-primary">Mostrar/Ocultar Productos más Utilizados</button>
<button onclick="toggleTable('recentProductsTable')" class="btn btn-primary">Mostrar/Ocultar Productos Recientemente Añadidos</button>
<button onclick="toggleTable('recentMedicamentosTable')" class="btn btn-primary">Mostrar/Ocultar Medicamentos Recientemente Añadidos</button>



<!-- Productos más utilizados -->
<div id="productosTable" style="display: block;"> <!-- Inicialmente visible -->
  <div class="col-md-6">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong><span class="glyphicon glyphicon-th"></span><span> Productos más utilizados</span></strong>
      </div>
      <div class="panel-body">
        <table class="table table-striped table-bordered table-condensed">
          <thead>
            <tr>
              <th>Título</th>
              <th>Total Consumo</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($products as $product): ?>
              <tr>
                <td><?php echo remove_junk(first_character($product['name'])); ?></td>
                <td><?php echo (int)$product['totalQty']; ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Productos recientemente añadidos -->
<div id="recentProductsTable" style="display: block;"> <!-- Inicialmente visible -->
  <div class="col-md-6">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong><span class="glyphicon glyphicon-th"></span><span> Productos recientemente añadidos</span></strong>
      </div>
      <div class="panel-body">
        <div class="list-group">
          <?php foreach ($recent_products as $recent_product): ?>
            <div class="list-group-item clearfix">
              <h4 class="list-group-item-heading"><?php echo remove_junk(first_character($recent_product['name'])); ?></h4>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Medicamentos recientemente añadidos -->
<div id="recentMedicamentosTable" style="display: block;"> <!-- Inicialmente visible -->
  <div class="col-md-6">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong><span class="glyphicon glyphicon-th"></span><span> Medicamentos recientemente añadidos</span></strong>
      </div>
      <div class="panel-body">
        <div class="list-group">
          <?php foreach ($recent_medicamentos as $recent_medicamento): ?>
            <div class="list-group-item clearfix">
              <h4 class="list-group-item-heading"><?php echo remove_junk(first_character($recent_medicamento['nombre'])); ?></h4>
              <span class="list-group-item-text pull-right">Cantidad: <?php echo (int)$recent_medicamento['cantidad']; ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</div>


<?php include_once('layouts/footer.php'); ?>
