<?php
include_once('includes/load.php');
$req_fields = array('username','password');
validate_fields($req_fields);
$username = remove_junk($_POST['username']);
$password = remove_junk($_POST['password']);

if(empty($errors)) {
    $user = authenticate_v2($username, $password);

    if($user) {
        // Crear sesión con id de usuario
        $session->login($user['id']);
        // Actualizar la hora de inicio de sesión
        updateLastLogIn($user['id']);
        // Redirigir al usuario a su página de inicio según el nivel de usuario
        if($user['user_level'] === '1') {
            $session->msg("s", "Hello ".$user['username'].".");
            redirect('admin.php', false);
        } elseif ($user['user_level'] === '2') {
            $session->msg("s", "Hello ".$user['username']);
            redirect('special.php', false);
        } else {
            $session->msg("s", "Hello ".$user['username']);
            redirect('home_user.php', false);
        }
    } else {
        error_log("Fallo en la autenticación para el usuario: $username");
        $session->msg("d", "Sorry Username/Password incorrect.");
        redirect('index.php', false);
    }
} else {
    $session->msg("d", $errors);
    redirect('login_v2.php', false);
}
?>
